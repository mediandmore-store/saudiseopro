<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckSubscription
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string $feature = null): Response
    {
        $user = Auth::user();

        // Check if user is authenticated
        if (!$user) {
            return redirect()->route('login')
                ->with('error', 'يجب تسجيل الدخول للوصول إلى هذه الصفحة');
        }

        // Check if user has an active subscription
        if (!$user->hasActiveSubscription()) {
            return $this->handleNoSubscription($request);
        }

        $subscription = $user->subscription;

        // Check if subscription is expired
        if ($subscription->expires_at && $subscription->expires_at->isPast()) {
            return $this->handleExpiredSubscription($request);
        }

        // Check if subscription is cancelled and grace period ended
        if ($subscription->cancelled_at && $subscription->ends_at && $subscription->ends_at->isPast()) {
            return $this->handleCancelledSubscription($request);
        }

        // Check specific feature access if provided
        if ($feature && !$user->hasFeature($feature)) {
            return $this->handleFeatureNotAvailable($request, $feature);
        }

        // Check usage limits
        if (!$this->checkUsageLimits($user, $subscription)) {
            return $this->handleUsageLimitExceeded($request);
        }

        // Add subscription info to request for controllers to use
        $request->merge([
            'user_subscription' => $subscription,
            'subscription_features' => $subscription->features,
        ]);

        return $next($request);
    }

    /**
     * Handle case when user has no subscription.
     */
    protected function handleNoSubscription(Request $request): Response
    {
        if ($request->expectsJson()) {
            return response()->json([
                'error' => 'يتطلب اشتراك نشط',
                'redirect' => route('pricing'),
            ], 403);
        }

        return redirect()->route('pricing')
            ->with('warning', 'يرجى اختيار خطة اشتراك للوصول إلى هذه الميزة');
    }

    /**
     * Handle case when subscription is expired.
     */
    protected function handleExpiredSubscription(Request $request): Response
    {
        if ($request->expectsJson()) {
            return response()->json([
                'error' => 'انتهت صلاحية اشتراكك',
                'redirect' => route('pricing'),
            ], 403);
        }

        return redirect()->route('pricing')
            ->with('error', 'انتهت صلاحية اشتراكك. يرجى تجديد الاشتراك للمتابعة');
    }

    /**
     * Handle case when subscription is cancelled.
     */
    protected function handleCancelledSubscription(Request $request): Response
    {
        if ($request->expectsJson()) {
            return response()->json([
                'error' => 'تم إلغاء اشتراكك',
                'redirect' => route('pricing'),
            ], 403);
        }

        return redirect()->route('pricing')
            ->with('info', 'تم إلغاء اشتراكك. يمكنك الاشتراك مرة أخرى للوصول إلى الميزات');
    }

    /**
     * Handle case when feature is not available in current plan.
     */
    protected function handleFeatureNotAvailable(Request $request, string $feature): Response
    {
        $featureNames = [
            'google_integration' => 'ربط Google Analytics و Search Console',
            'platform_integration' => 'ربط المتاجر الإلكترونية',
            'keyword_analysis' => 'تحليل الكلمات المفتاحية',
            'content_optimization' => 'تحسين المحتوى بالذكاء الاصطناعي',
            'competitor_analysis' => 'تحليل المنافسين',
            'rank_tracking' => 'تتبع ترتيب الكلمات',
            'backlink_analysis' => 'تحليل الروابط الخلفية',
            'technical_seo' => 'فحص SEO التقني',
            'white_label' => 'العلامة التجارية البيضاء',
            'api_access' => 'الوصول لـ API',
            'priority_support' => 'دعم فني مميز',
            'custom_reports' => 'تقارير مخصصة',
        ];

        $featureName = $featureNames[$feature] ?? $feature;

        if ($request->expectsJson()) {
            return response()->json([
                'error' => "ميزة {$featureName} غير متاحة في خطتك الحالية",
                'feature' => $feature,
                'redirect' => route('pricing'),
            ], 403);
        }

        return redirect()->route('pricing')
            ->with('warning', "ميزة {$featureName} غير متاحة في خطتك الحالية. يرجى الترقية للوصول إلى هذه الميزة");
    }

    /**
     * Handle case when usage limit is exceeded.
     */
    protected function handleUsageLimitExceeded(Request $request): Response
    {
        if ($request->expectsJson()) {
            return response()->json([
                'error' => 'تم تجاوز حدود الاستخدام لخطتك الحالية',
                'redirect' => route('pricing'),
            ], 403);
        }

        return redirect()->route('pricing')
            ->with('warning', 'تم تجاوز حدود الاستخدام لخطتك الحالية. يرجى الترقية لزيادة الحدود');
    }

    /**
     * Check if user has exceeded usage limits.
     */
    protected function checkUsageLimits($user, $subscription): bool
    {
        // Check website limit
        if (!$subscription->hasUnlimitedWebsites()) {
            $websiteCount = $user->websites()->count();
            if ($websiteCount >= $subscription->max_websites) {
                return false;
            }
        }

        // Check keyword limit
        if (!$subscription->hasUnlimitedKeywords()) {
            $keywordCount = $user->trackedKeywords()->count();
            if ($keywordCount >= $subscription->max_keywords) {
                return false;
            }
        }

        // Check integration limit
        if (!$subscription->hasUnlimitedIntegrations()) {
            $integrationCount = $user->platformTokens()->active()->count();
            if ($integrationCount >= $subscription->max_integrations) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get feature requirements for different routes.
     */
    public static function getFeatureRequirements(): array
    {
        return [
            'integrations.*' => 'platform_integration',
            'google.*' => 'google_integration',
            'keywords.*' => 'keyword_analysis',
            'content.*' => 'content_optimization',
            'competitors.*' => 'competitor_analysis',
            'rankings.*' => 'rank_tracking',
            'backlinks.*' => 'backlink_analysis',
            'technical-seo.*' => 'technical_seo',
            'api.*' => 'api_access',
            'reports.*' => 'custom_reports',
        ];
    }
}

