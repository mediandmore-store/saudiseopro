<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SecurityHeaders
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        // Apply security headers
        $this->applySecurityHeaders($response, $request);

        return $response;
    }

    /**
     * Apply security headers to the response.
     */
    protected function applySecurityHeaders(Response $response, Request $request): void
    {
        // X-Frame-Options: Prevent clickjacking
        $response->headers->set('X-Frame-Options', 'DENY');

        // X-Content-Type-Options: Prevent MIME type sniffing
        $response->headers->set('X-Content-Type-Options', 'nosniff');

        // X-XSS-Protection: Enable XSS filtering
        $response->headers->set('X-XSS-Protection', '1; mode=block');

        // Referrer-Policy: Control referrer information
        $response->headers->set('Referrer-Policy', 'strict-origin-when-cross-origin');

        // Permissions-Policy: Control browser features
        $response->headers->set('Permissions-Policy', $this->getPermissionsPolicy());

        // Content Security Policy
        $response->headers->set('Content-Security-Policy', $this->getContentSecurityPolicy($request));

        // HSTS (HTTP Strict Transport Security) - only in production with HTTPS
        if (app()->environment('production') && $request->isSecure()) {
            $response->headers->set(
                'Strict-Transport-Security',
                'max-age=31536000; includeSubDomains; preload'
            );
        }

        // Remove server information
        $response->headers->remove('Server');
        $response->headers->remove('X-Powered-By');

        // Cache control for sensitive pages
        if ($this->isSensitivePage($request)) {
            $response->headers->set('Cache-Control', 'no-cache, no-store, must-revalidate');
            $response->headers->set('Pragma', 'no-cache');
            $response->headers->set('Expires', '0');
        }
    }

    /**
     * Get Content Security Policy header value.
     */
    protected function getContentSecurityPolicy(Request $request): string
    {
        $policies = [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.google.com https://www.gstatic.com https://apis.google.com https://js.stripe.com https://checkout.paypal.com",
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com",
            "font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com",
            "img-src 'self' data: https: blob:",
            "connect-src 'self' https://api.saudiseopro.com https://www.google-analytics.com https://api.stripe.com https://api.paypal.com",
            "frame-src 'self' https://www.google.com https://js.stripe.com https://www.paypal.com",
            "object-src 'none'",
            "base-uri 'self'",
            "form-action 'self' https://checkout.paypal.com",
            "frame-ancestors 'none'",
        ];

        // Allow additional sources in development
        if (app()->environment('local', 'development')) {
            $policies[] = "script-src 'self' 'unsafe-inline' 'unsafe-eval' http://localhost:* ws://localhost:* https://www.google.com https://www.gstatic.com https://apis.google.com";
            $policies[] = "connect-src 'self' http://localhost:* ws://localhost:* https://api.saudiseopro.com https://www.google-analytics.com";
        }

        return implode('; ', $policies);
    }

    /**
     * Get Permissions Policy header value.
     */
    protected function getPermissionsPolicy(): string
    {
        $policies = [
            'accelerometer=()',
            'ambient-light-sensor=()',
            'autoplay=()',
            'battery=()',
            'camera=()',
            'cross-origin-isolated=()',
            'display-capture=()',
            'document-domain=()',
            'encrypted-media=()',
            'execution-while-not-rendered=()',
            'execution-while-out-of-viewport=()',
            'fullscreen=(self)',
            'geolocation=()',
            'gyroscope=()',
            'keyboard-map=()',
            'magnetometer=()',
            'microphone=()',
            'midi=()',
            'navigation-override=()',
            'payment=(self)',
            'picture-in-picture=()',
            'publickey-credentials-get=()',
            'screen-wake-lock=()',
            'sync-xhr=()',
            'usb=()',
            'web-share=()',
            'xr-spatial-tracking=()',
        ];

        return implode(', ', $policies);
    }

    /**
     * Check if the current page is sensitive and should not be cached.
     */
    protected function isSensitivePage(Request $request): bool
    {
        $sensitiveRoutes = [
            'login',
            'register',
            'password.*',
            'dashboard*',
            'admin*',
            'integrations*',
            'billing*',
            'subscription*',
        ];

        $currentRoute = $request->route()?->getName();

        if (!$currentRoute) {
            return false;
        }

        foreach ($sensitiveRoutes as $pattern) {
            if (fnmatch($pattern, $currentRoute)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get additional headers for API responses.
     */
    protected function getApiHeaders(): array
    {
        return [
            'X-API-Version' => config('app.api_version', '1.0'),
            'X-RateLimit-Limit' => '1000',
            'X-RateLimit-Remaining' => '999',
        ];
    }

    /**
     * Apply headers specific to API routes.
     */
    protected function applyApiHeaders(Response $response): void
    {
        foreach ($this->getApiHeaders() as $header => $value) {
            $response->headers->set($header, $value);
        }

        // CORS headers for API
        $response->headers->set('Access-Control-Allow-Origin', config('app.frontend_url', '*'));
        $response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        $response->headers->set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
        $response->headers->set('Access-Control-Max-Age', '86400');
    }

    /**
     * Check if request is for API route.
     */
    protected function isApiRoute(Request $request): bool
    {
        return $request->is('api/*') || $request->expectsJson();
    }
}

