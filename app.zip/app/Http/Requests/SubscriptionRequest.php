<?php

namespace App\Http\Requests;

use App\Models\Subscription;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class SubscriptionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return Auth::check();
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        $rules = [
            'subscription_id' => [
                'required',
                'integer',
                'exists:subscriptions,id',
                function ($attribute, $value, $fail) {
                    $subscription = Subscription::find($value);
                    if (!$subscription || !$subscription->isActive()) {
                        $fail('الخطة المحددة غير متاحة');
                    }
                },
            ],
            'payment_method' => [
                'required',
                'string',
                'in:paypal,credit_card,bank_transfer,apple_pay,stc_pay',
            ],
            'billing_cycle' => [
                'sometimes',
                'string',
                'in:monthly,quarterly,yearly',
            ],
            'coupon_code' => [
                'sometimes',
                'string',
                'max:50',
                'exists:coupons,code',
            ],
        ];

        // Add validation for upgrade/downgrade scenarios
        if ($this->isMethod('PUT') || $this->isMethod('PATCH')) {
            $rules['reason'] = [
                'sometimes',
                'string',
                'max:500',
            ];
        }

        return $rules;
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'subscription_id.required' => 'يجب اختيار خطة اشتراك',
            'subscription_id.exists' => 'الخطة المحددة غير موجودة',
            'subscription_id.integer' => 'معرف الخطة غير صحيح',
            
            'payment_method.required' => 'يجب اختيار طريقة الدفع',
            'payment_method.in' => 'طريقة الدفع المحددة غير مدعومة',
            
            'billing_cycle.in' => 'دورة الفوترة المحددة غير صحيحة',
            
            'coupon_code.exists' => 'كود الخصم غير صحيح أو منتهي الصلاحية',
            'coupon_code.max' => 'كود الخصم طويل جداً',
            
            'reason.max' => 'السبب طويل جداً (الحد الأقصى 500 حرف)',
        ];
    }

    /**
     * Get custom attributes for validator errors.
     */
    public function attributes(): array
    {
        return [
            'subscription_id' => 'خطة الاشتراك',
            'payment_method' => 'طريقة الدفع',
            'billing_cycle' => 'دورة الفوترة',
            'coupon_code' => 'كود الخصم',
            'reason' => 'السبب',
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        // Clean and prepare data
        if ($this->has('coupon_code')) {
            $this->merge([
                'coupon_code' => strtoupper(trim($this->coupon_code)),
            ]);
        }

        // Set default billing cycle based on subscription if not provided
        if (!$this->has('billing_cycle') && $this->has('subscription_id')) {
            $subscription = Subscription::find($this->subscription_id);
            if ($subscription) {
                $this->merge([
                    'billing_cycle' => $subscription->billing_cycle,
                ]);
            }
        }
    }

    /**
     * Configure the validator instance.
     */
    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            $user = Auth::user();
            $subscriptionId = $this->input('subscription_id');
            
            // Check if user is trying to subscribe to the same plan
            if ($user->subscription_id === $subscriptionId) {
                $validator->errors()->add('subscription_id', 'أنت مشترك بالفعل في هذه الخطة');
            }

            // Validate coupon if provided
            if ($this->has('coupon_code') && $this->coupon_code) {
                $this->validateCoupon($validator);
            }

            // Validate payment method availability
            $this->validatePaymentMethod($validator);

            // Check subscription limits
            $this->validateSubscriptionLimits($validator);
        });
    }

    /**
     * Validate coupon code.
     */
    protected function validateCoupon($validator): void
    {
        $coupon = \App\Models\Coupon::where('code', $this->coupon_code)->first();
        
        if (!$coupon) {
            return; // Will be caught by exists rule
        }

        // Check if coupon is active
        if (!$coupon->is_active) {
            $validator->errors()->add('coupon_code', 'كود الخصم غير نشط');
            return;
        }

        // Check expiry date
        if ($coupon->expires_at && $coupon->expires_at->isPast()) {
            $validator->errors()->add('coupon_code', 'انتهت صلاحية كود الخصم');
            return;
        }

        // Check usage limit
        if ($coupon->max_uses && $coupon->used_count >= $coupon->max_uses) {
            $validator->errors()->add('coupon_code', 'تم استنفاد استخدامات كود الخصم');
            return;
        }

        // Check if user already used this coupon
        $user = Auth::user();
        if ($coupon->max_uses_per_user && 
            $user->couponUsages()->where('coupon_id', $coupon->id)->count() >= $coupon->max_uses_per_user) {
            $validator->errors()->add('coupon_code', 'لقد استخدمت هذا الكود من قبل');
            return;
        }

        // Check minimum order amount
        $subscription = Subscription::find($this->subscription_id);
        if ($coupon->minimum_amount && $subscription && $subscription->price < $coupon->minimum_amount) {
            $validator->errors()->add('coupon_code', 'قيمة الاشتراك أقل من الحد الأدنى لاستخدام هذا الكود');
        }
    }

    /**
     * Validate payment method availability.
     */
    protected function validatePaymentMethod($validator): void
    {
        $paymentMethod = $this->input('payment_method');
        $subscription = Subscription::find($this->input('subscription_id'));
        
        if (!$subscription) {
            return;
        }

        // Check if payment method is available for this subscription
        $unavailableMethods = [];
        
        // Some payment methods might not be available for certain plans
        if ($subscription->price < 50 && $paymentMethod === 'bank_transfer') {
            $unavailableMethods[] = 'التحويل البنكي غير متاح للخطط أقل من 50 ريال';
        }

        if (!empty($unavailableMethods)) {
            $validator->errors()->add('payment_method', implode(', ', $unavailableMethods));
        }
    }

    /**
     * Validate subscription limits.
     */
    protected function validateSubscriptionLimits($validator): void
    {
        $user = Auth::user();
        $subscription = Subscription::find($this->input('subscription_id'));
        
        if (!$subscription || !$user->subscription) {
            return;
        }

        // Check if downgrading and current usage exceeds new limits
        if ($subscription->price < $user->subscription->price) {
            $currentUsage = [
                'websites' => $user->websites()->count(),
                'keywords' => $user->trackedKeywords()->count(),
                'integrations' => $user->platformTokens()->active()->count(),
            ];

            if (!$subscription->hasUnlimitedWebsites() && 
                $currentUsage['websites'] > $subscription->max_websites) {
                $validator->errors()->add('subscription_id', 
                    "لديك {$currentUsage['websites']} مواقع والخطة الجديدة تسمح بـ {$subscription->max_websites} فقط");
            }

            if (!$subscription->hasUnlimitedKeywords() && 
                $currentUsage['keywords'] > $subscription->max_keywords) {
                $validator->errors()->add('subscription_id', 
                    "لديك {$currentUsage['keywords']} كلمة مفتاحية والخطة الجديدة تسمح بـ {$subscription->max_keywords} فقط");
            }

            if (!$subscription->hasUnlimitedIntegrations() && 
                $currentUsage['integrations'] > $subscription->max_integrations) {
                $validator->errors()->add('subscription_id', 
                    "لديك {$currentUsage['integrations']} ربط والخطة الجديدة تسمح بـ {$subscription->max_integrations} فقط");
            }
        }
    }

    /**
     * Get the selected subscription.
     */
    public function getSubscription(): ?Subscription
    {
        return Subscription::find($this->input('subscription_id'));
    }

    /**
     * Get the coupon if valid.
     */
    public function getCoupon(): ?\App\Models\Coupon
    {
        if (!$this->has('coupon_code') || !$this->coupon_code) {
            return null;
        }

        return \App\Models\Coupon::where('code', $this->coupon_code)
            ->where('is_active', true)
            ->where(function ($query) {
                $query->whereNull('expires_at')
                      ->orWhere('expires_at', '>', now());
            })
            ->first();
    }
}

