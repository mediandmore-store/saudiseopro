<?php

namespace App\Http\Controllers;

use App\Http\Requests\SubscriptionRequest;
use App\Models\Subscription;
use App\Services\BillingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class SubscriptionController extends Controller
{
    protected $billingService;

    public function __construct(BillingService $billingService)
    {
        $this->middleware('auth')->except(['showPlans']);
        $this->billingService = $billingService;
    }

    /**
     * Display subscription plans.
     */
    public function showPlans()
    {
        $subscriptions = Cache::remember('subscription_plans', 3600, function () {
            return Subscription::active()
                ->orderByPrice()
                ->get();
        });

        $currentSubscription = Auth::check() ? Auth::user()->subscription : null;

        return view('pricing', compact('subscriptions', 'currentSubscription'));
    }

    /**
     * Show subscription details.
     */
    public function show(Subscription $subscription)
    {
        if (!$subscription->isActive()) {
            abort(404);
        }

        return view('subscriptions.show', compact('subscription'));
    }

    /**
     * Handle subscription request.
     */
    public function subscribe(SubscriptionRequest $request)
    {
        $user = Auth::user();
        $subscription = Subscription::findOrFail($request->subscription_id);

        if (!$subscription->isActive()) {
            return back()->with('error', 'الخطة المحددة غير متاحة حالياً');
        }

        // Check if user already has this subscription
        if ($user->subscription_id === $subscription->id) {
            return back()->with('info', 'أنت مشترك بالفعل في هذه الخطة');
        }

        try {
            // Create payment session
            $paymentData = $this->billingService->createPaymentSession([
                'user_id' => $user->id,
                'subscription_id' => $subscription->id,
                'amount' => $subscription->price,
                'currency' => 'SAR',
                'payment_method' => $request->payment_method,
                'billing_cycle' => $subscription->billing_cycle,
            ]);

            Log::info('Payment session created', [
                'user_id' => $user->id,
                'subscription_id' => $subscription->id,
                'amount' => $subscription->price,
                'payment_method' => $request->payment_method,
            ]);

            return redirect($paymentData['payment_url']);

        } catch (\Exception $e) {
            Log::error('Subscription payment failed', [
                'user_id' => $user->id,
                'subscription_id' => $subscription->id,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في معالجة الدفع. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Handle successful payment callback.
     */
    public function paymentSuccess(Request $request)
    {
        $request->validate([
            'session_id' => 'required|string',
            'payment_id' => 'required|string',
        ]);

        try {
            $paymentDetails = $this->billingService->verifyPayment($request->session_id);

            if ($paymentDetails['status'] !== 'completed') {
                throw new \Exception('Payment not completed');
            }

            $user = Auth::user();
            $subscription = Subscription::findOrFail($paymentDetails['subscription_id']);

            // Update user subscription
            $user->update([
                'subscription_id' => $subscription->id,
            ]);

            // Create payment record
            $this->createPaymentRecord($user, $subscription, $paymentDetails);

            Log::info('Subscription activated successfully', [
                'user_id' => $user->id,
                'subscription_id' => $subscription->id,
                'payment_id' => $request->payment_id,
            ]);

            return redirect('/dashboard')
                ->with('success', 'تم تفعيل اشتراكك بنجاح! مرحباً بك في ' . $subscription->name);

        } catch (\Exception $e) {
            Log::error('Payment verification failed', [
                'session_id' => $request->session_id,
                'error' => $e->getMessage(),
            ]);

            return redirect('/pricing')
                ->with('error', 'حدث خطأ في تأكيد الدفع. يرجى التواصل مع الدعم الفني.');
        }
    }

    /**
     * Handle failed payment callback.
     */
    public function paymentFailed(Request $request)
    {
        Log::warning('Payment failed', [
            'user_id' => Auth::id(),
            'session_id' => $request->session_id,
            'reason' => $request->reason,
        ]);

        return redirect('/pricing')
            ->with('error', 'فشل في معالجة الدفع. يرجى المحاولة مرة أخرى أو استخدام طريقة دفع أخرى.');
    }

    /**
     * Cancel subscription.
     */
    public function cancel(Request $request)
    {
        $user = Auth::user();

        if (!$user->hasActiveSubscription()) {
            return back()->with('error', 'لا يوجد اشتراك نشط للإلغاء');
        }

        $request->validate([
            'reason' => 'nullable|string|max:500',
        ]);

        try {
            // Cancel recurring billing
            $this->billingService->cancelSubscription($user->id);

            // Keep subscription active until end of billing period
            $user->subscription()->update([
                'cancelled_at' => now(),
                'cancellation_reason' => $request->reason,
            ]);

            Log::info('Subscription cancelled', [
                'user_id' => $user->id,
                'subscription_id' => $user->subscription_id,
                'reason' => $request->reason,
            ]);

            return back()->with('success', 'تم إلغاء اشتراكك. ستظل الخدمة متاحة حتى نهاية فترة الفوترة الحالية.');

        } catch (\Exception $e) {
            Log::error('Subscription cancellation failed', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في إلغاء الاشتراك. يرجى التواصل مع الدعم الفني.');
        }
    }

    /**
     * Upgrade subscription.
     */
    public function upgrade(SubscriptionRequest $request)
    {
        $user = Auth::user();
        $newSubscription = Subscription::findOrFail($request->subscription_id);
        $currentSubscription = $user->subscription;

        if (!$currentSubscription) {
            return $this->subscribe($request);
        }

        if ($newSubscription->price <= $currentSubscription->price) {
            return back()->with('error', 'لا يمكن الترقية إلى خطة أقل أو مساوية في السعر');
        }

        try {
            // Calculate prorated amount
            $proratedAmount = $this->billingService->calculateProratedAmount(
                $currentSubscription,
                $newSubscription,
                $user
            );

            if ($proratedAmount > 0) {
                // Create payment for difference
                $paymentData = $this->billingService->createPaymentSession([
                    'user_id' => $user->id,
                    'subscription_id' => $newSubscription->id,
                    'amount' => $proratedAmount,
                    'currency' => 'SAR',
                    'payment_method' => $request->payment_method,
                    'type' => 'upgrade',
                ]);

                return redirect($paymentData['payment_url']);
            } else {
                // Free upgrade
                $user->update(['subscription_id' => $newSubscription->id]);

                return back()->with('success', 'تم ترقية اشتراكك بنجاح!');
            }

        } catch (\Exception $e) {
            Log::error('Subscription upgrade failed', [
                'user_id' => $user->id,
                'current_subscription' => $currentSubscription->id,
                'new_subscription' => $newSubscription->id,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في ترقية الاشتراك. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Downgrade subscription.
     */
    public function downgrade(SubscriptionRequest $request)
    {
        $user = Auth::user();
        $newSubscription = Subscription::findOrFail($request->subscription_id);
        $currentSubscription = $user->subscription;

        if (!$currentSubscription) {
            return back()->with('error', 'لا يوجد اشتراك حالي للتخفيض');
        }

        if ($newSubscription->price >= $currentSubscription->price) {
            return back()->with('error', 'لا يمكن التخفيض إلى خطة أعلى أو مساوية في السعر');
        }

        try {
            // Schedule downgrade for next billing cycle
            $user->update([
                'pending_subscription_id' => $newSubscription->id,
                'subscription_change_date' => $this->getNextBillingDate($user),
            ]);

            Log::info('Subscription downgrade scheduled', [
                'user_id' => $user->id,
                'current_subscription' => $currentSubscription->id,
                'new_subscription' => $newSubscription->id,
                'change_date' => $this->getNextBillingDate($user),
            ]);

            return back()->with('success', 'تم جدولة تخفيض اشتراكك. سيتم التطبيق في بداية الفترة القادمة.');

        } catch (\Exception $e) {
            Log::error('Subscription downgrade failed', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في تخفيض الاشتراك. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Show subscription history.
     */
    public function history()
    {
        $user = Auth::user();
        $payments = $user->payments()
            ->with('subscription')
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('subscriptions.history', compact('payments'));
    }

    /**
     * Download invoice.
     */
    public function downloadInvoice($paymentId)
    {
        $payment = Auth::user()->payments()->findOrFail($paymentId);
        
        return $this->billingService->generateInvoice($payment);
    }

    /**
     * Create payment record.
     */
    protected function createPaymentRecord($user, $subscription, $paymentDetails)
    {
        return $user->payments()->create([
            'subscription_id' => $subscription->id,
            'amount' => $paymentDetails['amount'],
            'currency' => $paymentDetails['currency'],
            'payment_method' => $paymentDetails['payment_method'],
            'payment_id' => $paymentDetails['payment_id'],
            'status' => 'completed',
            'paid_at' => now(),
        ]);
    }

    /**
     * Get next billing date for user.
     */
    protected function getNextBillingDate($user)
    {
        $lastPayment = $user->payments()
            ->where('status', 'completed')
            ->latest()
            ->first();

        if (!$lastPayment) {
            return now()->addMonth();
        }

        return match ($user->subscription->billing_cycle) {
            'monthly' => $lastPayment->paid_at->addMonth(),
            'quarterly' => $lastPayment->paid_at->addMonths(3),
            'yearly' => $lastPayment->paid_at->addYear(),
            default => $lastPayment->paid_at->addMonth(),
        };
    }
}

