<?php

namespace App\Http\Controllers;

use App\Models\Subscription;
use App\Models\User;
use App\Models\Website;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class HomeController extends Controller
{
    public function index()
    {
        $data = [
            'subscriptions' => $this->getSubscriptions(),
            'stats' => $this->getStats(),
            'features' => $this->getFeatures(),
            'testimonials' => $this->getTestimonials(),
        ];

        return view('home', $data);
    }

    public function dashboard()
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        $user = Auth::user();
        
        if (!$user->hasActiveSubscription()) {
            return redirect()->route('pricing')
                ->with('warning', 'يرجى اختيار خطة اشتراك للوصول إلى لوحة التحكم');
        }

        $data = [
            'user' => $user,
            'subscription' => $user->subscription,
            'websites' => $user->websites()->active()->get(),
            'recentActivity' => $this->getRecentActivity($user),
            'seoOverview' => $this->getSeoOverview($user),
            'integrations' => $this->getIntegrations($user),
        ];

        return view('dashboard', $data);
    }

    public function pricing()
    {
        $subscriptions = Subscription::active()
            ->orderBy('sort_order')
            ->orderBy('price')
            ->get();

        return view('pricing', compact('subscriptions'));
    }

    public function about()
    {
        return view('about');
    }

    public function contact()
    {
        return view('contact');
    }

    public function features()
    {
        $features = $this->getFeatures();
        return view('features', compact('features'));
    }

    public function privacy()
    {
        return view('privacy');
    }

    public function terms()
    {
        return view('terms');
    }

    protected function getSubscriptions()
    {
        return Cache::remember('home_subscriptions', 3600, function () {
            return Subscription::active()
                ->orderBy('sort_order')
                ->take(3)
                ->get();
        });
    }

    protected function getStats()
    {
        return Cache::remember('home_stats', 3600, function () {
            return [
                'users_count' => User::where('status', 'active')->count(),
                'websites_count' => Website::where('is_active', true)->count(),
                'keywords_tracked' => Website::sum('keywords_count'),
                'pages_analyzed' => Website::sum('pages_count'),
            ];
        });
    }

    protected function getFeatures()
    {
        return [
            [
                'icon' => 'chart-line',
                'title' => 'تحليل SEO شامل',
                'description' => 'فحص شامل لموقعك وتحديد نقاط القوة والضعف في الـ SEO',
                'features' => [
                    'فحص العناوين والأوصاف',
                    'تحليل الكلمات المفتاحية',
                    'فحص سرعة الموقع',
                    'تحليل الروابط الداخلية',
                ]
            ],
            [
                'icon' => 'link',
                'title' => 'ربط المتاجر الإلكترونية',
                'description' => 'ربط متجرك مع منصات التجارة الإلكترونية الرائدة',
                'features' => [
                    'ربط متجر سلة',
                    'ربط متجر زد',
                    'ربط Shopify',
                    'ربط WooCommerce',
                ]
            ],
            [
                'icon' => 'google',
                'title' => 'تكامل Google',
                'description' => 'ربط مباشر مع أدوات Google للحصول على بيانات دقيقة',
                'features' => [
                    'Google Analytics',
                    'Google Search Console',
                    'Google Sheets',
                    'تقارير مفصلة',
                ]
            ],
            [
                'icon' => 'robot',
                'title' => 'الذكاء الاصطناعي',
                'description' => 'استخدام الذكاء الاصطناعي لتحسين المحتوى والكلمات المفتاحية',
                'features' => [
                    'تحسين المحتوى',
                    'اقتراح كلمات مفتاحية',
                    'كتابة أوصاف المنتجات',
                    'تحليل المنافسين',
                ]
            ],
        ];
    }

    protected function getTestimonials()
    {
        return [
            [
                'name' => 'أحمد محمد',
                'company' => 'متجر الأناقة',
                'image' => '/images/testimonials/ahmed.jpg',
                'rating' => 5,
                'text' => 'ساعدني Saudi SEO Pro في تحسين ترتيب متجري في محركات البحث بشكل كبير. زادت المبيعات بنسبة 150% خلال 3 أشهر.',
            ],
            [
                'name' => 'فاطمة العلي',
                'company' => 'مدونة التقنية',
                'image' => '/images/testimonials/fatima.jpg',
                'rating' => 5,
                'text' => 'أداة رائعة لتحليل المحتوى وتحسين الكلمات المفتاحية. واجهة سهلة الاستخدام وتقارير مفصلة.',
            ],
            [
                'name' => 'خالد السعد',
                'company' => 'شركة الابتكار',
                'image' => '/images/testimonials/khalid.jpg',
                'rating' => 5,
                'text' => 'الربط مع Google Analytics وSearch Console وفر علي الكثير من الوقت. أنصح بها بشدة.',
            ],
        ];
    }

    protected function getRecentActivity($user)
    {
        $activities = [];

        // Recent website additions
        $recentWebsites = $user->websites()
            ->latest()
            ->take(3)
            ->get();

        foreach ($recentWebsites as $website) {
            $activities[] = [
                'type' => 'website_added',
                'title' => "تم إضافة موقع جديد: {$website->name}",
                'time' => $website->created_at,
                'icon' => 'globe',
            ];
        }

        // Recent payments
        $recentPayments = $user->payments()
            ->where('status', 'completed')
            ->latest()
            ->take(2)
            ->get();

        foreach ($recentPayments as $payment) {
            $activities[] = [
                'type' => 'payment_completed',
                'title' => "تم دفع {$payment->getFormattedAmount()}",
                'time' => $payment->paid_at,
                'icon' => 'credit-card',
            ];
        }

        // Sort by time
        usort($activities, function ($a, $b) {
            return $b['time'] <=> $a['time'];
        });

        return array_slice($activities, 0, 5);
    }

    protected function getSeoOverview($user)
    {
        $websites = $user->websites()->active()->get();
        
        if ($websites->isEmpty()) {
            return [
                'total_websites' => 0,
                'average_score' => 0,
                'total_keywords' => 0,
                'total_pages' => 0,
                'issues_count' => 0,
            ];
        }

        $totalScore = 0;
        $totalKeywords = 0;
        $totalPages = 0;
        $totalIssues = 0;

        foreach ($websites as $website) {
            $totalScore += $website->overall_seo_score;
            $totalKeywords += $website->keywords_count;
            $totalPages += $website->pages_count;
            $totalIssues += count($website->getSeoIssues());
        }

        return [
            'total_websites' => $websites->count(),
            'average_score' => $websites->count() > 0 ? round($totalScore / $websites->count()) : 0,
            'total_keywords' => $totalKeywords,
            'total_pages' => $totalPages,
            'issues_count' => $totalIssues,
        ];
    }

    protected function getIntegrations($user)
    {
        $integrations = [
            'google' => $user->hasGoogleConnection(),
            'salla' => $user->platformTokens()->where('platform', 'salla')->where('status', 'active')->exists(),
            'zid' => $user->platformTokens()->where('platform', 'zid')->where('status', 'active')->exists(),
            'shopify' => $user->platformTokens()->where('platform', 'shopify')->where('status', 'active')->exists(),
        ];

        return $integrations;
    }
}

