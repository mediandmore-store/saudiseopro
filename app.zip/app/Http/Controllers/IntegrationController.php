<?php

namespace App\Http\Controllers;

use App\Models\PlatformToken;
use App\Services\SallaService;
use App\Services\ZidService;
use App\Services\ShopifyService;
use App\Services\GoogleService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class IntegrationController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'subscription:platform_integration']);
    }

    /**
     * Display integrations dashboard.
     */
    public function index()
    {
        $user = Auth::user();
        
        $connectedPlatforms = $user->platformTokens()
            ->select('platform', 'store_name', 'store_url', 'created_at', 'is_active')
            ->get()
            ->keyBy('platform');

        $availablePlatforms = PlatformToken::getAvailablePlatforms();
        
        $hasGoogleConnection = $user->hasGoogleConnection();

        return view('integrations.index', compact(
            'connectedPlatforms', 
            'availablePlatforms', 
            'hasGoogleConnection'
        ));
    }

    /**
     * Connect to Salla platform.
     */
    public function connectSalla()
    {
        try {
            $sallaService = new SallaService();
            $authUrl = $sallaService->getAuthorizationUrl();
            
            Log::info('Salla connection initiated', [
                'user_id' => Auth::id(),
                'auth_url' => $authUrl,
            ]);

            return redirect($authUrl);

        } catch (\Exception $e) {
            Log::error('Salla connection failed', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في الاتصال بسلة. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Handle Salla OAuth callback.
     */
    public function handleSallaCallback(Request $request)
    {
        if ($request->has('error')) {
            Log::warning('Salla OAuth cancelled', [
                'user_id' => Auth::id(),
                'error' => $request->error,
            ]);

            return redirect('/integrations')
                ->with('error', 'تم إلغاء ربط متجر سلة');
        }

        if (!$request->has('code')) {
            return redirect('/integrations')
                ->with('error', 'رمز التفويض مفقود');
        }

        try {
            $sallaService = new SallaService();
            $tokenData = $sallaService->getAccessToken($request->code);
            
            // Get store information
            $storeInfo = $sallaService->getStoreInfo($tokenData['access_token']);

            // Save platform token
            PlatformToken::createOrUpdateForUser(Auth::id(), 'salla', array_merge($tokenData, [
                'store_id' => $storeInfo['id'],
                'store_name' => $storeInfo['name'],
                'store_url' => $storeInfo['domain'],
            ]));

            Log::info('Salla integration successful', [
                'user_id' => Auth::id(),
                'store_id' => $storeInfo['id'],
                'store_name' => $storeInfo['name'],
            ]);

            return redirect('/integrations')
                ->with('success', 'تم ربط متجر سلة "' . $storeInfo['name'] . '" بنجاح!');

        } catch (\Exception $e) {
            Log::error('Salla callback failed', [
                'user_id' => Auth::id(),
                'code' => $request->code,
                'error' => $e->getMessage(),
            ]);

            return redirect('/integrations')
                ->with('error', 'حدث خطأ في ربط متجر سلة. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Connect to Zid platform.
     */
    public function connectZid()
    {
        try {
            $zidService = new ZidService();
            $authUrl = $zidService->getAuthorizationUrl();
            
            Log::info('Zid connection initiated', [
                'user_id' => Auth::id(),
            ]);

            return redirect($authUrl);

        } catch (\Exception $e) {
            Log::error('Zid connection failed', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في الاتصال بزد. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Handle Zid OAuth callback.
     */
    public function handleZidCallback(Request $request)
    {
        if ($request->has('error')) {
            return redirect('/integrations')
                ->with('error', 'تم إلغاء ربط متجر زد');
        }

        try {
            $zidService = new ZidService();
            $tokenData = $zidService->getAccessToken($request->code);
            
            $storeInfo = $zidService->getStoreInfo($tokenData['access_token']);

            PlatformToken::createOrUpdateForUser(Auth::id(), 'zid', array_merge($tokenData, [
                'store_id' => $storeInfo['id'],
                'store_name' => $storeInfo['name'],
                'store_url' => $storeInfo['domain'],
            ]));

            Log::info('Zid integration successful', [
                'user_id' => Auth::id(),
                'store_id' => $storeInfo['id'],
            ]);

            return redirect('/integrations')
                ->with('success', 'تم ربط متجر زد "' . $storeInfo['name'] . '" بنجاح!');

        } catch (\Exception $e) {
            Log::error('Zid callback failed', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
            ]);

            return redirect('/integrations')
                ->with('error', 'حدث خطأ في ربط متجر زد. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Connect to Shopify platform.
     */
    public function connectShopify()
    {
        try {
            $shopifyService = new ShopifyService();
            $authUrl = $shopifyService->getAuthorizationUrl();
            
            Log::info('Shopify connection initiated', [
                'user_id' => Auth::id(),
            ]);

            return redirect($authUrl);

        } catch (\Exception $e) {
            Log::error('Shopify connection failed', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في الاتصال بشوبيفاي. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Handle Shopify OAuth callback.
     */
    public function handleShopifyCallback(Request $request)
    {
        if ($request->has('error')) {
            return redirect('/integrations')
                ->with('error', 'تم إلغاء ربط متجر شوبيفاي');
        }

        try {
            $shopifyService = new ShopifyService();
            $tokenData = $shopifyService->getAccessToken($request->code, $request->shop);
            
            $storeInfo = $shopifyService->getStoreInfo($request->shop, $tokenData['access_token']);

            PlatformToken::createOrUpdateForUser(Auth::id(), 'shopify', array_merge($tokenData, [
                'store_id' => $storeInfo['id'],
                'store_name' => $storeInfo['name'],
                'store_url' => $storeInfo['domain'],
            ]));

            Log::info('Shopify integration successful', [
                'user_id' => Auth::id(),
                'shop' => $request->shop,
            ]);

            return redirect('/integrations')
                ->with('success', 'تم ربط متجر شوبيفاي "' . $storeInfo['name'] . '" بنجاح!');

        } catch (\Exception $e) {
            Log::error('Shopify callback failed', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
            ]);

            return redirect('/integrations')
                ->with('error', 'حدث خطأ في ربط متجر شوبيفاي. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Disconnect platform.
     */
    public function disconnectPlatform(Request $request, $platform)
    {
        $request->validate([
            'platform' => 'required|in:salla,zid,shopify',
        ]);

        $user = Auth::user();
        $platformToken = $user->getPlatformToken($platform);

        if (!$platformToken) {
            return back()->with('error', 'المنصة غير مربوطة');
        }

        try {
            $platformToken->delete();

            Log::info('Platform disconnected', [
                'user_id' => $user->id,
                'platform' => $platform,
                'store_name' => $platformToken->store_name,
            ]);

            $platformName = PlatformToken::PLATFORMS[$platform];
            return back()->with('success', "تم إلغاء ربط منصة {$platformName} بنجاح");

        } catch (\Exception $e) {
            Log::error('Platform disconnection failed', [
                'user_id' => $user->id,
                'platform' => $platform,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في إلغاء الربط. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Sync platform data.
     */
    public function syncPlatform(Request $request, $platform)
    {
        $user = Auth::user();
        $platformToken = $user->getPlatformToken($platform);

        if (!$platformToken || !$platformToken->isValid()) {
            return back()->with('error', 'المنصة غير مربوطة أو انتهت صلاحية الاتصال');
        }

        try {
            $service = $this->getPlatformService($platform);
            $syncResult = $service->syncData($platformToken);

            Log::info('Platform data synced', [
                'user_id' => $user->id,
                'platform' => $platform,
                'synced_items' => $syncResult['count'],
            ]);

            return back()->with('success', "تم مزامنة بيانات {$platformToken->platform_name} بنجاح. تم مزامنة {$syncResult['count']} عنصر.");

        } catch (\Exception $e) {
            Log::error('Platform sync failed', [
                'user_id' => $user->id,
                'platform' => $platform,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في مزامنة البيانات. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Test platform connection.
     */
    public function testConnection($platform)
    {
        $user = Auth::user();
        $platformToken = $user->getPlatformToken($platform);

        if (!$platformToken) {
            return response()->json([
                'success' => false,
                'message' => 'المنصة غير مربوطة'
            ]);
        }

        try {
            $service = $this->getPlatformService($platform);
            $isConnected = $service->testConnection($platformToken);

            if ($isConnected) {
                return response()->json([
                    'success' => true,
                    'message' => 'الاتصال يعمل بشكل صحيح'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'فشل في الاتصال. قد تحتاج لإعادة الربط'
                ]);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'حدث خطأ في اختبار الاتصال'
            ]);
        }
    }

    /**
     * Get platform service instance.
     */
    protected function getPlatformService($platform)
    {
        return match ($platform) {
            'salla' => new SallaService(),
            'zid' => new ZidService(),
            'shopify' => new ShopifyService(),
            default => throw new \InvalidArgumentException("Unsupported platform: {$platform}"),
        };
    }
}

