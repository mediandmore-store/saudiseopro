<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Subscription;
use App\Models\PlatformToken;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'verified']);
    }

    /**
     * Display the dashboard.
     */
    public function index()
    {
        $user = Auth::user();

        // Check if user has active subscription
        if (!$user->hasActiveSubscription()) {
            return redirect('/pricing')
                ->with('warning', 'يرجى اختيار خطة اشتراك للوصول إلى لوحة التحكم');
        }

        $dashboardData = $this->getDashboardData($user);

        return view('dashboard', compact('dashboardData'));
    }

    /**
     * Get dashboard analytics data.
     */
    public function analytics()
    {
        $user = Auth::user();
        
        if (!$user->hasFeature('analytics')) {
            abort(403, 'هذه الميزة غير متاحة في خطتك الحالية');
        }

        $analyticsData = $this->getAnalyticsData($user);

        return view('dashboard.analytics', compact('analyticsData'));
    }

    /**
     * Get SEO overview.
     */
    public function seoOverview()
    {
        $user = Auth::user();
        $seoData = $this->getSeoOverviewData($user);

        return view('dashboard.seo-overview', compact('seoData'));
    }

    /**
     * Get keyword tracking data.
     */
    public function keywordTracking()
    {
        $user = Auth::user();
        
        if (!$user->hasFeature('rank_tracking')) {
            abort(403, 'تتبع الكلمات المفتاحية غير متاح في خطتك الحالية');
        }

        $keywordData = $this->getKeywordTrackingData($user);

        return view('dashboard.keyword-tracking', compact('keywordData'));
    }

    /**
     * Get competitor analysis data.
     */
    public function competitorAnalysis()
    {
        $user = Auth::user();
        
        if (!$user->hasFeature('competitor_analysis')) {
            abort(403, 'تحليل المنافسين غير متاح في خطتك الحالية');
        }

        $competitorData = $this->getCompetitorAnalysisData($user);

        return view('dashboard.competitor-analysis', compact('competitorData'));
    }

    /**
     * Get dashboard data for user.
     */
    protected function getDashboardData($user)
    {
        return Cache::remember("dashboard_data_{$user->id}", 300, function () use ($user) {
            $connectedPlatforms = $user->platformTokens()
                ->active()
                ->count();

            $totalWebsites = $user->websites()->count();
            $totalKeywords = $user->trackedKeywords()->count();
            
            // Get recent activity
            $recentActivity = $this->getRecentActivity($user);
            
            // Get SEO score summary
            $seoScores = $this->getSeoScoreSummary($user);
            
            // Get quick stats
            $quickStats = [
                'connected_platforms' => $connectedPlatforms,
                'total_websites' => $totalWebsites,
                'tracked_keywords' => $totalKeywords,
                'avg_seo_score' => $seoScores['average'] ?? 0,
                'google_connected' => $user->hasGoogleConnection(),
            ];

            // Get subscription info
            $subscription = $user->subscription;
            $subscriptionInfo = [
                'name' => $subscription->name,
                'features' => $subscription->feature_list,
                'usage' => $this->getUsageStats($user, $subscription),
            ];

            return [
                'quick_stats' => $quickStats,
                'subscription_info' => $subscriptionInfo,
                'recent_activity' => $recentActivity,
                'seo_scores' => $seoScores,
                'notifications' => $this->getNotifications($user),
            ];
        });
    }

    /**
     * Get analytics data for user.
     */
    protected function getAnalyticsData($user)
    {
        // This would integrate with Google Analytics API
        return [
            'traffic_overview' => [
                'total_sessions' => 12500,
                'total_users' => 8900,
                'bounce_rate' => 45.2,
                'avg_session_duration' => '2:34',
            ],
            'top_pages' => [
                ['url' => '/products/laptop', 'views' => 1250, 'bounce_rate' => 35.2],
                ['url' => '/about', 'views' => 980, 'bounce_rate' => 42.1],
                ['url' => '/contact', 'views' => 750, 'bounce_rate' => 38.5],
            ],
            'traffic_sources' => [
                'organic' => 65.5,
                'direct' => 20.3,
                'social' => 8.7,
                'referral' => 5.5,
            ],
            'keyword_performance' => $this->getKeywordPerformance($user),
        ];
    }

    /**
     * Get SEO overview data.
     */
    protected function getSeoOverviewData($user)
    {
        return [
            'overall_score' => 78,
            'technical_seo' => [
                'score' => 85,
                'issues' => [
                    'missing_meta_descriptions' => 5,
                    'duplicate_titles' => 2,
                    'slow_loading_pages' => 3,
                ]
            ],
            'content_optimization' => [
                'score' => 72,
                'opportunities' => [
                    'keyword_optimization' => 8,
                    'content_length' => 4,
                    'internal_linking' => 6,
                ]
            ],
            'backlink_profile' => [
                'total_backlinks' => 245,
                'referring_domains' => 89,
                'domain_authority' => 42,
            ],
        ];
    }

    /**
     * Get keyword tracking data.
     */
    protected function getKeywordTrackingData($user)
    {
        return [
            'total_keywords' => 150,
            'ranking_improvements' => 23,
            'ranking_declines' => 8,
            'top_keywords' => [
                ['keyword' => 'أفضل متجر إلكتروني', 'position' => 3, 'change' => +2],
                ['keyword' => 'تصميم مواقع', 'position' => 7, 'change' => -1],
                ['keyword' => 'SEO عربي', 'position' => 12, 'change' => +5],
            ],
            'keyword_distribution' => [
                'top_3' => 12,
                'top_10' => 34,
                'top_50' => 89,
                'beyond_50' => 15,
            ],
        ];
    }

    /**
     * Get competitor analysis data.
     */
    protected function getCompetitorAnalysisData($user)
    {
        return [
            'competitors' => [
                ['name' => 'منافس 1', 'domain_authority' => 65, 'organic_keywords' => 2500],
                ['name' => 'منافس 2', 'domain_authority' => 58, 'organic_keywords' => 1800],
                ['name' => 'منافس 3', 'domain_authority' => 52, 'organic_keywords' => 1200],
            ],
            'keyword_gaps' => [
                ['keyword' => 'تسويق رقمي', 'competitor_rank' => 5, 'our_rank' => null],
                ['keyword' => 'إعلانات جوجل', 'competitor_rank' => 8, 'our_rank' => 25],
            ],
            'backlink_opportunities' => [
                ['domain' => 'example.com', 'authority' => 75, 'linking_to_competitor' => true],
                ['domain' => 'another-site.com', 'authority' => 68, 'linking_to_competitor' => true],
            ],
        ];
    }

    /**
     * Get recent activity for user.
     */
    protected function getRecentActivity($user)
    {
        return [
            [
                'type' => 'keyword_rank_change',
                'message' => 'تحسن ترتيب كلمة "تصميم مواقع" من المركز 15 إلى 8',
                'time' => '2 ساعات',
                'icon' => 'trending-up',
                'color' => 'success'
            ],
            [
                'type' => 'new_backlink',
                'message' => 'رابط خلفي جديد من موقع عالي الجودة',
                'time' => '5 ساعات',
                'icon' => 'link',
                'color' => 'info'
            ],
            [
                'type' => 'seo_issue',
                'message' => 'تم اكتشاف 3 صفحات بدون وصف meta',
                'time' => '1 يوم',
                'icon' => 'alert-triangle',
                'color' => 'warning'
            ],
        ];
    }

    /**
     * Get SEO score summary.
     */
    protected function getSeoScoreSummary($user)
    {
        return [
            'average' => 78,
            'technical' => 85,
            'content' => 72,
            'backlinks' => 65,
            'trend' => '+5', // Improvement over last month
        ];
    }

    /**
     * Get usage statistics for subscription.
     */
    protected function getUsageStats($user, $subscription)
    {
        $websites = $user->websites()->count();
        $keywords = $user->trackedKeywords()->count();
        $integrations = $user->platformTokens()->active()->count();

        return [
            'websites' => [
                'used' => $websites,
                'limit' => $subscription->max_websites,
                'percentage' => $subscription->hasUnlimitedWebsites() ? 0 : ($websites / $subscription->max_websites) * 100,
            ],
            'keywords' => [
                'used' => $keywords,
                'limit' => $subscription->max_keywords,
                'percentage' => $subscription->hasUnlimitedKeywords() ? 0 : ($keywords / $subscription->max_keywords) * 100,
            ],
            'integrations' => [
                'used' => $integrations,
                'limit' => $subscription->max_integrations,
                'percentage' => $subscription->hasUnlimitedIntegrations() ? 0 : ($integrations / $subscription->max_integrations) * 100,
            ],
        ];
    }

    /**
     * Get notifications for user.
     */
    protected function getNotifications($user)
    {
        $notifications = [];

        // Check for subscription expiry
        if ($user->subscription && $user->subscription->expires_at && $user->subscription->expires_at->diffInDays() <= 7) {
            $notifications[] = [
                'type' => 'warning',
                'message' => 'اشتراكك سينتهي خلال ' . $user->subscription->expires_at->diffInDays() . ' أيام',
                'action' => 'تجديد الاشتراك',
                'url' => '/pricing',
            ];
        }

        // Check for expired platform tokens
        $expiredTokens = $user->platformTokens()->expired()->count();
        if ($expiredTokens > 0) {
            $notifications[] = [
                'type' => 'error',
                'message' => "انتهت صلاحية الاتصال مع {$expiredTokens} منصة",
                'action' => 'إعادة الربط',
                'url' => '/integrations',
            ];
        }

        return $notifications;
    }

    /**
     * Get keyword performance data.
     */
    protected function getKeywordPerformance($user)
    {
        // This would come from actual keyword tracking data
        return [
            'total_impressions' => 45000,
            'total_clicks' => 2800,
            'average_ctr' => 6.2,
            'average_position' => 12.5,
        ];
    }
}

