<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function login(LoginRequest $request): JsonResponse
    {
        $credentials = $request->validated();
        
        // Check rate limiting
        if (RateLimiter::tooManyAttempts($request->throttleKey(), 5)) {
            $seconds = RateLimiter::availableIn($request->throttleKey());
            
            return response()->json([
                'success' => false,
                'message' => "تم تجاوز عدد المحاولات المسموح. يرجى المحاولة بعد {$seconds} ثانية.",
                'retry_after' => $seconds,
            ], 429);
        }

        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            
            // Update last login info
            $user->update([
                'last_login_at' => now(),
                'last_login_ip' => $request->ip(),
            ]);

            // Create API token
            $token = $user->createToken('api-token', ['*'])->plainTextToken;

            RateLimiter::clear($request->throttleKey());

            Log::info('API login successful', [
                'user_id' => $user->id,
                'email' => $user->email,
                'ip' => $request->ip(),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'تم تسجيل الدخول بنجاح',
                'data' => [
                    'user' => $this->formatUser($user),
                    'token' => $token,
                    'token_type' => 'Bearer',
                ],
            ]);
        }

        RateLimiter::hit($request->throttleKey());

        Log::warning('API login failed', [
            'email' => $request->email,
            'ip' => $request->ip(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'البيانات المدخلة غير صحيحة',
        ], 401);
    }

    public function register(RegisterRequest $request): JsonResponse
    {
        $validated = $request->validated();
        $subscription = $request->getSubscription();

        try {
            // Create user
            $user = User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'password' => Hash::make($validated['password']),
                'marketing_emails' => $validated['marketing_emails'] ?? false,
                'status' => 'pending',
            ]);

            // Create subscription record
            $user->subscriptions()->create([
                'subscription_id' => $subscription->id,
                'status' => 'pending',
                'amount_paid' => $subscription->price,
                'billing_cycle' => $subscription->billing_cycle,
                'starts_at' => now(),
                'expires_at' => now()->addMonth(),
                'features_snapshot' => $subscription->getFeatureList(),
            ]);

            // Create API token
            $token = $user->createToken('api-token', ['*'])->plainTextToken;

            Log::info('API registration successful', [
                'user_id' => $user->id,
                'email' => $user->email,
                'subscription_id' => $subscription->id,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'تم إنشاء الحساب بنجاح',
                'data' => [
                    'user' => $this->formatUser($user),
                    'token' => $token,
                    'token_type' => 'Bearer',
                ],
            ], 201);

        } catch (\Exception $e) {
            Log::error('API registration failed', [
                'email' => $validated['email'],
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'حدث خطأ في إنشاء الحساب',
                'error' => config('app.debug') ? $e->getMessage() : null,
            ], 500);
        }
    }

    public function logout(Request $request): JsonResponse
    {
        $user = $request->user();
        
        // Revoke current token
        $request->user()->currentAccessToken()->delete();

        Log::info('API logout successful', [
            'user_id' => $user->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'تم تسجيل الخروج بنجاح',
        ]);
    }

    public function me(Request $request): JsonResponse
    {
        $user = $request->user();
        
        return response()->json([
            'success' => true,
            'data' => [
                'user' => $this->formatUser($user),
                'subscription' => $user->subscription ? [
                    'id' => $user->subscription->id,
                    'name' => $user->subscription->subscription->name,
                    'status' => $user->subscription->status,
                    'expires_at' => $user->subscription->expires_at,
                    'features' => $user->subscription->getFeatures(),
                ] : null,
            ],
        ]);
    }

    public function refresh(Request $request): JsonResponse
    {
        $user = $request->user();
        
        // Revoke current token
        $request->user()->currentAccessToken()->delete();
        
        // Create new token
        $token = $user->createToken('api-token', ['*'])->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'تم تجديد الرمز المميز بنجاح',
            'data' => [
                'token' => $token,
                'token_type' => 'Bearer',
            ],
        ]);
    }

    public function updateProfile(Request $request): JsonResponse
    {
        $request->validate([
            'name' => 'sometimes|string|max:255',
            'phone' => 'sometimes|nullable|string|max:20',
            'company' => 'sometimes|nullable|string|max:255',
            'website' => 'sometimes|nullable|url|max:255',
            'timezone' => 'sometimes|string|max:50',
            'locale' => 'sometimes|string|in:ar,en',
            'marketing_emails' => 'sometimes|boolean',
        ]);

        $user = $request->user();
        $user->update($request->only([
            'name', 'phone', 'company', 'website', 
            'timezone', 'locale', 'marketing_emails'
        ]));

        Log::info('API profile updated', [
            'user_id' => $user->id,
            'updated_fields' => array_keys($request->only([
                'name', 'phone', 'company', 'website', 
                'timezone', 'locale', 'marketing_emails'
            ])),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'تم تحديث الملف الشخصي بنجاح',
            'data' => [
                'user' => $this->formatUser($user),
            ],
        ]);
    }

    public function changePassword(Request $request): JsonResponse
    {
        $request->validate([
            'current_password' => 'required|string',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = $request->user();

        if (!Hash::check($request->current_password, $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'كلمة المرور الحالية غير صحيحة',
            ], 400);
        }

        $user->update([
            'password' => Hash::make($request->password),
        ]);

        // Revoke all tokens except current
        $user->tokens()->where('id', '!=', $request->user()->currentAccessToken()->id)->delete();

        Log::info('API password changed', [
            'user_id' => $user->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'تم تغيير كلمة المرور بنجاح',
        ]);
    }

    protected function formatUser(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'company' => $user->company,
            'website' => $user->website,
            'status' => $user->status,
            'email_verified_at' => $user->email_verified_at,
            'timezone' => $user->timezone,
            'locale' => $user->locale,
            'marketing_emails' => $user->marketing_emails,
            'last_login_at' => $user->last_login_at,
            'created_at' => $user->created_at,
        ];
    }
}

