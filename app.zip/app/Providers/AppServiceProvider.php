<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Gate;
use Illuminate\Pagination\Paginator;
use App\Models\User;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Register services in container
        $this->app->singleton(\App\Services\BillingService::class, function ($app) {
            return new \App\Services\BillingService();
        });

        $this->app->singleton(\App\Services\GoogleService::class, function ($app) {
            return new \App\Services\GoogleService();
        });

        $this->app->singleton(\App\Services\SallaService::class, function ($app) {
            return new \App\Services\SallaService();
        });

        $this->app->singleton(\App\Services\ZidService::class, function ($app) {
            return new \App\Services\ZidService();
        });

        // Register development tools only in local environment
        if ($this->app->environment('local')) {
            $this->app->register(\Laravel\Telescope\TelescopeServiceProvider::class);
           
        }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Set default string length for MySQL
        Schema::defaultStringLength(191);

        // Force HTTPS in production
        if ($this->app->environment('production')) {
            URL::forceScheme('https');
        }

        // Use Bootstrap for pagination
        Paginator::useBootstrapFive();

        // Share common data with all views
        $this->shareViewData();

        // Define custom gates
        $this->defineGates();

        // Register custom macros
        $this->registerMacros();

        // Set locale based on user preference
        $this->setLocale();
    }

    /**
     * Share common data with all views
     */
    protected function shareViewData(): void
    {
        View::composer('*', function ($view) {
            $user = auth()->user();
            
            $sharedData = [
                'appName' => config('app.name'),
                'appVersion' => config('app.version', '1.0.0'),
                'currentUser' => $user,
                'hasActiveSubscription' => $user ? $user->hasActiveSubscription() : false,
            ];

            if ($user && $user->hasActiveSubscription()) {
                $sharedData['userSubscription'] = $user->subscription;
                $sharedData['subscriptionFeatures'] = $user->subscription->getFeatures();
            }

            $view->with($sharedData);
        });

        // Share navigation data
        View::composer(['layouts.app', 'layouts.dashboard'], function ($view) {
            $navigationItems = $this->getNavigationItems();
            $view->with('navigationItems', $navigationItems);
        });
    }

    /**
     * Define custom authorization gates
     */
    protected function defineGates(): void
    {
        Gate::define('access-admin-panel', function (User $user) {
            return in_array($user->email, config('app.admin_emails', [])) ||
                   $user->status === 'admin';
        });

        Gate::define('manage-users', function (User $user) {
            return $user->can('access-admin-panel');
        });

        Gate::define('manage-subscriptions', function (User $user) {
            return $user->can('access-admin-panel');
        });

        Gate::define('view-analytics', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('google_integration');
        });

        Gate::define('manage-integrations', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('platform_integration');
        });

        Gate::define('export-data', function (User $user) {
            return $user->hasActiveSubscription();
        });

        Gate::define('api-access', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('api_access');
        });
    }

    /**
     * Register custom macros
     */
    protected function registerMacros(): void
    {
        // Add custom collection macro for SEO score calculation
        \Illuminate\Support\Collection::macro('averageSeoScore', function () {
            if ($this->isEmpty()) {
                return 0;
            }

            $scores = $this->pluck('overall_seo_score')->filter();
            return $scores->isEmpty() ? 0 : round($scores->average());
        });

        // Add custom request macro for throttle key
        \Illuminate\Http\Request::macro('throttleKey', function () {
            return 'login_attempts:' . $this->ip() . ':' . ($this->input('email') ?? 'unknown');
        });

        // Add custom response macro for API responses
        \Illuminate\Http\Response::macro('apiSuccess', function ($data = null, $message = 'Success', $code = 200) {
            return response()->json([
                'success' => true,
                'message' => $message,
                'data' => $data,
            ], $code);
        });

        \Illuminate\Http\Response::macro('apiError', function ($message = 'Error', $code = 400, $errors = null) {
            return response()->json([
                'success' => false,
                'message' => $message,
                'errors' => $errors,
            ], $code);
        });
    }

    /**
     * Set application locale
     */
    protected function setLocale(): void
    {
        $user = auth()->user();
        
        if ($user && $user->locale) {
            app()->setLocale($user->locale);
        } else {
            // Set locale based on browser preference or default
            $locale = request()->getPreferredLanguage(['ar', 'en']) ?? config('app.locale');
            app()->setLocale($locale);
        }
    }

    /**
     * Get navigation items for the application
     */
    protected function getNavigationItems(): array
    {
        $user = auth()->user();
        
        $items = [
            [
                'title' => 'الرئيسية',
                'route' => 'home',
                'icon' => 'home',
                'active' => request()->routeIs('home'),
            ],
            [
                'title' => 'الأسعار',
                'route' => 'pricing',
                'icon' => 'tag',
                'active' => request()->routeIs('pricing'),
            ],
        ];

        if ($user) {
            $items[] = [
                'title' => 'لوحة التحكم',
                'route' => 'dashboard',
                'icon' => 'dashboard',
                'active' => request()->routeIs('dashboard*'),
            ];

            if ($user->hasActiveSubscription()) {
                if ($user->hasFeature('google_integration')) {
                    $items[] = [
                        'title' => 'التحليلات',
                        'route' => 'dashboard.analytics',
                        'icon' => 'chart-line',
                        'active' => request()->routeIs('dashboard.analytics*'),
                    ];
                }

                if ($user->hasFeature('platform_integration')) {
                    $items[] = [
                        'title' => 'الربط',
                        'route' => 'integrations.index',
                        'icon' => 'link',
                        'active' => request()->routeIs('integrations*'),
                    ];
                }
            }

            if ($user->can('access-admin-panel')) {
                $items[] = [
                    'title' => 'الإدارة',
                    'route' => 'admin.dashboard',
                    'icon' => 'cog',
                    'active' => request()->routeIs('admin*'),
                ];
            }
        }

        return $items;
    }
}

