<?php

namespace App\Providers;

use App\Models\User;
use App\Models\Website;
use App\Models\Payment;
use App\Models\UserSubscription;
use App\Policies\UserPolicy;
use App\Policies\WebsitePolicy;
use App\Policies\PaymentPolicy;
use App\Policies\SubscriptionPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use Laravel\Sanctum\Sanctum;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        User::class => UserPolicy::class,
        Website::class => WebsitePolicy::class,
        Payment::class => PaymentPolicy::class,
        UserSubscription::class => SubscriptionPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        // Configure Sanctum
        Sanctum::usePersonalAccessTokenModel(\Laravel\Sanctum\PersonalAccessToken::class);

        // Define additional gates
        $this->defineGates();

        // Define super admin gate
        Gate::before(function ($user, $ability) {
            if ($user->email === 'admin@saudiseopro.com') {
                return true;
            }
        });
    }

    /**
     * Define authorization gates
     */
    protected function defineGates(): void
    {
        // Admin gates
        Gate::define('viewAny-users', function (User $user) {
            return $user->can('access-admin-panel');
        });

        Gate::define('create-users', function (User $user) {
            return $user->can('access-admin-panel');
        });

        Gate::define('update-users', function (User $user, User $targetUser) {
            return $user->can('access-admin-panel') || $user->id === $targetUser->id;
        });

        Gate::define('delete-users', function (User $user, User $targetUser) {
            return $user->can('access-admin-panel') && $user->id !== $targetUser->id;
        });

        // Subscription gates
        Gate::define('viewAny-subscriptions', function (User $user) {
            return $user->can('access-admin-panel');
        });

        Gate::define('create-subscriptions', function (User $user) {
            return $user->can('access-admin-panel');
        });

        Gate::define('update-subscriptions', function (User $user) {
            return $user->can('access-admin-panel');
        });

        Gate::define('delete-subscriptions', function (User $user) {
            return $user->can('access-admin-panel');
        });

        // Website gates
        Gate::define('create-websites', function (User $user) {
            if (!$user->hasActiveSubscription()) {
                return false;
            }

            $subscription = $user->subscription->subscription;
            $currentCount = $user->websites()->count();

            return $subscription->hasUnlimitedWebsites() || 
                   $currentCount < $subscription->max_websites;
        });

        Gate::define('view-website', function (User $user, Website $website) {
            return $user->id === $website->user_id || $user->can('access-admin-panel');
        });

        Gate::define('update-website', function (User $user, Website $website) {
            return $user->id === $website->user_id;
        });

        Gate::define('delete-website', function (User $user, Website $website) {
            return $user->id === $website->user_id;
        });

        // Payment gates
        Gate::define('view-payment', function (User $user, Payment $payment) {
            return $user->id === $payment->user_id || $user->can('access-admin-panel');
        });

        Gate::define('refund-payment', function (User $user, Payment $payment) {
            return $user->can('access-admin-panel') && $payment->canBeRefunded();
        });

        // Integration gates
        Gate::define('connect-google', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('google_integration');
        });

        Gate::define('connect-platforms', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('platform_integration');
        });

        Gate::define('use-ai-features', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('content_optimization');
        });

        Gate::define('access-api', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('api_access');
        });

        Gate::define('export-keywords', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('google_integration');
        });

        Gate::define('view-competitor-analysis', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('competitor_analysis');
        });

        Gate::define('track-rankings', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('rank_tracking');
        });

        Gate::define('analyze-backlinks', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('backlink_analysis');
        });

        Gate::define('technical-seo-audit', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('technical_seo');
        });

        Gate::define('white-label-access', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('white_label');
        });

        Gate::define('priority-support', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('priority_support');
        });

        Gate::define('custom-reports', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('custom_reports');
        });

        // Rate limiting gates
        Gate::define('api-rate-limit', function (User $user) {
            if (!$user->hasActiveSubscription()) {
                return 'guest'; // 10 requests per minute
            }

            if ($user->hasFeature('api_access')) {
                return 'premium'; // 1000 requests per minute
            }

            return 'basic'; // 100 requests per minute
        });

        // Data export gates
        Gate::define('export-analytics', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('google_integration');
        });

        Gate::define('bulk-operations', function (User $user) {
            return $user->hasActiveSubscription() && 
                   $user->hasFeature('api_access');
        });

        // Feature usage limits
        Gate::define('check-website-limit', function (User $user) {
            if (!$user->hasActiveSubscription()) {
                return false;
            }

            $subscription = $user->subscription->subscription;
            $currentCount = $user->websites()->count();

            return $subscription->hasUnlimitedWebsites() || 
                   $currentCount < $subscription->max_websites;
        });

        Gate::define('check-keyword-limit', function (User $user, int $additionalKeywords = 1) {
            if (!$user->hasActiveSubscription()) {
                return false;
            }

            $subscription = $user->subscription->subscription;
            $currentCount = $user->websites()->sum('keywords_count');

            return $subscription->hasUnlimitedKeywords() || 
                   ($currentCount + $additionalKeywords) <= $subscription->max_keywords;
        });

        Gate::define('check-integration-limit', function (User $user) {
            if (!$user->hasActiveSubscription()) {
                return false;
            }

            $subscription = $user->subscription->subscription;
            $currentCount = $user->platformTokens()->where('status', 'active')->count();

            return $subscription->hasUnlimitedIntegrations() || 
                   $currentCount < $subscription->max_integrations;
        });
    }
}

