<?php

namespace App\Providers;

use Laravel\Telescope\TelescopeServiceProvider as BaseServiceProvider;

class TelescopeServiceProvider extends BaseServiceProvider
{
    // Override methods if needed
}