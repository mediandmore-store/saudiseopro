<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'subscription_id',
        'payment_id',
        'session_id',
        'amount',
        'currency',
        'payment_method',
        'status',
        'payment_details',
        'failure_reason',
        'fee_amount',
        'net_amount',
        'invoice_number',
        'paid_at',
        'failed_at',
        'refunded_at',
        'refunded_amount',
        'refund_reason',
        'metadata',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'fee_amount' => 'decimal:2',
        'net_amount' => 'decimal:2',
        'refunded_amount' => 'decimal:2',
        'payment_details' => 'array',
        'metadata' => 'array',
        'paid_at' => 'datetime',
        'failed_at' => 'datetime',
        'refunded_at' => 'datetime',
    ];

    // Relationships
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    // Scopes
    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeFailed($query)
    {
        return $query->where('status', 'failed');
    }

    public function scopeRefunded($query)
    {
        return $query->where('status', 'refunded');
    }

    public function scopeByMethod($query, string $method)
    {
        return $query->where('payment_method', $method);
    }

    // Helper methods
    public function isCompleted(): bool
    {
        return $this->status === 'completed';
    }

    public function isPending(): bool
    {
        return $this->status === 'pending';
    }

    public function isFailed(): bool
    {
        return $this->status === 'failed';
    }

    public function isRefunded(): bool
    {
        return $this->status === 'refunded';
    }

    public function markAsCompleted(array $details = []): bool
    {
        return $this->update([
            'status' => 'completed',
            'paid_at' => now(),
            'payment_details' => array_merge($this->payment_details ?? [], $details),
        ]);
    }

    public function markAsFailed(string $reason = null, array $details = []): bool
    {
        return $this->update([
            'status' => 'failed',
            'failed_at' => now(),
            'failure_reason' => $reason,
            'payment_details' => array_merge($this->payment_details ?? [], $details),
        ]);
    }

    public function refund(float $amount = null, string $reason = null): bool
    {
        if (!$this->isCompleted()) {
            return false;
        }

        $refundAmount = $amount ?? $this->amount;
        
        if ($refundAmount > $this->amount) {
            return false;
        }

        return $this->update([
            'status' => 'refunded',
            'refunded_at' => now(),
            'refunded_amount' => $refundAmount,
            'refund_reason' => $reason,
        ]);
    }

    public function getFormattedAmount(): string
    {
        return number_format($this->amount, 2) . ' ' . $this->currency;
    }

    public function getPaymentMethodName(): string
    {
        return match ($this->payment_method) {
            'paypal' => 'PayPal',
            'credit_card' => 'بطاقة ائتمانية',
            'bank_transfer' => 'تحويل بنكي',
            'apple_pay' => 'Apple Pay',
            'stc_pay' => 'STC Pay',
            default => $this->payment_method,
        };
    }

    public function getStatusName(): string
    {
        return match ($this->status) {
            'pending' => 'في الانتظار',
            'completed' => 'مكتملة',
            'failed' => 'فاشلة',
            'cancelled' => 'ملغية',
            'refunded' => 'مستردة',
            default => $this->status,
        };
    }

    public function generateInvoiceNumber(): string
    {
        if ($this->invoice_number) {
            return $this->invoice_number;
        }

        $invoiceNumber = 'INV-' . date('Y') . '-' . str_pad($this->id, 6, '0', STR_PAD_LEFT);
        $this->update(['invoice_number' => $invoiceNumber]);
        
        return $invoiceNumber;
    }

    public function canBeRefunded(): bool
    {
        return $this->isCompleted() && 
               $this->refunded_amount < $this->amount &&
               $this->paid_at->diffInDays(now()) <= 30; // 30 days refund policy
    }

    public function getRemainingRefundAmount(): float
    {
        return $this->amount - $this->refunded_amount;
    }
}

