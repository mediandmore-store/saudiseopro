<?php $__env->startSection('title', 'لوحة التحكم - Saudi SEO Pro'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-1">مرحباً، <?php echo e($user->name); ?></h1>
                    <p class="text-muted mb-0">إليك نظرة عامة على أداء مواقعك</p>
                </div>
                <div>
                    <?php if($subscription): ?>
                        <span class="badge bg-success fs-6">
                            <i class="fas fa-crown me-1"></i>
                            <?php echo e($subscription->subscription->name); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Subscription Status -->
    <?php if($subscription): ?>
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h6 class="fw-bold mb-1">حالة الاشتراك</h6>
                                <p class="text-muted mb-0">
                                    خطة <?php echo e($subscription->subscription->name); ?> - 
                                    <?php if($subscription->expires_at): ?>
                                        ينتهي في <?php echo e($subscription->expires_at->format('d/m/Y')); ?>

                                        (<?php echo e($subscription->daysUntilExpiry()); ?> يوم متبقي)
                                    <?php else: ?>
                                        اشتراك دائم
                                    <?php endif; ?>
                                </p>
                            </div>
                            <div class="col-md-4 text-md-end">
                                <a href="<?php echo e(route('pricing')); ?>" class="btn btn-outline-primary">
                                    <i class="fas fa-upgrade me-1"></i>
                                    ترقية الخطة
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Overview Cards -->
    <div class="row g-4 mb-4">
        <div class="col-lg-3 col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                                <i class="fas fa-globe text-primary fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">المواقع</h6>
                            <h3 class="fw-bold mb-0"><?php echo e($seoOverview['total_websites']); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-success bg-opacity-10 rounded-circle p-3">
                                <i class="fas fa-chart-line text-success fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">متوسط نقاط SEO</h6>
                            <h3 class="fw-bold mb-0"><?php echo e($seoOverview['average_score']); ?>/100</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-info bg-opacity-10 rounded-circle p-3">
                                <i class="fas fa-key text-info fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">الكلمات المتتبعة</h6>
                            <h3 class="fw-bold mb-0"><?php echo e(number_format($seoOverview['total_keywords'])); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-warning bg-opacity-10 rounded-circle p-3">
                                <i class="fas fa-exclamation-triangle text-warning fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">المشاكل المكتشفة</h6>
                            <h3 class="fw-bold mb-0"><?php echo e($seoOverview['issues_count']); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Websites List -->
        <div class="col-lg-8 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="fw-bold mb-0">مواقعي</h5>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-websites')): ?>
                            <a href="#" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addWebsiteModal">
                                <i class="fas fa-plus me-1"></i>
                                إضافة موقع
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if($websites->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>الموقع</th>
                                        <th>نقاط SEO</th>
                                        <th>الحالة</th>
                                        <th>آخر فحص</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <img src="https://www.google.com/s2/favicons?domain=<?php echo e($website->domain); ?>" 
                                                             alt="<?php echo e($website->name); ?>" width="20" height="20" class="me-2">
                                                    </div>
                                                    <div>
                                                        <h6 class="mb-0"><?php echo e($website->name); ?></h6>
                                                        <small class="text-muted"><?php echo e($website->domain); ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="progress me-2" style="width: 60px; height: 8px;">
                                                        <div class="progress-bar 
                                                            <?php if($website->overall_seo_score >= 80): ?> bg-success
                                                            <?php elseif($website->overall_seo_score >= 60): ?> bg-warning
                                                            <?php else: ?> bg-danger
                                                            <?php endif; ?>" 
                                                            style="width: <?php echo e($website->overall_seo_score); ?>%"></div>
                                                    </div>
                                                    <span class="fw-bold"><?php echo e($website->overall_seo_score); ?>/100</span>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge 
                                                    <?php if($website->is_verified): ?> bg-success
                                                    <?php else: ?> bg-warning
                                                    <?php endif; ?>">
                                                    <?php echo e($website->is_verified ? 'مؤكد' : 'غير مؤكد'); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <?php if($website->last_crawled_at): ?>
                                                    <?php echo e($website->last_crawled_at->diffForHumans()); ?>

                                                <?php else: ?>
                                                    <span class="text-muted">لم يتم الفحص</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="#" class="btn btn-outline-primary">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="#" class="btn btn-outline-secondary">
                                                        <i class="fas fa-cog"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-globe fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">لا توجد مواقع مضافة</h5>
                            <p class="text-muted mb-3">ابدأ بإضافة موقعك الأول لتحليل أدائه</p>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-websites')): ?>
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addWebsiteModal">
                                    <i class="fas fa-plus me-1"></i>
                                    إضافة موقع جديد
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Integrations -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <h6 class="fw-bold mb-0">الربط والتكامل</h6>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fab fa-google text-danger me-2"></i>
                            <span>Google Analytics</span>
                        </div>
                        <?php if($integrations['google']): ?>
                            <span class="badge bg-success">متصل</span>
                        <?php else: ?>
                            <a href="<?php echo e(route('google.connect')); ?>" class="btn btn-sm btn-outline-primary">ربط</a>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-shopping-cart text-primary me-2"></i>
                            <span>سلة</span>
                        </div>
                        <?php if($integrations['salla']): ?>
                            <span class="badge bg-success">متصل</span>
                        <?php else: ?>
                            <a href="<?php echo e(route('integrations.salla.connect')); ?>" class="btn btn-sm btn-outline-primary">ربط</a>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-store text-info me-2"></i>
                            <span>زد</span>
                        </div>
                        <?php if($integrations['zid']): ?>
                            <span class="badge bg-success">متصل</span>
                        <?php else: ?>
                            <a href="#" class="btn btn-sm btn-outline-primary">ربط</a>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fab fa-shopify text-success me-2"></i>
                            <span>Shopify</span>
                        </div>
                        <?php if($integrations['shopify']): ?>
                            <span class="badge bg-success">متصل</span>
                        <?php else: ?>
                            <a href="#" class="btn btn-sm btn-outline-primary">ربط</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <h6 class="fw-bold mb-0">النشاط الأخير</h6>
                </div>
                <div class="card-body">
                    <?php if(count($recentActivity) > 0): ?>
                        <?php $__currentLoopData = $recentActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-start mb-3">
                                <div class="flex-shrink-0">
                                    <div class="bg-light rounded-circle p-2">
                                        <i class="fas fa-<?php echo e($activity['icon']); ?> text-muted"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <p class="mb-1 small"><?php echo e($activity['title']); ?></p>
                                    <small class="text-muted"><?php echo e($activity['time']->diffForHumans()); ?></small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <i class="fas fa-clock fa-2x text-muted mb-2"></i>
                            <p class="text-muted mb-0">لا يوجد نشاط حديث</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Website Modal -->
<div class="modal fade" id="addWebsiteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">إضافة موقع جديد</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="#" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="website_name" class="form-label">اسم الموقع</label>
                        <input type="text" class="form-control" id="website_name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="website_url" class="form-label">رابط الموقع</label>
                        <input type="url" class="form-control" id="website_url" name="url" 
                               placeholder="https://example.com" required>
                    </div>
                    <div class="mb-3">
                        <label for="website_type" class="form-label">نوع الموقع</label>
                        <select class="form-select" id="website_type" name="type">
                            <option value="ecommerce">متجر إلكتروني</option>
                            <option value="blog">مدونة</option>
                            <option value="corporate">موقع شركة</option>
                            <option value="portfolio">معرض أعمال</option>
                            <option value="other">أخرى</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-primary">إضافة الموقع</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Auto-refresh data every 5 minutes
    setInterval(function() {
        location.reload();
    }, 300000);
    
    // Track website additions
    document.getElementById('addWebsiteModal').addEventListener('submit', function() {
        if (typeof gtag !== 'undefined') {
            gtag('event', 'website_added', {
                'event_category': 'Dashboard',
                'event_label': 'Add Website',
                'value': 1
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/saudi-seo-pro-complete/resources/views/dashboard.blade.php ENDPATH**/ ?>