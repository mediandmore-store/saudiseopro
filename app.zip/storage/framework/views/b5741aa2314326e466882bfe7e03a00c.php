<?php $__env->startSection('title', 'Saudi SEO Pro - أداة تحسين محركات البحث الأولى في السعودية'); ?>
<?php $__env->startSection('description', 'حسن ترتيب موقعك في محركات البحث مع Saudi SEO Pro. ربط مع Google Analytics، تحليل المنافسين، وتحسين المحتوى بالذكاء الاصطناعي.'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="hero-section py-5">
    <div class="container">
        <div class="row align-items-center min-vh-75">
            <div class="col-lg-6 mb-5 mb-lg-0">
                <h1 class="display-4 fw-bold mb-4">
                    حسن ترتيب موقعك في محركات البحث
                </h1>
                <p class="lead mb-4">
                    أداة تحسين محركات البحث الأولى في السعودية. ربط مع Google Analytics، تحليل المنافسين، وتحسين المحتوى بالذكاء الاصطناعي.
                </p>
                <div class="d-flex flex-column flex-sm-row gap-3">
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-light btn-lg px-4">
                        <i class="fas fa-rocket me-2"></i>
                        ابدأ مجاناً
                    </a>
                    <a href="<?php echo e(route('pricing')); ?>" class="btn btn-outline-light btn-lg px-4">
                        <i class="fas fa-eye me-2"></i>
                        شاهد الأسعار
                    </a>
                </div>
                
                <!-- Stats -->
                <div class="row mt-5">
                    <div class="col-4">
                        <div class="text-center">
                            <h3 class="fw-bold"><?php echo e(number_format($stats['users_count'])); ?>+</h3>
                            <small>مستخدم نشط</small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="text-center">
                            <h3 class="fw-bold"><?php echo e(number_format($stats['websites_count'])); ?>+</h3>
                            <small>موقع محلل</small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="text-center">
                            <h3 class="fw-bold"><?php echo e(number_format($stats['keywords_tracked'])); ?>+</h3>
                            <small>كلمة متتبعة</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="text-center">
                    <img src="<?php echo e(asset('images/hero-dashboard.png')); ?>" alt="Saudi SEO Pro Dashboard" class="img-fluid rounded shadow-lg">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold mb-3">ميزات قوية لتحسين موقعك</h2>
            <p class="lead text-muted">
                كل ما تحتاجه لتحسين ترتيب موقعك في محركات البحث
            </p>
        </div>
        
        <div class="row g-4">
            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-start">
                                <div class="flex-shrink-0">
                                    <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                                        <i class="fas fa-<?php echo e($feature['icon']); ?> text-primary fa-lg"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5 class="fw-bold mb-2"><?php echo e($feature['title']); ?></h5>
                                    <p class="text-muted mb-3"><?php echo e($feature['description']); ?></p>
                                    <ul class="list-unstyled">
                                        <?php $__currentLoopData = $feature['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="mb-1">
                                                <i class="fas fa-check text-success me-2"></i>
                                                <?php echo e($item); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Pricing Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold mb-3">خطط أسعار مرنة</h2>
            <p class="lead text-muted">
                اختر الخطة المناسبة لاحتياجاتك
            </p>
        </div>
        
        <div class="row g-4 justify-content-center">
            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card h-100 border-0 shadow-sm <?php echo e($subscription->is_popular ? 'border-primary' : ''); ?>">
                        <?php if($subscription->is_popular): ?>
                            <div class="card-header bg-primary text-white text-center py-2">
                                <small class="fw-bold">الأكثر شعبية</small>
                            </div>
                        <?php endif; ?>
                        
                        <div class="card-body p-4 text-center">
                            <h4 class="fw-bold mb-3"><?php echo e($subscription->name); ?></h4>
                            <div class="mb-4">
                                <span class="display-4 fw-bold text-primary"><?php echo e(number_format($subscription->price)); ?></span>
                                <span class="text-muted">ر.س / شهر</span>
                            </div>
                            
                            <ul class="list-unstyled mb-4">
                                <?php $__currentLoopData = $subscription->getFeatureList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="mb-2">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <?php echo e($feature); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            
                            <a href="<?php echo e(route('register')); ?>?plan=<?php echo e($subscription->id); ?>" 
                               class="btn <?php echo e($subscription->is_popular ? 'btn-primary' : 'btn-outline-primary'); ?> w-100">
                                ابدأ الآن
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="<?php echo e(route('pricing')); ?>" class="btn btn-link">
                عرض جميع الخطط والميزات
                <i class="fas fa-arrow-left ms-1"></i>
            </a>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold mb-3">ماذا يقول عملاؤنا</h2>
            <p class="lead text-muted">
                آراء حقيقية من عملاء راضين
            </p>
        </div>
        
        <div class="row g-4">
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body p-4">
                            <div class="mb-3">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star <?php echo e($i <= $testimonial['rating'] ? 'text-warning' : 'text-muted'); ?>"></i>
                                <?php endfor; ?>
                            </div>
                            
                            <p class="mb-4">"<?php echo e($testimonial['text']); ?>"</p>
                            
                            <div class="d-flex align-items-center">
                                <img src="<?php echo e($testimonial['image']); ?>" alt="<?php echo e($testimonial['name']); ?>" 
                                     class="rounded-circle me-3" width="50" height="50">
                                <div>
                                    <h6 class="fw-bold mb-0"><?php echo e($testimonial['name']); ?></h6>
                                    <small class="text-muted"><?php echo e($testimonial['company']); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-5 bg-primary text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h3 class="fw-bold mb-2">جاهز لتحسين ترتيب موقعك؟</h3>
                <p class="mb-0">ابدأ مجاناً واكتشف كيف يمكن لـ Saudi SEO Pro مساعدتك في الوصول للصفحة الأولى</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-light btn-lg px-4">
                    <i class="fas fa-rocket me-2"></i>
                    ابدأ مجاناً الآن
                </a>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
    
    // Track CTA clicks
    document.querySelectorAll('a[href*="register"]').forEach(link => {
        link.addEventListener('click', function() {
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click', {
                    'event_category': 'CTA',
                    'event_label': 'Register Button',
                    'value': 1
                });
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/saudi-seo-pro-complete/resources/views/home.blade.php ENDPATH**/ ?>