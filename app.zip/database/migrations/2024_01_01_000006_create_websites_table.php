<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('websites', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->string('url');
            $table->string('domain');
            $table->enum('type', ['ecommerce', 'blog', 'corporate', 'portfolio', 'other'])->default('other');
            $table->string('platform')->nullable(); // WordPress, Shopify, etc.
            $table->json('settings')->nullable(); // Website-specific settings
            $table->boolean('is_verified')->default(false);
            $table->string('verification_method')->nullable(); // HTML file, meta tag, DNS
            $table->string('verification_token')->nullable();
            $table->timestamp('verified_at')->nullable();
            $table->boolean('is_active')->default(true);
            $table->json('seo_score')->nullable(); // Overall SEO score breakdown
            $table->timestamp('last_crawled_at')->nullable();
            $table->json('crawl_status')->nullable(); // Last crawl results
            $table->integer('pages_count')->default(0);
            $table->integer('keywords_count')->default(0);
            $table->timestamps();
            
            // Indexes
            $table->index(['user_id', 'is_active']);
            $table->index('domain');
            $table->index('is_verified');
            $table->index('last_crawled_at');
            
            // Unique constraint for domain per user
            $table->unique(['user_id', 'domain']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('websites');
    }
};

