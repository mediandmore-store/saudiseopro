<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('subscriptions', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->decimal('price', 10, 2);
            $table->enum('billing_cycle', ['monthly', 'quarterly', 'yearly'])->default('monthly');
            $table->json('features');
            $table->integer('max_websites')->default(1);
            $table->integer('max_keywords')->default(100);
            $table->integer('max_integrations')->default(1);
            $table->boolean('google_integration')->default(false);
            $table->boolean('platform_integration')->default(false);
            $table->boolean('keyword_analysis')->default(false);
            $table->boolean('content_optimization')->default(false);
            $table->boolean('competitor_analysis')->default(false);
            $table->boolean('rank_tracking')->default(false);
            $table->boolean('backlink_analysis')->default(false);
            $table->boolean('technical_seo')->default(false);
            $table->boolean('white_label')->default(false);
            $table->boolean('api_access')->default(false);
            $table->boolean('priority_support')->default(false);
            $table->boolean('custom_reports')->default(false);
            $table->boolean('is_active')->default(true);
            $table->boolean('is_popular')->default(false);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
            
            // Indexes
            $table->index(['is_active', 'sort_order']);
            $table->index('price');
            $table->index('billing_cycle');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('subscriptions');
    }
};

