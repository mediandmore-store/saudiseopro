<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('platform_tokens', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->enum('platform', ['salla', 'zid', 'shopify', 'woocommerce', 'google']);
            $table->string('store_id')->nullable(); // Platform-specific store identifier
            $table->string('store_name')->nullable();
            $table->string('store_url')->nullable();
            $table->text('access_token'); // Encrypted
            $table->text('refresh_token')->nullable(); // Encrypted
            $table->timestamp('expires_at')->nullable();
            $table->json('scopes')->nullable(); // Granted permissions
            $table->json('store_info')->nullable(); // Additional store metadata
            $table->enum('status', ['active', 'expired', 'revoked', 'error'])->default('active');
            $table->timestamp('last_sync_at')->nullable();
            $table->json('sync_status')->nullable(); // Last sync results
            $table->integer('sync_count')->default(0);
            $table->timestamp('last_used_at')->nullable();
            $table->timestamps();
            
            // Indexes
            $table->index(['user_id', 'platform']);
            $table->index(['platform', 'status']);
            $table->index('expires_at');
            $table->index('last_sync_at');
            
            // Unique constraint to prevent duplicate platform connections per user
            $table->unique(['user_id', 'platform', 'store_id'], 'unique_user_platform_store');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('platform_tokens');
    }
};

