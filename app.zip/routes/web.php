<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\IntegrationController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\GoogleAuthController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Public routes
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', [HomeController::class, 'about'])->name('about');
Route::get('/features', [HomeController::class, 'features'])->name('features');
Route::get('/contact', [HomeController::class, 'contact'])->name('contact');
Route::post('/contact', [HomeController::class, 'submitContact'])->name('contact.submit');
Route::get('/privacy', [HomeController::class, 'privacy'])->name('privacy');
Route::get('/terms', [HomeController::class, 'terms'])->name('terms');
Route::get('/faq', [HomeController::class, 'faq'])->name('faq');

// Newsletter subscription
Route::post('/newsletter/subscribe', [HomeController::class, 'subscribeNewsletter'])->name('newsletter.subscribe');

// Pricing and subscription plans
Route::get('/pricing', [SubscriptionController::class, 'showPlans'])->name('pricing');
Route::get('/subscription/{subscription}', [SubscriptionController::class, 'show'])->name('subscription.show');

// Authentication routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.submit');
    Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.submit');
    
    // Password reset routes
    Route::get('/forgot-password', [AuthController::class, 'showLinkRequestForm'])->name('password.request');
    Route::post('/forgot-password', [AuthController::class, 'sendResetLinkEmail'])->name('password.email');
    Route::get('/reset-password/{token}', [AuthController::class, 'showResetForm'])->name('password.reset');
    Route::post('/reset-password', [AuthController::class, 'reset'])->name('password.update');
});

// Authenticated routes
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    
    // Email verification routes
    Route::get('/email/verify', function () {
        return view('auth.verify-email');
    })->name('verification.notice');
    
    Route::get('/email/verify/{id}/{hash}', [AuthController::class, 'verify'])
        ->middleware(['signed', 'throttle:6,1'])
        ->name('verification.verify');
    
    Route::post('/email/verification-notification', [AuthController::class, 'resend'])
        ->middleware('throttle:6,1')
        ->name('verification.send');
});

// Subscription management routes
Route::middleware(['auth', 'verified'])->group(function () {
    Route::post('/subscribe', [SubscriptionController::class, 'subscribe'])->name('subscription.subscribe');
    Route::put('/subscription/upgrade', [SubscriptionController::class, 'upgrade'])->name('subscription.upgrade');
    Route::put('/subscription/downgrade', [SubscriptionController::class, 'downgrade'])->name('subscription.downgrade');
    Route::delete('/subscription/cancel', [SubscriptionController::class, 'cancel'])->name('subscription.cancel');
    Route::get('/subscription/history', [SubscriptionController::class, 'history'])->name('subscription.history');
    Route::get('/subscription/invoice/{payment}', [SubscriptionController::class, 'downloadInvoice'])->name('subscription.invoice');
});

// Payment callback routes
Route::get('/payment/success', [SubscriptionController::class, 'paymentSuccess'])->name('subscription.payment.success');
Route::get('/payment/cancel', [SubscriptionController::class, 'paymentFailed'])->name('subscription.payment.cancel');
Route::get('/payment/failed', [SubscriptionController::class, 'paymentFailed'])->name('subscription.payment.failed');

// Dashboard routes (requires active subscription)
Route::middleware(['auth', 'verified', 'subscription'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/analytics', [DashboardController::class, 'analytics'])->name('dashboard.analytics');
    Route::get('/dashboard/seo-overview', [DashboardController::class, 'seoOverview'])->name('dashboard.seo-overview');
    Route::get('/dashboard/keywords', [DashboardController::class, 'keywordTracking'])->name('dashboard.keywords');
    Route::get('/dashboard/competitors', [DashboardController::class, 'competitorAnalysis'])->name('dashboard.competitors');
});

// Integration routes (requires platform integration feature)
Route::middleware(['auth', 'verified', 'subscription:platform_integration'])->prefix('integrations')->name('integrations.')->group(function () {
    Route::get('/', [IntegrationController::class, 'index'])->name('index');
    
    // Salla integration
    Route::get('/salla/connect', [IntegrationController::class, 'connectSalla'])->name('salla.connect');
    Route::get('/salla/callback', [IntegrationController::class, 'handleSallaCallback'])->name('salla.callback');
    
    // Zid integration
    Route::get('/zid/connect', [IntegrationController::class, 'connectZid'])->name('zid.connect');
    Route::get('/zid/callback', [IntegrationController::class, 'handleZidCallback'])->name('zid.callback');
    
    // Shopify integration
    Route::get('/shopify/connect', [IntegrationController::class, 'connectShopify'])->name('shopify.connect');
    Route::get('/shopify/callback', [IntegrationController::class, 'handleShopifyCallback'])->name('shopify.callback');
    
    // Platform management
    Route::delete('/platform/{platform}', [IntegrationController::class, 'disconnectPlatform'])->name('platform.disconnect');
    Route::post('/platform/{platform}/sync', [IntegrationController::class, 'syncPlatform'])->name('platform.sync');
    Route::get('/platform/{platform}/test', [IntegrationController::class, 'testConnection'])->name('platform.test');
});

// Google integration routes (requires Google integration feature)
Route::middleware(['auth', 'verified', 'subscription:google_integration'])->prefix('google')->name('google.')->group(function () {
    Route::get('/connect', [GoogleAuthController::class, 'redirectToGoogle'])->name('connect');
    Route::get('/callback', [GoogleAuthController::class, 'handleGoogleCallback'])->name('callback');
    Route::delete('/disconnect', [GoogleAuthController::class, 'disconnectGoogle'])->name('disconnect');
    Route::get('/test', [GoogleAuthController::class, 'testConnection'])->name('test');
    Route::post('/refresh-tokens', [GoogleAuthController::class, 'refreshTokens'])->name('refresh-tokens');
    
    // Google services
    Route::get('/analytics/accounts', [GoogleAuthController::class, 'getAnalyticsAccounts'])->name('analytics.accounts');
    Route::get('/search-console/sites', [GoogleAuthController::class, 'getSearchConsoleSites'])->name('search-console.sites');
    Route::post('/export-to-sheets', [GoogleAuthController::class, 'exportToSheets'])->name('export-to-sheets');
});

// Admin routes (for future admin panel)
Route::middleware(['auth', 'verified', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', function () {
        return view('admin.dashboard');
    })->name('dashboard');
    
    Route::get('/users', function () {
        return view('admin.users');
    })->name('users');
    
    Route::get('/subscriptions', function () {
        return view('admin.subscriptions');
    })->name('subscriptions');
    
    Route::get('/analytics', function () {
        return view('admin.analytics');
    })->name('analytics');
});

// Webhook routes (for platform integrations)
Route::prefix('webhooks')->name('webhooks.')->group(function () {
    Route::post('/salla', function () {
        // Handle Salla webhooks
        return response()->json(['status' => 'ok']);
    })->name('salla');
    
    Route::post('/zid', function () {
        // Handle Zid webhooks
        return response()->json(['status' => 'ok']);
    })->name('zid');
    
    Route::post('/shopify', function () {
        // Handle Shopify webhooks
        return response()->json(['status' => 'ok']);
    })->name('shopify');
});

// Health check and status routes
Route::get('/health', function () {
    return response()->json([
        'status' => 'ok',
        'timestamp' => now()->toISOString(),
        'version' => config('app.version', '1.0.0'),
    ]);
})->name('health');

Route::get('/status', function () {
    return response()->json([
        'app' => 'Saudi SEO Pro',
        'status' => 'operational',
        'database' => 'connected',
        'cache' => 'operational',
        'queue' => 'operational',
    ]);
})->name('status');

// Sitemap route
Route::get('/sitemap.xml', function () {
    return response()->view('sitemap', [], 200, [
        'Content-Type' => 'application/xml'
    ]);
})->name('sitemap');

// Robots.txt route
Route::get('/robots.txt', function () {
    return response()->view('robots', [], 200, [
        'Content-Type' => 'text/plain'
    ]);
})->name('robots');

// Fallback route for SPA-like behavior (if needed)
Route::fallback(function () {
    return response()->view('errors.404', [], 404);
});

