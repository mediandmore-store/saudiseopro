<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\SubscriptionController;
use App\Http\Controllers\Api\IntegrationController;
use App\Http\Controllers\Api\AnalyticsController;
use App\Http\Controllers\Api\KeywordController;
use App\Http\Controllers\Api\SEOController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// API version prefix
Route::prefix('v1')->group(function () {
    
    // Public API routes
    Route::get('/status', function () {
        return response()->json([
            'status' => 'ok',
            'version' => '1.0.0',
            'timestamp' => now()->toISOString(),
        ]);
    });

    Route::get('/pricing', function () {
        return response()->json([
            'plans' => \App\Models\Subscription::active()->get(),
        ]);
    });

    // Authentication routes
    Route::prefix('auth')->group(function () {
        Route::post('/login', [AuthController::class, 'login']);
        Route::post('/register', [AuthController::class, 'register']);
        Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
        Route::post('/reset-password', [AuthController::class, 'resetPassword']);
        Route::post('/verify-email', [AuthController::class, 'verifyEmail']);
        Route::post('/resend-verification', [AuthController::class, 'resendVerification']);
        
        // Authenticated auth routes
        Route::middleware('auth:sanctum')->group(function () {
            Route::post('/logout', [AuthController::class, 'logout']);
            Route::get('/user', [AuthController::class, 'user']);
            Route::put('/user', [AuthController::class, 'updateUser']);
            Route::put('/password', [AuthController::class, 'updatePassword']);
        });
    });

    // Protected API routes
    Route::middleware(['auth:sanctum', 'verified'])->group(function () {
        
        // User profile routes
        Route::get('/user', function (Request $request) {
            return $request->user()->load('subscription', 'platformTokens');
        });

        // Subscription management
        Route::prefix('subscriptions')->group(function () {
            Route::get('/', [SubscriptionController::class, 'index']);
            Route::get('/current', [SubscriptionController::class, 'current']);
            Route::post('/subscribe', [SubscriptionController::class, 'subscribe']);
            Route::put('/upgrade', [SubscriptionController::class, 'upgrade']);
            Route::put('/downgrade', [SubscriptionController::class, 'downgrade']);
            Route::delete('/cancel', [SubscriptionController::class, 'cancel']);
            Route::get('/history', [SubscriptionController::class, 'history']);
            Route::get('/usage', [SubscriptionController::class, 'usage']);
        });

        // Integration management (requires platform integration feature)
        Route::middleware('subscription:platform_integration')->prefix('integrations')->group(function () {
            Route::get('/', [IntegrationController::class, 'index']);
            Route::get('/platforms', [IntegrationController::class, 'availablePlatforms']);
            
            // Platform-specific routes
            Route::prefix('salla')->group(function () {
                Route::get('/auth-url', [IntegrationController::class, 'getSallaAuthUrl']);
                Route::post('/connect', [IntegrationController::class, 'connectSalla']);
                Route::delete('/disconnect', [IntegrationController::class, 'disconnectSalla']);
                Route::get('/products', [IntegrationController::class, 'getSallaProducts']);
                Route::put('/products/{id}/seo', [IntegrationController::class, 'updateSallaProductSEO']);
                Route::post('/sync', [IntegrationController::class, 'syncSallaData']);
            });
            
            Route::prefix('zid')->group(function () {
                Route::get('/auth-url', [IntegrationController::class, 'getZidAuthUrl']);
                Route::post('/connect', [IntegrationController::class, 'connectZid']);
                Route::delete('/disconnect', [IntegrationController::class, 'disconnectZid']);
                Route::get('/products', [IntegrationController::class, 'getZidProducts']);
                Route::put('/products/{id}/seo', [IntegrationController::class, 'updateZidProductSEO']);
                Route::post('/sync', [IntegrationController::class, 'syncZidData']);
            });
            
            Route::prefix('shopify')->group(function () {
                Route::get('/auth-url', [IntegrationController::class, 'getShopifyAuthUrl']);
                Route::post('/connect', [IntegrationController::class, 'connectShopify']);
                Route::delete('/disconnect', [IntegrationController::class, 'disconnectShopify']);
                Route::get('/products', [IntegrationController::class, 'getShopifyProducts']);
                Route::put('/products/{id}/seo', [IntegrationController::class, 'updateShopifyProductSEO']);
                Route::post('/sync', [IntegrationController::class, 'syncShopifyData']);
            });
        });

        // Analytics routes (requires analytics feature)
        Route::middleware('subscription:keyword_analysis')->prefix('analytics')->group(function () {
            Route::get('/dashboard', [AnalyticsController::class, 'dashboard']);
            Route::get('/traffic', [AnalyticsController::class, 'traffic']);
            Route::get('/keywords', [AnalyticsController::class, 'keywords']);
            Route::get('/pages', [AnalyticsController::class, 'pages']);
            Route::get('/competitors', [AnalyticsController::class, 'competitors']);
            Route::get('/backlinks', [AnalyticsController::class, 'backlinks']);
            Route::get('/technical-seo', [AnalyticsController::class, 'technicalSEO']);
            
            // Export routes
            Route::post('/export/keywords', [AnalyticsController::class, 'exportKeywords']);
            Route::post('/export/report', [AnalyticsController::class, 'exportReport']);
        });

        // Keyword management routes
        Route::middleware('subscription:keyword_analysis')->prefix('keywords')->group(function () {
            Route::get('/', [KeywordController::class, 'index']);
            Route::post('/', [KeywordController::class, 'store']);
            Route::get('/{keyword}', [KeywordController::class, 'show']);
            Route::put('/{keyword}', [KeywordController::class, 'update']);
            Route::delete('/{keyword}', [KeywordController::class, 'destroy']);
            
            // Keyword analysis
            Route::post('/analyze', [KeywordController::class, 'analyze']);
            Route::post('/suggestions', [KeywordController::class, 'suggestions']);
            Route::post('/difficulty', [KeywordController::class, 'difficulty']);
            Route::post('/volume', [KeywordController::class, 'volume']);
            Route::post('/trends', [KeywordController::class, 'trends']);
            
            // Bulk operations
            Route::post('/bulk/import', [KeywordController::class, 'bulkImport']);
            Route::post('/bulk/export', [KeywordController::class, 'bulkExport']);
            Route::post('/bulk/analyze', [KeywordController::class, 'bulkAnalyze']);
        });

        // SEO tools routes
        Route::prefix('seo')->group(function () {
            Route::post('/analyze-url', [SEOController::class, 'analyzeUrl']);
            Route::post('/analyze-content', [SEOController::class, 'analyzeContent']);
            Route::post('/optimize-content', [SEOController::class, 'optimizeContent']);
            Route::post('/generate-meta', [SEOController::class, 'generateMeta']);
            Route::post('/check-duplicate', [SEOController::class, 'checkDuplicate']);
            Route::post('/suggest-improvements', [SEOController::class, 'suggestImprovements']);
            
            // Technical SEO
            Route::post('/technical-audit', [SEOController::class, 'technicalAudit']);
            Route::post('/page-speed', [SEOController::class, 'pageSpeed']);
            Route::post('/mobile-friendly', [SEOController::class, 'mobileFriendly']);
            Route::post('/schema-markup', [SEOController::class, 'schemaMarkup']);
        });

        // Google integration routes (requires Google integration feature)
        Route::middleware('subscription:google_integration')->prefix('google')->group(function () {
            Route::get('/auth-url', [GoogleAuthController::class, 'getAuthUrl']);
            Route::post('/connect', [GoogleAuthController::class, 'connect']);
            Route::delete('/disconnect', [GoogleAuthController::class, 'disconnect']);
            Route::get('/status', [GoogleAuthController::class, 'status']);
            
            // Google Analytics
            Route::prefix('analytics')->group(function () {
                Route::get('/accounts', [GoogleAuthController::class, 'getAnalyticsAccounts']);
                Route::get('/properties', [GoogleAuthController::class, 'getAnalyticsProperties']);
                Route::get('/data', [GoogleAuthController::class, 'getAnalyticsData']);
                Route::get('/reports', [GoogleAuthController::class, 'getAnalyticsReports']);
            });
            
            // Google Search Console
            Route::prefix('search-console')->group(function () {
                Route::get('/sites', [GoogleAuthController::class, 'getSearchConsoleSites']);
                Route::get('/performance', [GoogleAuthController::class, 'getSearchConsolePerformance']);
                Route::get('/keywords', [GoogleAuthController::class, 'getSearchConsoleKeywords']);
                Route::get('/pages', [GoogleAuthController::class, 'getSearchConsolePages']);
                Route::get('/issues', [GoogleAuthController::class, 'getSearchConsoleIssues']);
            });
            
            // Google Sheets export
            Route::post('/export-to-sheets', [GoogleAuthController::class, 'exportToSheets']);
        });

        // Webhook management routes
        Route::prefix('webhooks')->group(function () {
            Route::get('/', [WebhookController::class, 'index']);
            Route::post('/', [WebhookController::class, 'store']);
            Route::get('/{webhook}', [WebhookController::class, 'show']);
            Route::put('/{webhook}', [WebhookController::class, 'update']);
            Route::delete('/{webhook}', [WebhookController::class, 'destroy']);
            Route::post('/{webhook}/test', [WebhookController::class, 'test']);
        });

        // Reports routes
        Route::prefix('reports')->group(function () {
            Route::get('/', [ReportController::class, 'index']);
            Route::post('/generate', [ReportController::class, 'generate']);
            Route::get('/{report}', [ReportController::class, 'show']);
            Route::get('/{report}/download', [ReportController::class, 'download']);
            Route::delete('/{report}', [ReportController::class, 'destroy']);
        });

        // Settings routes
        Route::prefix('settings')->group(function () {
            Route::get('/', [SettingsController::class, 'index']);
            Route::put('/', [SettingsController::class, 'update']);
            Route::get('/notifications', [SettingsController::class, 'notifications']);
            Route::put('/notifications', [SettingsController::class, 'updateNotifications']);
        });
    });

    // Admin API routes
    Route::middleware(['auth:sanctum', 'verified', 'admin'])->prefix('admin')->group(function () {
        Route::get('/stats', [AdminController::class, 'stats']);
        Route::get('/users', [AdminController::class, 'users']);
        Route::get('/subscriptions', [AdminController::class, 'subscriptions']);
        Route::get('/payments', [AdminController::class, 'payments']);
        Route::get('/analytics', [AdminController::class, 'analytics']);
        
        // User management
        Route::prefix('users')->group(function () {
            Route::get('/{user}', [AdminController::class, 'showUser']);
            Route::put('/{user}', [AdminController::class, 'updateUser']);
            Route::delete('/{user}', [AdminController::class, 'deleteUser']);
            Route::post('/{user}/suspend', [AdminController::class, 'suspendUser']);
            Route::post('/{user}/activate', [AdminController::class, 'activateUser']);
        });
        
        // Subscription management
        Route::prefix('subscriptions')->group(function () {
            Route::post('/', [AdminController::class, 'createSubscription']);
            Route::put('/{subscription}', [AdminController::class, 'updateSubscription']);
            Route::delete('/{subscription}', [AdminController::class, 'deleteSubscription']);
        });
    });

    // Rate limited public endpoints
    Route::middleware('throttle:60,1')->group(function () {
        Route::post('/contact', [ContactController::class, 'submit']);
        Route::post('/newsletter/subscribe', [NewsletterController::class, 'subscribe']);
        Route::post('/feedback', [FeedbackController::class, 'submit']);
    });
});

// Webhook endpoints (no authentication required)
Route::prefix('webhooks')->group(function () {
    Route::post('/salla', [WebhookController::class, 'handleSalla']);
    Route::post('/zid', [WebhookController::class, 'handleZid']);
    Route::post('/shopify', [WebhookController::class, 'handleShopify']);
    Route::post('/paypal', [WebhookController::class, 'handlePayPal']);
    Route::post('/stripe', [WebhookController::class, 'handleStripe']);
});

// API documentation route
Route::get('/docs', function () {
    return response()->json([
        'message' => 'Saudi SEO Pro API Documentation',
        'version' => '1.0.0',
        'endpoints' => [
            'authentication' => '/api/v1/auth/*',
            'subscriptions' => '/api/v1/subscriptions/*',
            'integrations' => '/api/v1/integrations/*',
            'analytics' => '/api/v1/analytics/*',
            'keywords' => '/api/v1/keywords/*',
            'seo' => '/api/v1/seo/*',
            'google' => '/api/v1/google/*',
        ],
        'documentation_url' => config('app.url') . '/docs',
    ]);
});

// Fallback for undefined API routes
Route::fallback(function () {
    return response()->json([
        'error' => 'Endpoint not found',
        'message' => 'The requested API endpoint does not exist.',
    ], 404);
});

