@extends('layouts.app')

@section('title', 'لوحة التحكم - Saudi SEO Pro')

@section('content')
<div class="container-fluid py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-1">مرحباً، {{ $user->name }}</h1>
                    <p class="text-muted mb-0">إليك نظرة عامة على أداء مواقعك</p>
                </div>
                <div>
                    @if($subscription)
                        <span class="badge bg-success fs-6">
                            <i class="fas fa-crown me-1"></i>
                            {{ $subscription->subscription->name }}
                        </span>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Subscription Status -->
    @if($subscription)
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h6 class="fw-bold mb-1">حالة الاشتراك</h6>
                                <p class="text-muted mb-0">
                                    خطة {{ $subscription->subscription->name }} - 
                                    @if($subscription->expires_at)
                                        ينتهي في {{ $subscription->expires_at->format('d/m/Y') }}
                                        ({{ $subscription->daysUntilExpiry() }} يوم متبقي)
                                    @else
                                        اشتراك دائم
                                    @endif
                                </p>
                            </div>
                            <div class="col-md-4 text-md-end">
                                <a href="{{ route('pricing') }}" class="btn btn-outline-primary">
                                    <i class="fas fa-upgrade me-1"></i>
                                    ترقية الخطة
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <!-- Overview Cards -->
    <div class="row g-4 mb-4">
        <div class="col-lg-3 col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                                <i class="fas fa-globe text-primary fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">المواقع</h6>
                            <h3 class="fw-bold mb-0">{{ $seoOverview['total_websites'] }}</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-success bg-opacity-10 rounded-circle p-3">
                                <i class="fas fa-chart-line text-success fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">متوسط نقاط SEO</h6>
                            <h3 class="fw-bold mb-0">{{ $seoOverview['average_score'] }}/100</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-info bg-opacity-10 rounded-circle p-3">
                                <i class="fas fa-key text-info fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">الكلمات المتتبعة</h6>
                            <h3 class="fw-bold mb-0">{{ number_format($seoOverview['total_keywords']) }}</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-warning bg-opacity-10 rounded-circle p-3">
                                <i class="fas fa-exclamation-triangle text-warning fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">المشاكل المكتشفة</h6>
                            <h3 class="fw-bold mb-0">{{ $seoOverview['issues_count'] }}</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Websites List -->
        <div class="col-lg-8 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="fw-bold mb-0">مواقعي</h5>
                        @can('create-websites')
                            <a href="#" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addWebsiteModal">
                                <i class="fas fa-plus me-1"></i>
                                إضافة موقع
                            </a>
                        @endcan
                    </div>
                </div>
                <div class="card-body">
                    @if($websites->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>الموقع</th>
                                        <th>نقاط SEO</th>
                                        <th>الحالة</th>
                                        <th>آخر فحص</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($websites as $website)
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-shrink-0">
                                                        <img src="https://www.google.com/s2/favicons?domain={{ $website->domain }}" 
                                                             alt="{{ $website->name }}" width="20" height="20" class="me-2">
                                                    </div>
                                                    <div>
                                                        <h6 class="mb-0">{{ $website->name }}</h6>
                                                        <small class="text-muted">{{ $website->domain }}</small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="progress me-2" style="width: 60px; height: 8px;">
                                                        <div class="progress-bar 
                                                            @if($website->overall_seo_score >= 80) bg-success
                                                            @elseif($website->overall_seo_score >= 60) bg-warning
                                                            @else bg-danger
                                                            @endif" 
                                                            style="width: {{ $website->overall_seo_score }}%"></div>
                                                    </div>
                                                    <span class="fw-bold">{{ $website->overall_seo_score }}/100</span>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge 
                                                    @if($website->is_verified) bg-success
                                                    @else bg-warning
                                                    @endif">
                                                    {{ $website->is_verified ? 'مؤكد' : 'غير مؤكد' }}
                                                </span>
                                            </td>
                                            <td>
                                                @if($website->last_crawled_at)
                                                    {{ $website->last_crawled_at->diffForHumans() }}
                                                @else
                                                    <span class="text-muted">لم يتم الفحص</span>
                                                @endif
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="#" class="btn btn-outline-primary">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="#" class="btn btn-outline-secondary">
                                                        <i class="fas fa-cog"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="text-center py-5">
                            <i class="fas fa-globe fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">لا توجد مواقع مضافة</h5>
                            <p class="text-muted mb-3">ابدأ بإضافة موقعك الأول لتحليل أدائه</p>
                            @can('create-websites')
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addWebsiteModal">
                                    <i class="fas fa-plus me-1"></i>
                                    إضافة موقع جديد
                                </button>
                            @endcan
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Integrations -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <h6 class="fw-bold mb-0">الربط والتكامل</h6>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fab fa-google text-danger me-2"></i>
                            <span>Google Analytics</span>
                        </div>
                        @if($integrations['google'])
                            <span class="badge bg-success">متصل</span>
                        @else
                            <a href="{{ route('google.connect') }}" class="btn btn-sm btn-outline-primary">ربط</a>
                        @endif
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-shopping-cart text-primary me-2"></i>
                            <span>سلة</span>
                        </div>
                        @if($integrations['salla'])
                            <span class="badge bg-success">متصل</span>
                        @else
                            <a href="{{ route('integrations.salla.connect') }}" class="btn btn-sm btn-outline-primary">ربط</a>
                        @endif
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-store text-info me-2"></i>
                            <span>زد</span>
                        </div>
                        @if($integrations['zid'])
                            <span class="badge bg-success">متصل</span>
                        @else
                            <a href="#" class="btn btn-sm btn-outline-primary">ربط</a>
                        @endif
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fab fa-shopify text-success me-2"></i>
                            <span>Shopify</span>
                        </div>
                        @if($integrations['shopify'])
                            <span class="badge bg-success">متصل</span>
                        @else
                            <a href="#" class="btn btn-sm btn-outline-primary">ربط</a>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <h6 class="fw-bold mb-0">النشاط الأخير</h6>
                </div>
                <div class="card-body">
                    @if(count($recentActivity) > 0)
                        @foreach($recentActivity as $activity)
                            <div class="d-flex align-items-start mb-3">
                                <div class="flex-shrink-0">
                                    <div class="bg-light rounded-circle p-2">
                                        <i class="fas fa-{{ $activity['icon'] }} text-muted"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <p class="mb-1 small">{{ $activity['title'] }}</p>
                                    <small class="text-muted">{{ $activity['time']->diffForHumans() }}</small>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div class="text-center py-3">
                            <i class="fas fa-clock fa-2x text-muted mb-2"></i>
                            <p class="text-muted mb-0">لا يوجد نشاط حديث</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Website Modal -->
<div class="modal fade" id="addWebsiteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">إضافة موقع جديد</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="#" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="website_name" class="form-label">اسم الموقع</label>
                        <input type="text" class="form-control" id="website_name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="website_url" class="form-label">رابط الموقع</label>
                        <input type="url" class="form-control" id="website_url" name="url" 
                               placeholder="https://example.com" required>
                    </div>
                    <div class="mb-3">
                        <label for="website_type" class="form-label">نوع الموقع</label>
                        <select class="form-select" id="website_type" name="type">
                            <option value="ecommerce">متجر إلكتروني</option>
                            <option value="blog">مدونة</option>
                            <option value="corporate">موقع شركة</option>
                            <option value="portfolio">معرض أعمال</option>
                            <option value="other">أخرى</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-primary">إضافة الموقع</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Auto-refresh data every 5 minutes
    setInterval(function() {
        location.reload();
    }, 300000);
    
    // Track website additions
    document.getElementById('addWebsiteModal').addEventListener('submit', function() {
        if (typeof gtag !== 'undefined') {
            gtag('event', 'website_added', {
                'event_category': 'Dashboard',
                'event_label': 'Add Website',
                'value': 1
            });
        }
    });
</script>
@endpush

