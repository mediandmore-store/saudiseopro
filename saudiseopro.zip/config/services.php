<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Payment Services
    |--------------------------------------------------------------------------
    */

    'paypal' => [
        'client_id' => env('PAYPAL_CLIENT_ID'),
        'client_secret' => env('PAYPAL_CLIENT_SECRET'),
        'base_url' => env('PAYPAL_BASE_URL', 'https://api-m.sandbox.paypal.com'),
        'webhook_id' => env('PAYPAL_WEBHOOK_ID'),
    ],

    'stripe' => [
        'key' => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
        'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),
    ],

    'stc_pay' => [
        'merchant_id' => env('STC_PAY_MERCHANT_ID'),
        'secret_key' => env('STC_PAY_SECRET_KEY'),
        'base_url' => env('STC_PAY_BASE_URL', 'https://api.stcpay.com.sa'),
    ],

    /*
    |--------------------------------------------------------------------------
    | E-commerce Platform Services
    |--------------------------------------------------------------------------
    */

    'salla' => [
        'client_id' => env('SALLA_CLIENT_ID'),
        'client_secret' => env('SALLA_CLIENT_SECRET'),
        'redirect_uri' => env('SALLA_REDIRECT_URI'),
        'base_url' => env('SALLA_BASE_URL', 'https://accounts.salla.sa'),
        'api_url' => env('SALLA_API_URL', 'https://api.salla.dev'),
        'webhook_secret' => env('SALLA_WEBHOOK_SECRET'),
    ],

    'zid' => [
        'client_id' => env('ZID_CLIENT_ID'),
        'client_secret' => env('ZID_CLIENT_SECRET'),
        'redirect_uri' => env('ZID_REDIRECT_URI'),
        'base_url' => env('ZID_BASE_URL', 'https://oauth.zid.sa'),
        'api_url' => env('ZID_API_URL', 'https://api.zid.sa'),
        'webhook_secret' => env('ZID_WEBHOOK_SECRET'),
    ],

    'shopify' => [
        'client_id' => env('SHOPIFY_CLIENT_ID'),
        'client_secret' => env('SHOPIFY_CLIENT_SECRET'),
        'redirect_uri' => env('SHOPIFY_REDIRECT_URI'),
        'scopes' => 'read_products,write_products,read_orders,read_analytics',
        'webhook_secret' => env('SHOPIFY_WEBHOOK_SECRET'),
    ],

    'woocommerce' => [
        'consumer_key' => env('WOOCOMMERCE_CONSUMER_KEY'),
        'consumer_secret' => env('WOOCOMMERCE_CONSUMER_SECRET'),
        'webhook_secret' => env('WOOCOMMERCE_WEBHOOK_SECRET'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Google Services
    |--------------------------------------------------------------------------
    */

    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID'),
        'client_secret' => env('GOOGLE_CLIENT_SECRET'),
        'redirect' => env('GOOGLE_REDIRECT_URI'),
        'scopes' => [
            'https://www.googleapis.com/auth/analytics.readonly',
            'https://www.googleapis.com/auth/webmasters.readonly',
            'https://www.googleapis.com/auth/spreadsheets',
            'https://www.googleapis.com/auth/drive.file',
        ],
    ],

    'google_analytics' => [
        'property_id' => env('GOOGLE_ANALYTICS_PROPERTY_ID'),
        'measurement_id' => env('GOOGLE_ANALYTICS_MEASUREMENT_ID'),
    ],

    'google_search_console' => [
        'site_url' => env('GOOGLE_SEARCH_CONSOLE_SITE_URL'),
    ],

    /*
    |--------------------------------------------------------------------------
    | SEO & Analytics Services
    |--------------------------------------------------------------------------
    */

    'semrush' => [
        'api_key' => env('SEMRUSH_API_KEY'),
        'base_url' => 'https://api.semrush.com',
    ],

    'ahrefs' => [
        'api_key' => env('AHREFS_API_KEY'),
        'base_url' => 'https://apiv2.ahrefs.com',
    ],

    'moz' => [
        'access_id' => env('MOZ_ACCESS_ID'),
        'secret_key' => env('MOZ_SECRET_KEY'),
        'base_url' => 'https://lsapi.seomoz.com',
    ],

    'screaming_frog' => [
        'api_key' => env('SCREAMING_FROG_API_KEY'),
        'base_url' => 'https://api.screamingfrog.co.uk',
    ],

    /*
    |--------------------------------------------------------------------------
    | AI & Content Services
    |--------------------------------------------------------------------------
    */

    'openai' => [
        'api_key' => env('OPENAI_API_KEY'),
        'organization' => env('OPENAI_ORGANIZATION'),
        'model' => env('OPENAI_MODEL', 'gpt-3.5-turbo'),
        'max_tokens' => env('OPENAI_MAX_TOKENS', 1000),
    ],

    'anthropic' => [
        'api_key' => env('ANTHROPIC_API_KEY'),
        'model' => env('ANTHROPIC_MODEL', 'claude-3-sonnet-20240229'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Social Media Services
    |--------------------------------------------------------------------------
    */

    'facebook' => [
        'client_id' => env('FACEBOOK_CLIENT_ID'),
        'client_secret' => env('FACEBOOK_CLIENT_SECRET'),
        'redirect' => env('FACEBOOK_REDIRECT_URI'),
        'pixel_id' => env('FACEBOOK_PIXEL_ID'),
    ],

    'twitter' => [
        'client_id' => env('TWITTER_CLIENT_ID'),
        'client_secret' => env('TWITTER_CLIENT_SECRET'),
        'redirect' => env('TWITTER_REDIRECT_URI'),
    ],

    'linkedin' => [
        'client_id' => env('LINKEDIN_CLIENT_ID'),
        'client_secret' => env('LINKEDIN_CLIENT_SECRET'),
        'redirect' => env('LINKEDIN_REDIRECT_URI'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Monitoring & Error Tracking
    |--------------------------------------------------------------------------
    */

    'sentry' => [
        'dsn' => env('SENTRY_LARAVEL_DSN'),
        'traces_sample_rate' => env('SENTRY_TRACES_SAMPLE_RATE', 0.1),
    ],

    'bugsnag' => [
        'api_key' => env('BUGSNAG_API_KEY'),
    ],

    'new_relic' => [
        'license_key' => env('NEW_RELIC_LICENSE_KEY'),
        'app_name' => env('NEW_RELIC_APP_NAME', 'Saudi SEO Pro'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Communication Services
    |--------------------------------------------------------------------------
    */

    'slack' => [
        'webhook_url' => env('SLACK_WEBHOOK_URL'),
        'channel' => env('SLACK_CHANNEL', '#general'),
    ],

    'telegram' => [
        'bot_token' => env('TELEGRAM_BOT_TOKEN'),
        'chat_id' => env('TELEGRAM_CHAT_ID'),
    ],

    'whatsapp' => [
        'api_key' => env('WHATSAPP_API_KEY'),
        'phone_number' => env('WHATSAPP_PHONE_NUMBER'),
    ],

    /*
    |--------------------------------------------------------------------------
    | File Storage Services
    |--------------------------------------------------------------------------
    */

    'aws' => [
        'access_key_id' => env('AWS_ACCESS_KEY_ID'),
        'secret_access_key' => env('AWS_SECRET_ACCESS_KEY'),
        'default_region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
        'bucket' => env('AWS_BUCKET'),
        'url' => env('AWS_URL'),
        'endpoint' => env('AWS_ENDPOINT'),
        'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE_ENDPOINT', false),
    ],

    'digitalocean' => [
        'access_key_id' => env('DO_ACCESS_KEY_ID'),
        'secret_access_key' => env('DO_SECRET_ACCESS_KEY'),
        'default_region' => env('DO_DEFAULT_REGION', 'nyc3'),
        'bucket' => env('DO_BUCKET'),
        'endpoint' => env('DO_ENDPOINT'),
    ],

    /*
    |--------------------------------------------------------------------------
    | CDN Services
    |--------------------------------------------------------------------------
    */

    'cloudflare' => [
        'api_key' => env('CLOUDFLARE_API_KEY'),
        'email' => env('CLOUDFLARE_EMAIL'),
        'zone_id' => env('CLOUDFLARE_ZONE_ID'),
    ],

    'cloudfront' => [
        'distribution_id' => env('CLOUDFRONT_DISTRIBUTION_ID'),
        'key_pair_id' => env('CLOUDFRONT_KEY_PAIR_ID'),
        'private_key' => env('CLOUDFRONT_PRIVATE_KEY'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Backup Services
    |--------------------------------------------------------------------------
    */

    'backup' => [
        'disk' => env('BACKUP_DISK', 's3'),
        'encryption_key' => env('BACKUP_ENCRYPTION_KEY'),
        'retention_days' => env('BACKUP_RETENTION_DAYS', 30),
    ],

    /*
    |--------------------------------------------------------------------------
    | Feature Flags
    |--------------------------------------------------------------------------
    */

    'features' => [
        'google_integration' => env('FEATURE_GOOGLE_INTEGRATION', true),
        'platform_integration' => env('FEATURE_PLATFORM_INTEGRATION', true),
        'ai_content_optimization' => env('FEATURE_AI_CONTENT_OPTIMIZATION', true),
        'competitor_analysis' => env('FEATURE_COMPETITOR_ANALYSIS', true),
        'white_label' => env('FEATURE_WHITE_LABEL', false),
        'api_access' => env('FEATURE_API_ACCESS', true),
        'advanced_analytics' => env('FEATURE_ADVANCED_ANALYTICS', true),
    ],

];

