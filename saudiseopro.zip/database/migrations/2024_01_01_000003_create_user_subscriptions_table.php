<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_subscriptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('subscription_id')->constrained()->onDelete('cascade');
            $table->enum('status', ['active', 'cancelled', 'expired', 'pending'])->default('pending');
            $table->decimal('amount_paid', 10, 2);
            $table->string('currency', 3)->default('SAR');
            $table->enum('billing_cycle', ['monthly', 'quarterly', 'yearly']);
            $table->timestamp('starts_at');
            $table->timestamp('expires_at')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            $table->timestamp('ends_at')->nullable(); // Grace period end
            $table->string('cancellation_reason')->nullable();
            $table->json('features_snapshot'); // Store features at time of subscription
            $table->string('payment_method')->nullable();
            $table->string('payment_reference')->nullable();
            $table->boolean('auto_renew')->default(true);
            $table->timestamps();
            
            // Indexes
            $table->index(['user_id', 'status']);
            $table->index(['status', 'expires_at']);
            $table->index('expires_at');
            $table->index('created_at');
            
            // Ensure one active subscription per user
            $table->unique(['user_id', 'status'], 'unique_active_subscription')
                  ->where('status', 'active');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_subscriptions');
    }
};

