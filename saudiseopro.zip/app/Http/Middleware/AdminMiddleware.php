<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = Auth::user();

        if (!$user) {
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'يجب تسجيل الدخول للوصول إلى هذه الصفحة',
                ], 401);
            }

            return redirect()->route('login')
                ->with('error', 'يجب تسجيل الدخول للوصول إلى لوحة الإدارة');
        }

        if (!$this->isAdmin($user)) {
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'ليس لديك صلاحية للوصول إلى هذه الصفحة',
                ], 403);
            }

            return redirect()->route('dashboard')
                ->with('error', 'ليس لديك صلاحية للوصول إلى لوحة الإدارة');
        }

        return $next($request);
    }

    /**
     * Check if user is admin
     */
    protected function isAdmin($user): bool
    {
        // Check if user has admin role
        if (method_exists($user, 'hasRole')) {
            return $user->hasRole('admin') || $user->hasRole('super-admin');
        }

        // Check if user email is in admin list
        $adminEmails = config('app.admin_emails', []);
        if (in_array($user->email, $adminEmails)) {
            return true;
        }

        // Check if user has admin permission
        if (method_exists($user, 'can')) {
            return $user->can('access-admin-panel');
        }

        // Check user status for admin
        return $user->status === 'admin' || $user->is_admin ?? false;
    }
}

