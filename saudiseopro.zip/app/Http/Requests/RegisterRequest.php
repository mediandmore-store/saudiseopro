<?php

namespace App\Http\Requests;

use App\Models\Subscription;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class RegisterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'min:2',
                'max:255',
                'regex:/^[\p{Arabic}\p{L}\s\-\.]+$/u', // Allow Arabic, Latin letters, spaces, hyphens, dots
            ],
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                'unique:users,email',
            ],
            'password' => [
                'required',
                'string',
                'confirmed',
                Password::min(8)
                    ->letters()
                    ->mixedCase()
                    ->numbers()
                    ->symbols()
                    ->uncompromised(),
            ],
            'subscription_id' => [
                'required',
                'integer',
                'exists:subscriptions,id',
                function ($attribute, $value, $fail) {
                    $subscription = Subscription::find($value);
                    if (!$subscription || !$subscription->isActive()) {
                        $fail('الخطة المحددة غير متاحة');
                    }
                },
            ],
            'terms' => [
                'required',
                'accepted',
            ],
            'privacy' => [
                'required',
                'accepted',
            ],
            'marketing_emails' => [
                'boolean',
            ],
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'name.required' => 'الاسم مطلوب',
            'name.min' => 'الاسم يجب أن يكون حرفين على الأقل',
            'name.max' => 'الاسم طويل جداً',
            'name.regex' => 'الاسم يحتوي على أحرف غير مسموحة',
            
            'email.required' => 'البريد الإلكتروني مطلوب',
            'email.email' => 'البريد الإلكتروني غير صحيح',
            'email.max' => 'البريد الإلكتروني طويل جداً',
            'email.unique' => 'هذا البريد الإلكتروني مستخدم بالفعل',
            
            'password.required' => 'كلمة المرور مطلوبة',
            'password.confirmed' => 'تأكيد كلمة المرور غير متطابق',
            'password.min' => 'كلمة المرور يجب أن تكون 8 أحرف على الأقل',
            
            'subscription_id.required' => 'يجب اختيار خطة اشتراك',
            'subscription_id.exists' => 'الخطة المحددة غير موجودة',
            
            'terms.required' => 'يجب الموافقة على شروط الاستخدام',
            'terms.accepted' => 'يجب الموافقة على شروط الاستخدام',
            
            'privacy.required' => 'يجب الموافقة على سياسة الخصوصية',
            'privacy.accepted' => 'يجب الموافقة على سياسة الخصوصية',
        ];
    }

    /**
     * Get custom attributes for validator errors.
     */
    public function attributes(): array
    {
        return [
            'name' => 'الاسم',
            'email' => 'البريد الإلكتروني',
            'password' => 'كلمة المرور',
            'password_confirmation' => 'تأكيد كلمة المرور',
            'subscription_id' => 'خطة الاشتراك',
            'terms' => 'شروط الاستخدام',
            'privacy' => 'سياسة الخصوصية',
            'marketing_emails' => 'الرسائل التسويقية',
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim($this->name),
            'email' => strtolower(trim($this->email)),
            'marketing_emails' => $this->boolean('marketing_emails'),
        ]);
    }

    /**
     * Configure the validator instance.
     */
    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            // Additional custom validation
            if ($this->hasSpamIndicators()) {
                $validator->errors()->add('email', 'تم رفض التسجيل. يرجى المحاولة مرة أخرى.');
            }

            // Check if email domain is allowed
            if (!$this->isEmailDomainAllowed()) {
                $validator->errors()->add('email', 'نطاق البريد الإلكتروني غير مسموح');
            }
        });
    }

    /**
     * Handle a failed validation attempt.
     */
    protected function failedValidation($validator): void
    {
        // Log failed registration attempt
        logger()->warning('Registration validation failed', [
            'email' => $this->input('email'),
            'name' => $this->input('name'),
            'ip' => $this->ip(),
            'user_agent' => $this->userAgent(),
            'errors' => $validator->errors()->toArray(),
        ]);

        parent::failedValidation($validator);
    }

    /**
     * Check for spam indicators.
     */
    protected function hasSpamIndicators(): bool
    {
        $name = strtolower($this->input('name', ''));
        $email = strtolower($this->input('email', ''));

        // Check for common spam patterns
        $spamPatterns = [
            'test@test.com',
            'admin@admin.com',
            'user@user.com',
            'spam',
            'fake',
            'dummy',
        ];

        foreach ($spamPatterns as $pattern) {
            if (str_contains($email, $pattern) || str_contains($name, $pattern)) {
                return true;
            }
        }

        // Check if name and email are suspiciously similar
        $emailLocal = explode('@', $email)[0];
        if (similar_text($name, $emailLocal) / strlen($name) > 0.8) {
            return true;
        }

        return false;
    }

    /**
     * Check if email domain is allowed.
     */
    protected function isEmailDomainAllowed(): bool
    {
        $email = $this->input('email', '');
        $domain = explode('@', $email)[1] ?? '';

        // List of blocked domains
        $blockedDomains = [
            '10minutemail.com',
            'tempmail.org',
            'guerrillamail.com',
            'mailinator.com',
        ];

        return !in_array($domain, $blockedDomains);
    }

    /**
     * Get the validated data from the request.
     */
    public function validated($key = null, $default = null)
    {
        $validated = parent::validated($key, $default);

        // Remove terms and privacy from validated data as they're not stored
        unset($validated['terms'], $validated['privacy']);

        return $validated;
    }

    /**
     * Get the selected subscription.
     */
    public function getSubscription(): ?Subscription
    {
        return Subscription::find($this->input('subscription_id'));
    }
}

