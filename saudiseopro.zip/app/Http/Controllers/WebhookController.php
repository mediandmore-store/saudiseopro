<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use App\Models\User;
use App\Models\UserSubscription;
use App\Services\BillingService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;

class WebhookController extends Controller
{
    protected BillingService $billingService;

    public function __construct(BillingService $billingService)
    {
        $this->billingService = $billingService;
    }

    public function paypal(Request $request): JsonResponse
    {
        try {
            // Verify PayPal webhook signature
            if (!$this->verifyPayPalSignature($request)) {
                Log::warning('Invalid PayPal webhook signature', [
                    'headers' => $request->headers->all(),
                    'body' => $request->getContent(),
                ]);
                
                return response()->json(['error' => 'Invalid signature'], 400);
            }

            $eventType = $request->input('event_type');
            $resource = $request->input('resource');

            Log::info('PayPal webhook received', [
                'event_type' => $eventType,
                'resource_id' => $resource['id'] ?? null,
            ]);

            switch ($eventType) {
                case 'PAYMENT.CAPTURE.COMPLETED':
                    $this->handlePayPalPaymentCompleted($resource);
                    break;

                case 'PAYMENT.CAPTURE.DENIED':
                case 'PAYMENT.CAPTURE.DECLINED':
                    $this->handlePayPalPaymentFailed($resource);
                    break;

                case 'BILLING.SUBSCRIPTION.ACTIVATED':
                    $this->handlePayPalSubscriptionActivated($resource);
                    break;

                case 'BILLING.SUBSCRIPTION.CANCELLED':
                    $this->handlePayPalSubscriptionCancelled($resource);
                    break;

                default:
                    Log::info('Unhandled PayPal webhook event', ['event_type' => $eventType]);
            }

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error('PayPal webhook error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json(['error' => 'Internal error'], 500);
        }
    }

    public function stripe(Request $request): JsonResponse
    {
        try {
            // Verify Stripe webhook signature
            if (!$this->verifyStripeSignature($request)) {
                Log::warning('Invalid Stripe webhook signature');
                return response()->json(['error' => 'Invalid signature'], 400);
            }

            $event = $request->all();
            $eventType = $event['type'];
            $object = $event['data']['object'];

            Log::info('Stripe webhook received', [
                'event_type' => $eventType,
                'object_id' => $object['id'] ?? null,
            ]);

            switch ($eventType) {
                case 'payment_intent.succeeded':
                    $this->handleStripePaymentSucceeded($object);
                    break;

                case 'payment_intent.payment_failed':
                    $this->handleStripePaymentFailed($object);
                    break;

                case 'customer.subscription.created':
                case 'customer.subscription.updated':
                    $this->handleStripeSubscriptionUpdated($object);
                    break;

                case 'customer.subscription.deleted':
                    $this->handleStripeSubscriptionDeleted($object);
                    break;

                case 'invoice.payment_succeeded':
                    $this->handleStripeInvoicePaymentSucceeded($object);
                    break;

                default:
                    Log::info('Unhandled Stripe webhook event', ['event_type' => $eventType]);
            }

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error('Stripe webhook error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json(['error' => 'Internal error'], 500);
        }
    }

    public function salla(Request $request): JsonResponse
    {
        try {
            // Verify Salla webhook signature
            if (!$this->verifySallaSignature($request)) {
                Log::warning('Invalid Salla webhook signature');
                return response()->json(['error' => 'Invalid signature'], 400);
            }

            $event = $request->input('event');
            $data = $request->input('data');

            Log::info('Salla webhook received', [
                'event' => $event,
                'merchant_id' => $data['merchant']['id'] ?? null,
            ]);

            switch ($event) {
                case 'app.installed':
                    $this->handleSallaAppInstalled($data);
                    break;

                case 'app.uninstalled':
                    $this->handleSallaAppUninstalled($data);
                    break;

                case 'order.created':
                    $this->handleSallaOrderCreated($data);
                    break;

                case 'product.created':
                case 'product.updated':
                    $this->handleSallaProductUpdated($data);
                    break;

                default:
                    Log::info('Unhandled Salla webhook event', ['event' => $event]);
            }

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error('Salla webhook error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json(['error' => 'Internal error'], 500);
        }
    }

    protected function verifyPayPalSignature(Request $request): bool
    {
        $webhookSecret = config('services.paypal.webhook_secret');
        if (!$webhookSecret) {
            return true; // Skip verification if no secret configured
        }

        $signature = $request->header('PAYPAL-TRANSMISSION-SIG');
        $certId = $request->header('PAYPAL-CERT-ID');
        $timestamp = $request->header('PAYPAL-TRANSMISSION-TIME');
        
        // Implement PayPal signature verification logic
        // This is a simplified version - implement full verification in production
        return !empty($signature) && !empty($certId) && !empty($timestamp);
    }

    protected function verifyStripeSignature(Request $request): bool
    {
        $webhookSecret = config('services.stripe.webhook_secret');
        if (!$webhookSecret) {
            return true; // Skip verification if no secret configured
        }

        $signature = $request->header('Stripe-Signature');
        $payload = $request->getContent();

        // Implement Stripe signature verification
        return !empty($signature);
    }

    protected function verifySallaSignature(Request $request): bool
    {
        $webhookSecret = config('services.salla.webhook_secret');
        if (!$webhookSecret) {
            return true; // Skip verification if no secret configured
        }

        $signature = $request->header('X-Salla-Signature');
        $payload = $request->getContent();

        // Verify signature
        $expectedSignature = hash_hmac('sha256', $payload, $webhookSecret);
        return hash_equals($expectedSignature, $signature);
    }

    protected function handlePayPalPaymentCompleted(array $resource): void
    {
        $paymentId = $resource['id'];
        $customId = $resource['custom_id'] ?? null;

        if (!$customId) {
            Log::warning('PayPal payment completed without custom_id', ['payment_id' => $paymentId]);
            return;
        }

        $payment = Payment::where('payment_id', $paymentId)->first();
        if (!$payment) {
            Log::warning('PayPal payment not found in database', ['payment_id' => $paymentId]);
            return;
        }

        $payment->markAsCompleted([
            'paypal_capture_id' => $resource['id'],
            'paypal_status' => $resource['status'],
        ]);

        // Activate subscription
        $this->activateUserSubscription($payment);

        Log::info('PayPal payment completed successfully', [
            'payment_id' => $paymentId,
            'user_id' => $payment->user_id,
        ]);
    }

    protected function handlePayPalPaymentFailed(array $resource): void
    {
        $paymentId = $resource['id'];
        
        $payment = Payment::where('payment_id', $paymentId)->first();
        if (!$payment) {
            return;
        }

        $payment->markAsFailed($resource['status_details']['reason'] ?? 'Payment failed');

        Log::info('PayPal payment failed', [
            'payment_id' => $paymentId,
            'user_id' => $payment->user_id,
            'reason' => $resource['status_details']['reason'] ?? 'Unknown',
        ]);
    }

    protected function handleStripePaymentSucceeded(array $object): void
    {
        $paymentIntentId = $object['id'];
        $metadata = $object['metadata'] ?? [];

        $payment = Payment::where('payment_id', $paymentIntentId)->first();
        if (!$payment) {
            Log::warning('Stripe payment not found in database', ['payment_intent_id' => $paymentIntentId]);
            return;
        }

        $payment->markAsCompleted([
            'stripe_payment_intent_id' => $object['id'],
            'stripe_status' => $object['status'],
        ]);

        // Activate subscription
        $this->activateUserSubscription($payment);

        Log::info('Stripe payment succeeded', [
            'payment_intent_id' => $paymentIntentId,
            'user_id' => $payment->user_id,
        ]);
    }

    protected function handleStripePaymentFailed(array $object): void
    {
        $paymentIntentId = $object['id'];
        
        $payment = Payment::where('payment_id', $paymentIntentId)->first();
        if (!$payment) {
            return;
        }

        $lastError = $object['last_payment_error'] ?? [];
        $payment->markAsFailed($lastError['message'] ?? 'Payment failed');

        Log::info('Stripe payment failed', [
            'payment_intent_id' => $paymentIntentId,
            'user_id' => $payment->user_id,
            'error' => $lastError['message'] ?? 'Unknown error',
        ]);
    }

    protected function activateUserSubscription(Payment $payment): void
    {
        $userSubscription = UserSubscription::where('user_id', $payment->user_id)
            ->where('subscription_id', $payment->subscription_id)
            ->where('status', 'pending')
            ->first();

        if ($userSubscription) {
            $userSubscription->update([
                'status' => 'active',
                'payment_reference' => $payment->payment_id,
            ]);

            // Update user status
            $payment->user->update(['status' => 'active']);

            Log::info('User subscription activated', [
                'user_id' => $payment->user_id,
                'subscription_id' => $payment->subscription_id,
                'payment_id' => $payment->id,
            ]);
        }
    }

    protected function handleSallaAppInstalled(array $data): void
    {
        $merchantId = $data['merchant']['id'];
        $accessToken = $data['access_token'] ?? null;

        if (!$accessToken) {
            Log::warning('Salla app installed without access token', ['merchant_id' => $merchantId]);
            return;
        }

        // Find user by merchant ID or create new integration record
        Log::info('Salla app installed', [
            'merchant_id' => $merchantId,
            'store_name' => $data['merchant']['name'] ?? null,
        ]);
    }

    protected function handleSallaAppUninstalled(array $data): void
    {
        $merchantId = $data['merchant']['id'];

        // Deactivate Salla integration
        Log::info('Salla app uninstalled', ['merchant_id' => $merchantId]);
    }

    protected function handleSallaOrderCreated(array $data): void
    {
        // Handle new order from Salla store
        Log::info('Salla order created', [
            'order_id' => $data['id'] ?? null,
            'merchant_id' => $data['merchant']['id'] ?? null,
        ]);
    }

    protected function handleSallaProductUpdated(array $data): void
    {
        // Handle product updates from Salla store
        Log::info('Salla product updated', [
            'product_id' => $data['id'] ?? null,
            'merchant_id' => $data['merchant']['id'] ?? null,
        ]);
    }
}

