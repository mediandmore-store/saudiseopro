<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\GoogleService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Laravel\Socialite\Facades\Socialite;

class GoogleAuthController extends Controller
{
    protected $googleService;

    public function __construct(GoogleService $googleService)
    {
        $this->middleware(['auth', 'subscription:google_integration']);
        $this->googleService = $googleService;
    }

    /**
     * Redirect to Google OAuth.
     */
    public function redirectToGoogle()
    {
        try {
            $scopes = [
                'https://www.googleapis.com/auth/analytics.readonly',
                'https://www.googleapis.com/auth/webmasters.readonly',
                'https://www.googleapis.com/auth/spreadsheets',
            ];

            $authUrl = Socialite::driver('google')
                ->scopes($scopes)
                ->with(['access_type' => 'offline', 'prompt' => 'consent'])
                ->redirect();

            Log::info('Google OAuth initiated', [
                'user_id' => Auth::id(),
                'scopes' => $scopes,
            ]);

            return $authUrl;

        } catch (\Exception $e) {
            Log::error('Google OAuth initiation failed', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
            ]);

            return redirect('/integrations')
                ->with('error', 'حدث خطأ في الاتصال بجوجل. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Handle Google OAuth callback.
     */
    public function handleGoogleCallback(Request $request)
    {
        if ($request->has('error')) {
            Log::warning('Google OAuth cancelled', [
                'user_id' => Auth::id(),
                'error' => $request->error,
            ]);

            return redirect('/integrations')
                ->with('error', 'تم إلغاء ربط حساب جوجل');
        }

        if (!Auth::check()) {
            return redirect('/login')
                ->with('error', 'يجب تسجيل الدخول أولاً');
        }

        try {
            $googleUser = Socialite::driver('google')->user();
            $user = Auth::user();

            // Validate required scopes
            $requiredScopes = [
                'https://www.googleapis.com/auth/analytics.readonly',
                'https://www.googleapis.com/auth/webmasters.readonly',
            ];

            if (!$this->hasRequiredScopes($googleUser, $requiredScopes)) {
                return redirect('/integrations')
                    ->with('error', 'لم يتم منح جميع الصلاحيات المطلوبة. يرجى المحاولة مرة أخرى والموافقة على جميع الصلاحيات.');
            }

            // Save Google tokens
            $user->setGoogleAccessToken($googleUser->token);
            $user->setGoogleRefreshToken($googleUser->refreshToken);
            $user->save();

            // Test connection and get account info
            $accountInfo = $this->googleService->getAccountInfo($googleUser->token);

            Log::info('Google integration successful', [
                'user_id' => $user->id,
                'google_email' => $googleUser->email,
                'analytics_accounts' => count($accountInfo['analytics_accounts'] ?? []),
                'search_console_sites' => count($accountInfo['search_console_sites'] ?? []),
            ]);

            return redirect('/integrations')
                ->with('success', 'تم ربط حساب جوجل بنجاح! يمكنك الآن الوصول إلى بيانات Analytics و Search Console.');

        } catch (\Exception $e) {
            Log::error('Google OAuth callback failed', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return redirect('/integrations')
                ->with('error', 'حدث خطأ في ربط حساب جوجل. يرجى المحاولة مرة أخرى.');
        }
    }

    /**
     * Disconnect Google account.
     */
    public function disconnectGoogle()
    {
        try {
            $user = Auth::user();

            if (!$user->hasGoogleConnection()) {
                return back()->with('error', 'حساب جوجل غير مربوط');
            }

            // Revoke Google tokens
            $this->googleService->revokeTokens($user->getGoogleAccessToken());

            // Clear tokens from database
            $user->setGoogleAccessToken(null);
            $user->setGoogleRefreshToken(null);
            $user->save();

            Log::info('Google account disconnected', [
                'user_id' => $user->id,
            ]);

            return back()->with('success', 'تم إلغاء ربط حساب جوجل بنجاح');

        } catch (\Exception $e) {
            Log::error('Google disconnection failed', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'حدث خطأ في إلغاء ربط حساب جوجل');
        }
    }

    /**
     * Get Google Analytics accounts.
     */
    public function getAnalyticsAccounts()
    {
        $user = Auth::user();

        if (!$user->hasGoogleConnection()) {
            return response()->json([
                'success' => false,
                'message' => 'حساب جوجل غير مربوط'
            ]);
        }

        try {
            $accounts = $this->googleService->getAnalyticsAccounts($user->getGoogleAccessToken());

            return response()->json([
                'success' => true,
                'accounts' => $accounts
            ]);

        } catch (\Exception $e) {
            Log::error('Failed to get Analytics accounts', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'حدث خطأ في جلب حسابات Analytics'
            ]);
        }
    }

    /**
     * Get Search Console sites.
     */
    public function getSearchConsoleSites()
    {
        $user = Auth::user();

        if (!$user->hasGoogleConnection()) {
            return response()->json([
                'success' => false,
                'message' => 'حساب جوجل غير مربوط'
            ]);
        }

        try {
            $sites = $this->googleService->getSearchConsoleSites($user->getGoogleAccessToken());

            return response()->json([
                'success' => true,
                'sites' => $sites
            ]);

        } catch (\Exception $e) {
            Log::error('Failed to get Search Console sites', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'حدث خطأ في جلب مواقع Search Console'
            ]);
        }
    }

    /**
     * Test Google connection.
     */
    public function testConnection()
    {
        $user = Auth::user();

        if (!$user->hasGoogleConnection()) {
            return response()->json([
                'success' => false,
                'message' => 'حساب جوجل غير مربوط'
            ]);
        }

        try {
            $isValid = $this->googleService->testConnection($user->getGoogleAccessToken());

            if ($isValid) {
                return response()->json([
                    'success' => true,
                    'message' => 'الاتصال مع جوجل يعمل بشكل صحيح'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'انتهت صلاحية الاتصال. يرجى إعادة الربط'
                ]);
            }

        } catch (\Exception $e) {
            Log::error('Google connection test failed', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'حدث خطأ في اختبار الاتصال'
            ]);
        }
    }

    /**
     * Refresh Google tokens.
     */
    public function refreshTokens()
    {
        $user = Auth::user();

        if (!$user->hasGoogleConnection()) {
            return response()->json([
                'success' => false,
                'message' => 'حساب جوجل غير مربوط'
            ]);
        }

        try {
            $refreshToken = $user->getGoogleRefreshToken();
            
            if (!$refreshToken) {
                return response()->json([
                    'success' => false,
                    'message' => 'لا يوجد رمز تجديد. يرجى إعادة ربط الحساب'
                ]);
            }

            $newTokens = $this->googleService->refreshAccessToken($refreshToken);

            $user->setGoogleAccessToken($newTokens['access_token']);
            if (isset($newTokens['refresh_token'])) {
                $user->setGoogleRefreshToken($newTokens['refresh_token']);
            }
            $user->save();

            Log::info('Google tokens refreshed', [
                'user_id' => $user->id,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'تم تجديد رموز الوصول بنجاح'
            ]);

        } catch (\Exception $e) {
            Log::error('Token refresh failed', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'فشل في تجديد رموز الوصول. يرجى إعادة ربط الحساب'
            ]);
        }
    }

    /**
     * Export data to Google Sheets.
     */
    public function exportToSheets(Request $request)
    {
        $request->validate([
            'data_type' => 'required|in:keywords,analytics,search_console',
            'date_range' => 'required|in:7d,30d,90d',
        ]);

        $user = Auth::user();

        if (!$user->hasGoogleConnection()) {
            return response()->json([
                'success' => false,
                'message' => 'حساب جوجل غير مربوط'
            ]);
        }

        try {
            $sheetUrl = $this->googleService->exportToSheets(
                $user->getGoogleAccessToken(),
                $request->data_type,
                $request->date_range,
                $user->id
            );

            Log::info('Data exported to Google Sheets', [
                'user_id' => $user->id,
                'data_type' => $request->data_type,
                'date_range' => $request->date_range,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'تم تصدير البيانات بنجاح',
                'sheet_url' => $sheetUrl
            ]);

        } catch (\Exception $e) {
            Log::error('Export to Sheets failed', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'حدث خطأ في تصدير البيانات'
            ]);
        }
    }

    /**
     * Check if user has required scopes.
     */
    protected function hasRequiredScopes($googleUser, $requiredScopes)
    {
        $userScopes = $googleUser->approvedScopes ?? [];
        
        foreach ($requiredScopes as $scope) {
            if (!in_array($scope, $userScopes)) {
                return false;
            }
        }

        return true;
    }
}

