<?php

namespace App\Services;

use App\Models\User;
use Google\Client as GoogleClient;
use Google\Service\Analytics;
use Google\Service\SearchConsole;
use Google\Service\Sheets;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class GoogleService
{
    protected GoogleClient $client;
    protected User $user;

    public function __construct(User $user = null)
    {
        $this->client = new GoogleClient();
        $this->client->setClientId(config('services.google.client_id'));
        $this->client->setClientSecret(config('services.google.client_secret'));
        $this->client->setRedirectUri(config('services.google.redirect'));
        $this->client->setScopes(config('services.google.scopes'));
        $this->client->setAccessType('offline');
        $this->client->setPrompt('consent');

        if ($user) {
            $this->user = $user;
            $this->setAccessToken($user->getGoogleAccessToken());
        }
    }

    public function getAuthUrl(): string
    {
        return $this->client->createAuthUrl();
    }

    public function handleCallback(string $code): array
    {
        $token = $this->client->fetchAccessTokenWithAuthCode($code);
        
        if (isset($token['error'])) {
            throw new \Exception('Google OAuth error: ' . $token['error_description']);
        }

        return $token;
    }

    public function setAccessToken(?string $token): void
    {
        if ($token) {
            $this->client->setAccessToken($token);
        }
    }

    public function refreshToken(): ?string
    {
        if ($this->client->isAccessTokenExpired()) {
            $refreshToken = $this->client->getRefreshToken();
            if ($refreshToken) {
                $newToken = $this->client->fetchAccessTokenWithRefreshToken($refreshToken);
                return json_encode($newToken);
            }
        }
        return null;
    }

    public function getAnalyticsData(string $propertyId, array $params = []): array
    {
        try {
            $analytics = new Analytics($this->client);
            
            $defaultParams = [
                'startDate' => '30daysAgo',
                'endDate' => 'today',
                'metrics' => ['sessions', 'users', 'pageviews', 'bounceRate'],
                'dimensions' => ['date'],
            ];

            $params = array_merge($defaultParams, $params);

            $cacheKey = "analytics_data_{$propertyId}_" . md5(serialize($params));
            
            return Cache::remember($cacheKey, 3600, function () use ($analytics, $propertyId, $params) {
                // This is a simplified version - implement actual Analytics Data API v1 calls
                $response = $analytics->reports->batchGet([
                    'reportRequests' => [
                        [
                            'viewId' => $propertyId,
                            'dateRanges' => [
                                [
                                    'startDate' => $params['startDate'],
                                    'endDate' => $params['endDate'],
                                ]
                            ],
                            'metrics' => array_map(function ($metric) {
                                return ['expression' => "ga:{$metric}"];
                            }, $params['metrics']),
                            'dimensions' => array_map(function ($dimension) {
                                return ['name' => "ga:{$dimension}"];
                            }, $params['dimensions']),
                        ]
                    ]
                ]);

                return $this->formatAnalyticsResponse($response);
            });

        } catch (\Exception $e) {
            Log::error('Google Analytics API error', [
                'user_id' => $this->user->id ?? null,
                'property_id' => $propertyId,
                'error' => $e->getMessage(),
            ]);

            throw $e;
        }
    }

    public function getSearchConsoleData(string $siteUrl, array $params = []): array
    {
        try {
            $searchConsole = new SearchConsole($this->client);
            
            $defaultParams = [
                'startDate' => '2024-01-01',
                'endDate' => date('Y-m-d'),
                'dimensions' => ['query'],
                'rowLimit' => 100,
            ];

            $params = array_merge($defaultParams, $params);

            $cacheKey = "search_console_data_" . md5($siteUrl . serialize($params));
            
            return Cache::remember($cacheKey, 3600, function () use ($searchConsole, $siteUrl, $params) {
                $request = new \Google\Service\SearchConsole\SearchAnalyticsQueryRequest();
                $request->setStartDate($params['startDate']);
                $request->setEndDate($params['endDate']);
                $request->setDimensions($params['dimensions']);
                $request->setRowLimit($params['rowLimit']);

                $response = $searchConsole->searchanalytics->query($siteUrl, $request);
                
                return $this->formatSearchConsoleResponse($response);
            });

        } catch (\Exception $e) {
            Log::error('Google Search Console API error', [
                'user_id' => $this->user->id ?? null,
                'site_url' => $siteUrl,
                'error' => $e->getMessage(),
            ]);

            throw $e;
        }
    }

    public function getSitesList(): array
    {
        try {
            $searchConsole = new SearchConsole($this->client);
            $sites = $searchConsole->sites->listSites();
            
            return array_map(function ($site) {
                return [
                    'site_url' => $site->getSiteUrl(),
                    'permission_level' => $site->getPermissionLevel(),
                ];
            }, $sites->getSiteEntry() ?? []);

        } catch (\Exception $e) {
            Log::error('Google Search Console sites list error', [
                'user_id' => $this->user->id ?? null,
                'error' => $e->getMessage(),
            ]);

            return [];
        }
    }

    public function createSpreadsheet(string $title, array $data): ?string
    {
        try {
            $sheets = new Sheets($this->client);
            
            $spreadsheet = new \Google\Service\Sheets\Spreadsheet([
                'properties' => [
                    'title' => $title
                ]
            ]);

            $response = $sheets->spreadsheets->create($spreadsheet);
            $spreadsheetId = $response->getSpreadsheetId();

            // Add data to the spreadsheet
            if (!empty($data)) {
                $this->updateSpreadsheetData($spreadsheetId, $data);
            }

            Log::info('Google Spreadsheet created', [
                'user_id' => $this->user->id ?? null,
                'spreadsheet_id' => $spreadsheetId,
                'title' => $title,
            ]);

            return $spreadsheetId;

        } catch (\Exception $e) {
            Log::error('Google Sheets API error', [
                'user_id' => $this->user->id ?? null,
                'title' => $title,
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    public function updateSpreadsheetData(string $spreadsheetId, array $data, string $range = 'A1'): bool
    {
        try {
            $sheets = new Sheets($this->client);
            
            $body = new \Google\Service\Sheets\ValueRange([
                'values' => $data
            ]);

            $params = [
                'valueInputOption' => 'RAW'
            ];

            $sheets->spreadsheets_values->update($spreadsheetId, $range, $body, $params);

            return true;

        } catch (\Exception $e) {
            Log::error('Google Sheets update error', [
                'user_id' => $this->user->id ?? null,
                'spreadsheet_id' => $spreadsheetId,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    public function exportKeywordsToSheets(array $keywords, string $websiteName): ?string
    {
        $title = "كلمات مفتاحية - {$websiteName} - " . date('Y-m-d');
        
        $data = [
            ['الكلمة المفتاحية', 'الترتيب', 'النقرات', 'الظهور', 'معدل النقر', 'الموضع المتوسط']
        ];

        foreach ($keywords as $keyword) {
            $data[] = [
                $keyword['query'] ?? '',
                $keyword['position'] ?? '',
                $keyword['clicks'] ?? 0,
                $keyword['impressions'] ?? 0,
                $keyword['ctr'] ?? 0,
                $keyword['position'] ?? 0,
            ];
        }

        return $this->createSpreadsheet($title, $data);
    }

    protected function formatAnalyticsResponse($response): array
    {
        $formatted = [
            'totals' => [],
            'rows' => [],
        ];

        if ($response->getReports()) {
            $report = $response->getReports()[0];
            
            if ($report->getData() && $report->getData()->getTotals()) {
                $totals = $report->getData()->getTotals()[0];
                $formatted['totals'] = $totals->getValues();
            }

            if ($report->getData() && $report->getData()->getRows()) {
                foreach ($report->getData()->getRows() as $row) {
                    $formatted['rows'][] = [
                        'dimensions' => $row->getDimensions(),
                        'metrics' => $row->getMetrics()[0]->getValues(),
                    ];
                }
            }
        }

        return $formatted;
    }

    protected function formatSearchConsoleResponse($response): array
    {
        $formatted = [
            'rows' => [],
            'totals' => [
                'clicks' => 0,
                'impressions' => 0,
                'ctr' => 0,
                'position' => 0,
            ],
        ];

        if ($response->getRows()) {
            foreach ($response->getRows() as $row) {
                $formatted['rows'][] = [
                    'keys' => $row->getKeys(),
                    'clicks' => $row->getClicks(),
                    'impressions' => $row->getImpressions(),
                    'ctr' => $row->getCtr(),
                    'position' => $row->getPosition(),
                ];

                $formatted['totals']['clicks'] += $row->getClicks();
                $formatted['totals']['impressions'] += $row->getImpressions();
            }

            $rowCount = count($response->getRows());
            if ($rowCount > 0) {
                $formatted['totals']['ctr'] = $formatted['totals']['clicks'] / $formatted['totals']['impressions'];
                $formatted['totals']['position'] = array_sum(array_column($formatted['rows'], 'position')) / $rowCount;
            }
        }

        return $formatted;
    }

    public function isTokenValid(): bool
    {
        try {
            return !$this->client->isAccessTokenExpired();
        } catch (\Exception $e) {
            return false;
        }
    }

    public function revokeToken(): bool
    {
        try {
            $this->client->revokeToken();
            return true;
        } catch (\Exception $e) {
            Log::error('Google token revocation error', [
                'user_id' => $this->user->id ?? null,
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }
}

