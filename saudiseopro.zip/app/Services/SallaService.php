<?php

namespace App\Services;

use App\Models\PlatformToken;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SallaService
{
    protected $clientId;
    protected $clientSecret;
    protected $redirectUri;
    protected $baseUrl = 'https://accounts.salla.sa';
    protected $apiUrl = 'https://api.salla.dev';

    public function __construct()
    {
        $this->clientId = config('services.salla.client_id');
        $this->clientSecret = config('services.salla.client_secret');
        $this->redirectUri = config('services.salla.redirect_uri');
    }

    /**
     * Get authorization URL for OAuth flow.
     */
    public function getAuthorizationUrl(): string
    {
        $params = http_build_query([
            'client_id' => $this->clientId,
            'redirect_uri' => $this->redirectUri,
            'response_type' => 'code',
            'scope' => 'offline_access',
            'state' => csrf_token(),
        ]);

        return $this->baseUrl . '/oauth2/auth?' . $params;
    }

    /**
     * Exchange authorization code for access token.
     */
    public function getAccessToken(string $code): array
    {
        $response = Http::post($this->baseUrl . '/oauth2/token', [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $this->redirectUri,
        ]);

        if ($response->failed()) {
            Log::error('Salla token exchange failed', [
                'status' => $response->status(),
                'response' => $response->body(),
            ]);
            throw new \Exception('فشل في الحصول على رمز الوصول من سلة');
        }

        return $response->json();
    }

    /**
     * Refresh access token using refresh token.
     */
    public function refreshAccessToken(string $refreshToken): array
    {
        $response = Http::post($this->baseUrl . '/oauth2/token', [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'grant_type' => 'refresh_token',
            'refresh_token' => $refreshToken,
        ]);

        if ($response->failed()) {
            Log::error('Salla token refresh failed', [
                'status' => $response->status(),
                'response' => $response->body(),
            ]);
            throw new \Exception('فشل في تجديد رمز الوصول من سلة');
        }

        return $response->json();
    }

    /**
     * Get store information.
     */
    public function getStoreInfo(string $accessToken): array
    {
        $response = Http::withHeaders([
            'Authorization' => "Bearer {$accessToken}",
            'Accept' => 'application/json',
        ])->get($this->apiUrl . '/admin/v2/store');

        if ($response->failed()) {
            Log::error('Failed to get Salla store info', [
                'status' => $response->status(),
                'response' => $response->body(),
            ]);
            throw new \Exception('فشل في جلب معلومات المتجر من سلة');
        }

        $data = $response->json();
        return $data['data'] ?? $data;
    }

    /**
     * Get store products.
     */
    public function getProducts(PlatformToken $token, int $page = 1, int $perPage = 50): array
    {
        $this->ensureValidToken($token);

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$token->decrypted_access_token}",
            'Accept' => 'application/json',
        ])->get($this->apiUrl . '/admin/v2/products', [
            'page' => $page,
            'per_page' => $perPage,
        ]);

        if ($response->failed()) {
            Log::error('Failed to get Salla products', [
                'status' => $response->status(),
                'response' => $response->body(),
                'store_id' => $token->store_id,
            ]);
            throw new \Exception('فشل في جلب المنتجات من سلة');
        }

        return $response->json();
    }

    /**
     * Get specific product.
     */
    public function getProduct(PlatformToken $token, int $productId): array
    {
        $this->ensureValidToken($token);

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$token->decrypted_access_token}",
            'Accept' => 'application/json',
        ])->get($this->apiUrl . "/admin/v2/products/{$productId}");

        if ($response->failed()) {
            Log::error('Failed to get Salla product', [
                'status' => $response->status(),
                'response' => $response->body(),
                'product_id' => $productId,
                'store_id' => $token->store_id,
            ]);
            throw new \Exception('فشل في جلب المنتج من سلة');
        }

        $data = $response->json();
        return $data['data'] ?? $data;
    }

    /**
     * Update product SEO data.
     */
    public function updateProductSEO(PlatformToken $token, int $productId, array $seoData): array
    {
        $this->ensureValidToken($token);

        $updateData = [];

        if (isset($seoData['title'])) {
            $updateData['name'] = $seoData['title'];
        }

        if (isset($seoData['description'])) {
            $updateData['description'] = $seoData['description'];
        }

        if (isset($seoData['meta_title'])) {
            $updateData['metadata']['title'] = $seoData['meta_title'];
        }

        if (isset($seoData['meta_description'])) {
            $updateData['metadata']['description'] = $seoData['meta_description'];
        }

        if (isset($seoData['keywords'])) {
            $updateData['metadata']['keywords'] = $seoData['keywords'];
        }

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$token->decrypted_access_token}",
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->put($this->apiUrl . "/admin/v2/products/{$productId}", $updateData);

        if ($response->failed()) {
            Log::error('Failed to update Salla product SEO', [
                'status' => $response->status(),
                'response' => $response->body(),
                'product_id' => $productId,
                'store_id' => $token->store_id,
                'update_data' => $updateData,
            ]);
            throw new \Exception('فشل في تحديث بيانات SEO للمنتج في سلة');
        }

        return $response->json();
    }

    /**
     * Get store categories.
     */
    public function getCategories(PlatformToken $token): array
    {
        $this->ensureValidToken($token);

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$token->decrypted_access_token}",
            'Accept' => 'application/json',
        ])->get($this->apiUrl . '/admin/v2/categories');

        if ($response->failed()) {
            Log::error('Failed to get Salla categories', [
                'status' => $response->status(),
                'response' => $response->body(),
                'store_id' => $token->store_id,
            ]);
            throw new \Exception('فشل في جلب الفئات من سلة');
        }

        return $response->json();
    }

    /**
     * Get store analytics data.
     */
    public function getAnalytics(PlatformToken $token, string $startDate, string $endDate): array
    {
        $this->ensureValidToken($token);

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$token->decrypted_access_token}",
            'Accept' => 'application/json',
        ])->get($this->apiUrl . '/admin/v2/reports/analytics', [
            'start_date' => $startDate,
            'end_date' => $endDate,
        ]);

        if ($response->failed()) {
            Log::error('Failed to get Salla analytics', [
                'status' => $response->status(),
                'response' => $response->body(),
                'store_id' => $token->store_id,
            ]);
            throw new \Exception('فشل في جلب تحليلات المتجر من سلة');
        }

        return $response->json();
    }

    /**
     * Sync store data for SEO analysis.
     */
    public function syncData(PlatformToken $token): array
    {
        $this->ensureValidToken($token);

        $syncedItems = 0;
        $errors = [];

        try {
            // Sync products
            $page = 1;
            do {
                $productsResponse = $this->getProducts($token, $page, 50);
                $products = $productsResponse['data'] ?? [];

                foreach ($products as $product) {
                    try {
                        $this->syncProduct($token, $product);
                        $syncedItems++;
                    } catch (\Exception $e) {
                        $errors[] = "Product {$product['id']}: " . $e->getMessage();
                    }
                }

                $page++;
            } while (!empty($products) && count($products) === 50);

            // Sync categories
            $categoriesResponse = $this->getCategories($token);
            $categories = $categoriesResponse['data'] ?? [];

            foreach ($categories as $category) {
                try {
                    $this->syncCategory($token, $category);
                    $syncedItems++;
                } catch (\Exception $e) {
                    $errors[] = "Category {$category['id']}: " . $e->getMessage();
                }
            }

        } catch (\Exception $e) {
            Log::error('Salla data sync failed', [
                'store_id' => $token->store_id,
                'error' => $e->getMessage(),
            ]);
            throw new \Exception('فشل في مزامنة بيانات المتجر');
        }

        return [
            'count' => $syncedItems,
            'errors' => $errors,
        ];
    }

    /**
     * Test connection to Salla API.
     */
    public function testConnection(PlatformToken $token): bool
    {
        try {
            $this->getStoreInfo($token->decrypted_access_token);
            return true;
        } catch (\Exception $e) {
            Log::warning('Salla connection test failed', [
                'store_id' => $token->store_id,
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * Ensure token is valid and refresh if needed.
     */
    protected function ensureValidToken(PlatformToken $token): void
    {
        if ($token->isExpired() && $token->decrypted_refresh_token) {
            try {
                $newTokens = $this->refreshAccessToken($token->decrypted_refresh_token);
                $token->updateTokenData($newTokens);
            } catch (\Exception $e) {
                Log::error('Failed to refresh Salla token', [
                    'store_id' => $token->store_id,
                    'error' => $e->getMessage(),
                ]);
                throw new \Exception('انتهت صلاحية الاتصال مع سلة. يرجى إعادة الربط');
            }
        }
    }

    /**
     * Sync individual product.
     */
    protected function syncProduct(PlatformToken $token, array $product): void
    {
        // Store product data in local database for SEO analysis
        // This would typically save to a products table
        
        Log::info('Synced Salla product', [
            'store_id' => $token->store_id,
            'product_id' => $product['id'],
            'product_name' => $product['name'] ?? 'Unknown',
        ]);
    }

    /**
     * Sync individual category.
     */
    protected function syncCategory(PlatformToken $token, array $category): void
    {
        // Store category data in local database for SEO analysis
        
        Log::info('Synced Salla category', [
            'store_id' => $token->store_id,
            'category_id' => $category['id'],
            'category_name' => $category['name'] ?? 'Unknown',
        ]);
    }

    /**
     * Get webhook events for store.
     */
    public function getWebhookEvents(): array
    {
        return [
            'product.created',
            'product.updated',
            'product.deleted',
            'category.created',
            'category.updated',
            'category.deleted',
            'order.created',
            'order.updated',
        ];
    }

    /**
     * Register webhook for store events.
     */
    public function registerWebhook(PlatformToken $token, string $webhookUrl): array
    {
        $this->ensureValidToken($token);

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$token->decrypted_access_token}",
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->post($this->apiUrl . '/admin/v2/webhooks', [
            'name' => 'Saudi SEO Pro Webhook',
            'url' => $webhookUrl,
            'events' => $this->getWebhookEvents(),
        ]);

        if ($response->failed()) {
            Log::error('Failed to register Salla webhook', [
                'status' => $response->status(),
                'response' => $response->body(),
                'store_id' => $token->store_id,
            ]);
            throw new \Exception('فشل في تسجيل webhook مع سلة');
        }

        return $response->json();
    }
}

