<?php

namespace App\Services;

use App\Models\User;
use App\Models\Subscription;
use App\Models\Payment;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class BillingService
{
    protected $paypalClientId;
    protected $paypalClientSecret;
    protected $paypalBaseUrl;
    protected $stripeSecretKey;

    public function __construct()
    {
        $this->paypalClientId = config('services.paypal.client_id');
        $this->paypalClientSecret = config('services.paypal.client_secret');
        $this->paypalBaseUrl = config('services.paypal.base_url', 'https://api-m.sandbox.paypal.com');
        $this->stripeSecretKey = config('services.stripe.secret');
    }

    /**
     * Create payment session for subscription.
     */
    public function createPaymentSession(array $data): array
    {
        $paymentMethod = $data['payment_method'];
        
        switch ($paymentMethod) {
            case 'paypal':
                return $this->createPayPalPayment($data);
            case 'credit_card':
                return $this->createStripePayment($data);
            case 'stc_pay':
                return $this->createSTCPayPayment($data);
            case 'bank_transfer':
                return $this->createBankTransferPayment($data);
            default:
                throw new \InvalidArgumentException("Unsupported payment method: {$paymentMethod}");
        }
    }

    /**
     * Create PayPal payment.
     */
    protected function createPayPalPayment(array $data): array
    {
        $accessToken = $this->getPayPalAccessToken();
        
        $orderData = [
            'intent' => 'CAPTURE',
            'purchase_units' => [
                [
                    'reference_id' => 'subscription_' . $data['subscription_id'],
                    'amount' => [
                        'currency_code' => $data['currency'],
                        'value' => number_format($data['amount'], 2, '.', ''),
                    ],
                    'description' => $this->getSubscriptionDescription($data['subscription_id']),
                ]
            ],
            'application_context' => [
                'return_url' => route('subscription.payment.success'),
                'cancel_url' => route('subscription.payment.cancel'),
                'brand_name' => config('app.name'),
                'locale' => 'ar-SA',
                'landing_page' => 'BILLING',
                'user_action' => 'PAY_NOW',
            ],
        ];

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$accessToken}",
            'Content-Type' => 'application/json',
        ])->post("{$this->paypalBaseUrl}/v2/checkout/orders", $orderData);

        if ($response->failed()) {
            Log::error('PayPal order creation failed', [
                'response' => $response->body(),
                'data' => $data,
            ]);
            throw new \Exception('فشل في إنشاء طلب الدفع عبر PayPal');
        }

        $order = $response->json();
        
        // Store payment session
        $this->storePaymentSession([
            'session_id' => $order['id'],
            'user_id' => $data['user_id'],
            'subscription_id' => $data['subscription_id'],
            'amount' => $data['amount'],
            'currency' => $data['currency'],
            'payment_method' => 'paypal',
            'status' => 'pending',
        ]);

        return [
            'payment_url' => $this->getPayPalApprovalUrl($order['links']),
            'session_id' => $order['id'],
        ];
    }

    /**
     * Create Stripe payment.
     */
    protected function createStripePayment(array $data): array
    {
        \Stripe\Stripe::setApiKey($this->stripeSecretKey);

        try {
            $session = \Stripe\Checkout\Session::create([
                'payment_method_types' => ['card'],
                'line_items' => [
                    [
                        'price_data' => [
                            'currency' => strtolower($data['currency']),
                            'product_data' => [
                                'name' => $this->getSubscriptionDescription($data['subscription_id']),
                            ],
                            'unit_amount' => $data['amount'] * 100, // Convert to cents
                        ],
                        'quantity' => 1,
                    ],
                ],
                'mode' => 'payment',
                'success_url' => route('subscription.payment.success') . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => route('subscription.payment.cancel'),
                'metadata' => [
                    'user_id' => $data['user_id'],
                    'subscription_id' => $data['subscription_id'],
                ],
            ]);

            // Store payment session
            $this->storePaymentSession([
                'session_id' => $session->id,
                'user_id' => $data['user_id'],
                'subscription_id' => $data['subscription_id'],
                'amount' => $data['amount'],
                'currency' => $data['currency'],
                'payment_method' => 'credit_card',
                'status' => 'pending',
            ]);

            return [
                'payment_url' => $session->url,
                'session_id' => $session->id,
            ];

        } catch (\Exception $e) {
            Log::error('Stripe payment creation failed', [
                'error' => $e->getMessage(),
                'data' => $data,
            ]);
            throw new \Exception('فشل في إنشاء جلسة الدفع');
        }
    }

    /**
     * Create STC Pay payment.
     */
    protected function createSTCPayPayment(array $data): array
    {
        // This would integrate with STC Pay API
        // For now, we'll create a mock implementation
        
        $sessionId = 'stc_' . Str::random(32);
        
        // Store payment session
        $this->storePaymentSession([
            'session_id' => $sessionId,
            'user_id' => $data['user_id'],
            'subscription_id' => $data['subscription_id'],
            'amount' => $data['amount'],
            'currency' => $data['currency'],
            'payment_method' => 'stc_pay',
            'status' => 'pending',
        ]);

        return [
            'payment_url' => route('payment.stc', ['session' => $sessionId]),
            'session_id' => $sessionId,
        ];
    }

    /**
     * Create bank transfer payment.
     */
    protected function createBankTransferPayment(array $data): array
    {
        $sessionId = 'bank_' . Str::random(32);
        
        // Store payment session
        $this->storePaymentSession([
            'session_id' => $sessionId,
            'user_id' => $data['user_id'],
            'subscription_id' => $data['subscription_id'],
            'amount' => $data['amount'],
            'currency' => $data['currency'],
            'payment_method' => 'bank_transfer',
            'status' => 'pending',
        ]);

        return [
            'payment_url' => route('payment.bank-transfer', ['session' => $sessionId]),
            'session_id' => $sessionId,
        ];
    }

    /**
     * Verify payment completion.
     */
    public function verifyPayment(string $sessionId): array
    {
        $paymentSession = $this->getPaymentSession($sessionId);
        
        if (!$paymentSession) {
            throw new \Exception('جلسة الدفع غير موجودة');
        }

        switch ($paymentSession['payment_method']) {
            case 'paypal':
                return $this->verifyPayPalPayment($sessionId);
            case 'credit_card':
                return $this->verifyStripePayment($sessionId);
            case 'stc_pay':
                return $this->verifySTCPayPayment($sessionId);
            case 'bank_transfer':
                return $this->verifyBankTransferPayment($sessionId);
            default:
                throw new \Exception('طريقة دفع غير مدعومة');
        }
    }

    /**
     * Verify PayPal payment.
     */
    protected function verifyPayPalPayment(string $orderId): array
    {
        $accessToken = $this->getPayPalAccessToken();
        
        $response = Http::withHeaders([
            'Authorization' => "Bearer {$accessToken}",
        ])->get("{$this->paypalBaseUrl}/v2/checkout/orders/{$orderId}");

        if ($response->failed()) {
            throw new \Exception('فشل في التحقق من دفعة PayPal');
        }

        $order = $response->json();
        $paymentSession = $this->getPaymentSession($orderId);

        return [
            'status' => $order['status'] === 'APPROVED' ? 'completed' : 'failed',
            'payment_id' => $order['id'],
            'amount' => $paymentSession['amount'],
            'currency' => $paymentSession['currency'],
            'payment_method' => 'paypal',
            'subscription_id' => $paymentSession['subscription_id'],
        ];
    }

    /**
     * Verify Stripe payment.
     */
    protected function verifyStripePayment(string $sessionId): array
    {
        \Stripe\Stripe::setApiKey($this->stripeSecretKey);

        try {
            $session = \Stripe\Checkout\Session::retrieve($sessionId);
            $paymentSession = $this->getPaymentSession($sessionId);

            return [
                'status' => $session->payment_status === 'paid' ? 'completed' : 'failed',
                'payment_id' => $session->payment_intent,
                'amount' => $paymentSession['amount'],
                'currency' => $paymentSession['currency'],
                'payment_method' => 'credit_card',
                'subscription_id' => $paymentSession['subscription_id'],
            ];

        } catch (\Exception $e) {
            throw new \Exception('فشل في التحقق من دفعة Stripe');
        }
    }

    /**
     * Calculate prorated amount for subscription upgrade.
     */
    public function calculateProratedAmount(Subscription $currentSubscription, Subscription $newSubscription, User $user): float
    {
        $lastPayment = $user->payments()
            ->where('status', 'completed')
            ->latest()
            ->first();

        if (!$lastPayment) {
            return $newSubscription->price;
        }

        $daysInCycle = match ($currentSubscription->billing_cycle) {
            'monthly' => 30,
            'quarterly' => 90,
            'yearly' => 365,
            default => 30,
        };

        $daysSincePayment = $lastPayment->paid_at->diffInDays(now());
        $remainingDays = max(0, $daysInCycle - $daysSincePayment);
        
        $currentDailyRate = $currentSubscription->price / $daysInCycle;
        $newDailyRate = $newSubscription->price / $daysInCycle;
        
        $refundAmount = $currentDailyRate * $remainingDays;
        $newAmount = $newDailyRate * $remainingDays;
        
        return max(0, $newAmount - $refundAmount);
    }

    /**
     * Cancel subscription billing.
     */
    public function cancelSubscription(int $userId): bool
    {
        // This would cancel recurring billing with payment providers
        // Implementation depends on the payment method used
        
        Log::info('Subscription billing cancelled', ['user_id' => $userId]);
        
        return true;
    }

    /**
     * Generate invoice PDF.
     */
    public function generateInvoice(Payment $payment): \Illuminate\Http\Response
    {
        // This would generate a PDF invoice
        // For now, return a simple response
        
        return response()->json([
            'message' => 'Invoice generation not implemented yet',
            'payment_id' => $payment->id,
        ]);
    }

    /**
     * Get PayPal access token.
     */
    protected function getPayPalAccessToken(): string
    {
        $response = Http::withBasicAuth($this->paypalClientId, $this->paypalClientSecret)
            ->asForm()
            ->post("{$this->paypalBaseUrl}/v1/oauth2/token", [
                'grant_type' => 'client_credentials',
            ]);

        if ($response->failed()) {
            throw new \Exception('فشل في الحصول على رمز الوصول من PayPal');
        }

        return $response->json()['access_token'];
    }

    /**
     * Get PayPal approval URL from links.
     */
    protected function getPayPalApprovalUrl(array $links): string
    {
        foreach ($links as $link) {
            if ($link['rel'] === 'approve') {
                return $link['href'];
            }
        }

        throw new \Exception('رابط الموافقة غير موجود في استجابة PayPal');
    }

    /**
     * Get subscription description.
     */
    protected function getSubscriptionDescription(int $subscriptionId): string
    {
        $subscription = Subscription::find($subscriptionId);
        return $subscription ? "اشتراك {$subscription->name} - Saudi SEO Pro" : 'اشتراك Saudi SEO Pro';
    }

    /**
     * Store payment session.
     */
    protected function storePaymentSession(array $data): void
    {
        // Store in cache or database
        cache()->put("payment_session_{$data['session_id']}", $data, now()->addHours(2));
    }

    /**
     * Get payment session.
     */
    protected function getPaymentSession(string $sessionId): ?array
    {
        return cache()->get("payment_session_{$sessionId}");
    }

    /**
     * Verify STC Pay payment (mock implementation).
     */
    protected function verifySTCPayPayment(string $sessionId): array
    {
        $paymentSession = $this->getPaymentSession($sessionId);
        
        // Mock verification - in real implementation, this would call STC Pay API
        return [
            'status' => 'completed',
            'payment_id' => $sessionId,
            'amount' => $paymentSession['amount'],
            'currency' => $paymentSession['currency'],
            'payment_method' => 'stc_pay',
            'subscription_id' => $paymentSession['subscription_id'],
        ];
    }

    /**
     * Verify bank transfer payment (mock implementation).
     */
    protected function verifyBankTransferPayment(string $sessionId): array
    {
        $paymentSession = $this->getPaymentSession($sessionId);
        
        // Bank transfers need manual verification
        return [
            'status' => 'pending_verification',
            'payment_id' => $sessionId,
            'amount' => $paymentSession['amount'],
            'currency' => $paymentSession['currency'],
            'payment_method' => 'bank_transfer',
            'subscription_id' => $paymentSession['subscription_id'],
        ];
    }
}

