<?php

namespace App\Services;

use App\Models\PlatformToken;
use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Crypt;

class ZidService
{
    protected string $baseUrl;
    protected string $clientId;
    protected string $clientSecret;
    protected string $redirectUri;
    protected ?PlatformToken $token;

    public function __construct()
    {
        $this->baseUrl = config('services.zid.base_url');
        $this->clientId = config('services.zid.client_id');
        $this->clientSecret = config('services.zid.client_secret');
        $this->redirectUri = config('services.zid.redirect_uri');
    }

    public function setToken(PlatformToken $token): void
    {
        $this->token = $token;
    }

    public function getAuthUrl(string $state = null): string
    {
        $params = [
            'client_id' => $this->clientId,
            'redirect_uri' => $this->redirectUri,
            'response_type' => 'code',
            'scope' => 'read_products write_products read_orders read_store_profile',
        ];

        if ($state) {
            $params['state'] = $state;
        }

        return $this->baseUrl . '/oauth/authorize?' . http_build_query($params);
    }

    public function handleCallback(string $code, User $user): PlatformToken
    {
        $response = Http::post($this->baseUrl . '/oauth/token', [
            'grant_type' => 'authorization_code',
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'redirect_uri' => $this->redirectUri,
            'code' => $code,
        ]);

        if (!$response->successful()) {
            throw new \Exception('Failed to exchange code for token: ' . $response->body());
        }

        $tokenData = $response->json();

        // Get store information
        $storeInfo = $this->getStoreInfo($tokenData['access_token']);

        // Create or update platform token
        $platformToken = PlatformToken::updateOrCreate(
            [
                'user_id' => $user->id,
                'platform' => 'zid',
                'store_id' => $storeInfo['id'] ?? null,
            ],
            [
                'store_name' => $storeInfo['name'] ?? null,
                'store_url' => $storeInfo['domain'] ?? null,
                'access_token' => Crypt::encryptString($tokenData['access_token']),
                'refresh_token' => isset($tokenData['refresh_token']) ? Crypt::encryptString($tokenData['refresh_token']) : null,
                'expires_at' => isset($tokenData['expires_in']) ? now()->addSeconds($tokenData['expires_in']) : null,
                'scopes' => $tokenData['scope'] ? explode(' ', $tokenData['scope']) : [],
                'store_info' => $storeInfo,
                'status' => 'active',
                'last_used_at' => now(),
            ]
        );

        Log::info('Zid integration connected', [
            'user_id' => $user->id,
            'store_id' => $storeInfo['id'] ?? null,
            'store_name' => $storeInfo['name'] ?? null,
        ]);

        return $platformToken;
    }

    public function getStoreInfo(?string $accessToken = null): array
    {
        $token = $accessToken ?? $this->getAccessToken();

        $response = Http::withToken($token)
            ->get($this->baseUrl . '/v1/managers/account/stores');

        if (!$response->successful()) {
            throw new \Exception('Failed to get store info: ' . $response->body());
        }

        $stores = $response->json('stores', []);
        return $stores[0] ?? [];
    }

    public function getProducts(array $params = []): array
    {
        $this->ensureValidToken();

        $defaultParams = [
            'page' => 1,
            'per_page' => 50,
        ];

        $params = array_merge($defaultParams, $params);

        $response = Http::withToken($this->getAccessToken())
            ->get($this->baseUrl . '/v1/products', $params);

        if (!$response->successful()) {
            throw new \Exception('Failed to get products: ' . $response->body());
        }

        return $response->json();
    }

    public function getProduct(int $productId): array
    {
        $this->ensureValidToken();

        $response = Http::withToken($this->getAccessToken())
            ->get($this->baseUrl . "/v1/products/{$productId}");

        if (!$response->successful()) {
            throw new \Exception('Failed to get product: ' . $response->body());
        }

        return $response->json();
    }

    public function updateProduct(int $productId, array $data): array
    {
        $this->ensureValidToken();

        $response = Http::withToken($this->getAccessToken())
            ->put($this->baseUrl . "/v1/products/{$productId}", $data);

        if (!$response->successful()) {
            throw new \Exception('Failed to update product: ' . $response->body());
        }

        return $response->json();
    }

    public function optimizeProductSeo(int $productId, array $seoData): array
    {
        $product = $this->getProduct($productId);
        
        $optimizedData = [
            'seo' => [
                'title' => $seoData['meta_title'] ?? $product['name'],
                'description' => $seoData['meta_description'] ?? $this->generateMetaDescription($product),
                'keywords' => $seoData['keywords'] ?? $this->extractKeywords($product),
            ]
        ];

        // Add optimized description if provided
        if (isset($seoData['description'])) {
            $optimizedData['description'] = $seoData['description'];
        }

        return $this->updateProduct($productId, $optimizedData);
    }

    public function getOrders(array $params = []): array
    {
        $this->ensureValidToken();

        $defaultParams = [
            'page' => 1,
            'per_page' => 50,
            'status' => 'all',
        ];

        $params = array_merge($defaultParams, $params);

        $response = Http::withToken($this->getAccessToken())
            ->get($this->baseUrl . '/v1/orders', $params);

        if (!$response->successful()) {
            throw new \Exception('Failed to get orders: ' . $response->body());
        }

        return $response->json();
    }

    public function getAnalytics(array $params = []): array
    {
        $this->ensureValidToken();

        $defaultParams = [
            'start_date' => now()->subDays(30)->format('Y-m-d'),
            'end_date' => now()->format('Y-m-d'),
        ];

        $params = array_merge($defaultParams, $params);

        $response = Http::withToken($this->getAccessToken())
            ->get($this->baseUrl . '/v1/analytics/overview', $params);

        if (!$response->successful()) {
            throw new \Exception('Failed to get analytics: ' . $response->body());
        }

        return $response->json();
    }

    public function syncProducts(): array
    {
        $this->ensureValidToken();

        $allProducts = [];
        $page = 1;
        $perPage = 100;

        do {
            $response = $this->getProducts([
                'page' => $page,
                'per_page' => $perPage,
            ]);

            $products = $response['products'] ?? [];
            $allProducts = array_merge($allProducts, $products);

            $page++;
        } while (count($products) === $perPage);

        // Update sync status
        $this->token->update([
            'last_sync_at' => now(),
            'sync_status' => [
                'products_count' => count($allProducts),
                'last_sync' => now()->toISOString(),
            ],
            'sync_count' => $this->token->sync_count + 1,
        ]);

        Log::info('Zid products synced', [
            'user_id' => $this->token->user_id,
            'store_id' => $this->token->store_id,
            'products_count' => count($allProducts),
        ]);

        return $allProducts;
    }

    protected function getAccessToken(): string
    {
        if (!$this->token) {
            throw new \Exception('No token set for Zid service');
        }

        return Crypt::decryptString($this->token->access_token);
    }

    protected function ensureValidToken(): void
    {
        if (!$this->token) {
            throw new \Exception('No token set for Zid service');
        }

        if ($this->token->expires_at && $this->token->expires_at->isPast()) {
            $this->refreshToken();
        }

        $this->token->update(['last_used_at' => now()]);
    }

    protected function refreshToken(): void
    {
        if (!$this->token->refresh_token) {
            throw new \Exception('No refresh token available');
        }

        $response = Http::post($this->baseUrl . '/oauth/token', [
            'grant_type' => 'refresh_token',
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'refresh_token' => Crypt::decryptString($this->token->refresh_token),
        ]);

        if (!$response->successful()) {
            $this->token->update(['status' => 'expired']);
            throw new \Exception('Failed to refresh token: ' . $response->body());
        }

        $tokenData = $response->json();

        $this->token->update([
            'access_token' => Crypt::encryptString($tokenData['access_token']),
            'refresh_token' => isset($tokenData['refresh_token']) ? Crypt::encryptString($tokenData['refresh_token']) : $this->token->refresh_token,
            'expires_at' => isset($tokenData['expires_in']) ? now()->addSeconds($tokenData['expires_in']) : null,
            'status' => 'active',
        ]);
    }

    protected function generateMetaDescription(array $product): string
    {
        $description = $product['description'] ?? $product['name'] ?? '';
        $description = strip_tags($description);
        $description = str_replace(["\n", "\r", "\t"], ' ', $description);
        $description = preg_replace('/\s+/', ' ', $description);
        
        return mb_substr(trim($description), 0, 160);
    }

    protected function extractKeywords(array $product): array
    {
        $text = ($product['name'] ?? '') . ' ' . ($product['description'] ?? '');
        $text = strip_tags($text);
        $text = strtolower($text);
        
        // Remove common Arabic stop words
        $stopWords = ['في', 'من', 'إلى', 'على', 'عن', 'مع', 'هذا', 'هذه', 'ذلك', 'تلك', 'التي', 'الذي'];
        
        $words = preg_split('/[\s\p{P}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
        $words = array_filter($words, function ($word) use ($stopWords) {
            return mb_strlen($word) > 2 && !in_array($word, $stopWords);
        });

        $wordCounts = array_count_values($words);
        arsort($wordCounts);

        return array_slice(array_keys($wordCounts), 0, 10);
    }

    public function disconnect(): bool
    {
        if (!$this->token) {
            return false;
        }

        try {
            // Revoke token with Zid
            Http::withToken($this->getAccessToken())
                ->post($this->baseUrl . '/oauth/revoke');
        } catch (\Exception $e) {
            Log::warning('Failed to revoke Zid token', [
                'user_id' => $this->token->user_id,
                'error' => $e->getMessage(),
            ]);
        }

        $this->token->update(['status' => 'revoked']);

        Log::info('Zid integration disconnected', [
            'user_id' => $this->token->user_id,
            'store_id' => $this->token->store_id,
        ]);

        return true;
    }
}

