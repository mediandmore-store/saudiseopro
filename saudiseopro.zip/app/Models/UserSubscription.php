<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserSubscription extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'subscription_id',
        'status',
        'amount_paid',
        'currency',
        'billing_cycle',
        'starts_at',
        'expires_at',
        'cancelled_at',
        'ends_at',
        'cancellation_reason',
        'features_snapshot',
        'payment_method',
        'payment_reference',
        'auto_renew',
    ];

    protected $casts = [
        'amount_paid' => 'decimal:2',
        'starts_at' => 'datetime',
        'expires_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'ends_at' => 'datetime',
        'features_snapshot' => 'array',
        'auto_renew' => 'boolean',
    ];

    // Relationships
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeExpired($query)
    {
        return $query->where('status', 'expired')
                    ->orWhere(function ($q) {
                        $q->where('expires_at', '<', now())
                          ->where('status', 'active');
                    });
    }

    public function scopeCancelled($query)
    {
        return $query->where('status', 'cancelled');
    }

    // Helper methods
    public function isActive(): bool
    {
        return $this->status === 'active' && 
               ($this->expires_at === null || $this->expires_at->isFuture());
    }

    public function isExpired(): bool
    {
        return $this->status === 'expired' || 
               ($this->expires_at && $this->expires_at->isPast());
    }

    public function isCancelled(): bool
    {
        return $this->status === 'cancelled';
    }

    public function isInGracePeriod(): bool
    {
        return $this->cancelled_at && 
               $this->ends_at && 
               $this->ends_at->isFuture();
    }

    public function daysUntilExpiry(): int
    {
        if (!$this->expires_at) {
            return -1; // Never expires
        }

        return max(0, now()->diffInDays($this->expires_at, false));
    }

    public function cancel(string $reason = null): bool
    {
        $this->update([
            'status' => 'cancelled',
            'cancelled_at' => now(),
            'ends_at' => $this->expires_at ?? now()->addDays(7), // Grace period
            'cancellation_reason' => $reason,
            'auto_renew' => false,
        ]);

        return true;
    }

    public function renew(): bool
    {
        if (!$this->auto_renew || !$this->subscription) {
            return false;
        }

        $newExpiryDate = match ($this->billing_cycle) {
            'monthly' => $this->expires_at->addMonth(),
            'quarterly' => $this->expires_at->addMonths(3),
            'yearly' => $this->expires_at->addYear(),
            default => $this->expires_at->addMonth(),
        };

        $this->update([
            'expires_at' => $newExpiryDate,
            'status' => 'active',
        ]);

        return true;
    }

    public function getFeatures(): array
    {
        return $this->features_snapshot ?? [];
    }

    public function hasFeature(string $feature): bool
    {
        $features = $this->getFeatures();
        return in_array($feature, $features);
    }
}

