<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'price',
        'description',
        'features',
        'active',
        'max_websites',
        'max_keywords',
        'max_integrations',
        'billing_cycle',
        'trial_days',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'features' => 'array',
        'active' => 'boolean',
        'price' => 'decimal:2',
        'max_websites' => 'integer',
        'max_keywords' => 'integer',
        'max_integrations' => 'integer',
        'trial_days' => 'integer',
    ];

    /**
     * Get the users for the subscription.
     */
    public function users()
    {
        return $this->hasMany(User::class);
    }

    /**
     * Check if subscription is active.
     */
    public function isActive(): bool
    {
        return $this->active;
    }

    /**
     * Check if subscription has a specific feature.
     */
    public function hasFeature(string $feature): bool
    {
        return in_array($feature, $this->features ?? []);
    }

    /**
     * Get formatted price with currency.
     */
    public function getFormattedPriceAttribute(): string
    {
        return number_format($this->price, 2) . ' ريال';
    }

    /**
     * Get monthly price (convert from billing cycle).
     */
    public function getMonthlyPriceAttribute(): float
    {
        return match ($this->billing_cycle) {
            'yearly' => $this->price / 12,
            'quarterly' => $this->price / 3,
            default => $this->price,
        };
    }

    /**
     * Get savings percentage for yearly plans.
     */
    public function getSavingsPercentageAttribute(): int
    {
        if ($this->billing_cycle !== 'yearly') {
            return 0;
        }

        // Assuming monthly price would be 20% higher
        $monthlyEquivalent = $this->price * 1.2;
        return round((($monthlyEquivalent - $this->price) / $monthlyEquivalent) * 100);
    }

    /**
     * Check if subscription includes unlimited websites.
     */
    public function hasUnlimitedWebsites(): bool
    {
        return $this->max_websites === -1 || $this->max_websites >= 999;
    }

    /**
     * Check if subscription includes unlimited keywords.
     */
    public function hasUnlimitedKeywords(): bool
    {
        return $this->max_keywords === -1 || $this->max_keywords >= 999999;
    }

    /**
     * Check if subscription includes unlimited integrations.
     */
    public function hasUnlimitedIntegrations(): bool
    {
        return $this->max_integrations === -1 || $this->max_integrations >= 999;
    }

    /**
     * Get feature list as formatted array.
     */
    public function getFeatureListAttribute(): array
    {
        $featureMap = [
            'google_integration' => 'ربط Google Analytics و Search Console',
            'platform_integration' => 'ربط المتاجر الإلكترونية (سلة، زد، شوبيفاي)',
            'keyword_analysis' => 'تحليل الكلمات المفتاحية',
            'content_optimization' => 'تحسين المحتوى بالذكاء الاصطناعي',
            'competitor_analysis' => 'تحليل المنافسين',
            'rank_tracking' => 'تتبع ترتيب الكلمات',
            'backlink_analysis' => 'تحليل الروابط الخلفية',
            'technical_seo' => 'فحص SEO التقني',
            'white_label' => 'العلامة التجارية البيضاء',
            'api_access' => 'الوصول لـ API',
            'priority_support' => 'دعم فني مميز',
            'custom_reports' => 'تقارير مخصصة',
        ];

        return array_map(function ($feature) use ($featureMap) {
            return $featureMap[$feature] ?? $feature;
        }, $this->features ?? []);
    }

    /**
     * Scope a query to only include active subscriptions.
     */
    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

    /**
     * Scope a query to only include subscriptions with specific feature.
     */
    public function scopeWithFeature($query, string $feature)
    {
        return $query->whereJsonContains('features', $feature);
    }

    /**
     * Scope a query to order by price.
     */
    public function scopeOrderByPrice($query, string $direction = 'asc')
    {
        return $query->orderBy('price', $direction);
    }

    /**
     * Get subscription by name.
     */
    public static function findByName(string $name): ?self
    {
        return static::where('name', $name)->first();
    }

    /**
     * Get default features for new subscriptions.
     */
    public static function getDefaultFeatures(): array
    {
        return [
            'keyword_analysis',
            'content_optimization',
        ];
    }

    /**
     * Get all available features.
     */
    public static function getAllFeatures(): array
    {
        return [
            'google_integration',
            'platform_integration',
            'keyword_analysis',
            'content_optimization',
            'competitor_analysis',
            'rank_tracking',
            'backlink_analysis',
            'technical_seo',
            'white_label',
            'api_access',
            'priority_support',
            'custom_reports',
        ];
    }
}

