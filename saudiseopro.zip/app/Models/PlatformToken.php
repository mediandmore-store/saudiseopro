<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class PlatformToken extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'platform',
        'access_token',
        'refresh_token',
        'expires_at',
        'scope',
        'store_id',
        'store_name',
        'store_url',
        'is_active',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'expires_at' => 'datetime',
        'is_active' => 'boolean',
        'scope' => 'array',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'access_token',
        'refresh_token',
    ];

    /**
     * Available platforms.
     */
    public const PLATFORMS = [
        'salla' => 'سلة',
        'zid' => 'زد',
        'shopify' => 'شوبيفاي',
        'woocommerce' => 'ووكومرس',
    ];

    /**
     * Get the user that owns the platform token.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get decrypted access token.
     */
    public function getDecryptedAccessTokenAttribute(): ?string
    {
        return $this->access_token ? decrypt($this->access_token) : null;
    }

    /**
     * Get decrypted refresh token.
     */
    public function getDecryptedRefreshTokenAttribute(): ?string
    {
        return $this->refresh_token ? decrypt($this->refresh_token) : null;
    }

    /**
     * Set encrypted access token.
     */
    public function setAccessTokenAttribute(?string $value): void
    {
        $this->attributes['access_token'] = $value ? encrypt($value) : null;
    }

    /**
     * Set encrypted refresh token.
     */
    public function setRefreshTokenAttribute(?string $value): void
    {
        $this->attributes['refresh_token'] = $value ? encrypt($value) : null;
    }

    /**
     * Check if token is expired.
     */
    public function isExpired(): bool
    {
        return $this->expires_at && $this->expires_at->isPast();
    }

    /**
     * Check if token will expire soon (within 24 hours).
     */
    public function isExpiringSoon(): bool
    {
        return $this->expires_at && $this->expires_at->diffInHours(now()) <= 24;
    }

    /**
     * Get platform display name.
     */
    public function getPlatformNameAttribute(): string
    {
        return self::PLATFORMS[$this->platform] ?? $this->platform;
    }

    /**
     * Get time until expiration.
     */
    public function getTimeUntilExpirationAttribute(): ?string
    {
        if (!$this->expires_at) {
            return null;
        }

        return $this->expires_at->diffForHumans();
    }

    /**
     * Check if token is valid and active.
     */
    public function isValid(): bool
    {
        return $this->is_active && !$this->isExpired();
    }

    /**
     * Mark token as inactive.
     */
    public function deactivate(): bool
    {
        return $this->update(['is_active' => false]);
    }

    /**
     * Mark token as active.
     */
    public function activate(): bool
    {
        return $this->update(['is_active' => true]);
    }

    /**
     * Update token data.
     */
    public function updateTokenData(array $tokenData): bool
    {
        return $this->update([
            'access_token' => $tokenData['access_token'] ?? $this->access_token,
            'refresh_token' => $tokenData['refresh_token'] ?? $this->refresh_token,
            'expires_at' => isset($tokenData['expires_in']) 
                ? now()->addSeconds($tokenData['expires_in']) 
                : $this->expires_at,
            'scope' => $tokenData['scope'] ?? $this->scope,
            'is_active' => true,
        ]);
    }

    /**
     * Scope a query to only include tokens for specific platform.
     */
    public function scopeForPlatform($query, string $platform)
    {
        return $query->where('platform', $platform);
    }

    /**
     * Scope a query to only include active tokens.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope a query to only include valid (active and not expired) tokens.
     */
    public function scopeValid($query)
    {
        return $query->where('is_active', true)
                    ->where(function ($q) {
                        $q->whereNull('expires_at')
                          ->orWhere('expires_at', '>', now());
                    });
    }

    /**
     * Scope a query to only include expired tokens.
     */
    public function scopeExpired($query)
    {
        return $query->whereNotNull('expires_at')
                    ->where('expires_at', '<=', now());
    }

    /**
     * Scope a query to only include tokens expiring soon.
     */
    public function scopeExpiringSoon($query, int $hours = 24)
    {
        return $query->whereNotNull('expires_at')
                    ->whereBetween('expires_at', [now(), now()->addHours($hours)]);
    }

    /**
     * Get platform token for user and platform.
     */
    public static function getForUserAndPlatform(int $userId, string $platform): ?self
    {
        return static::where('user_id', $userId)
                    ->where('platform', $platform)
                    ->first();
    }

    /**
     * Create or update platform token.
     */
    public static function createOrUpdateForUser(int $userId, string $platform, array $tokenData): self
    {
        return static::updateOrCreate(
            [
                'user_id' => $userId,
                'platform' => $platform,
            ],
            [
                'access_token' => $tokenData['access_token'],
                'refresh_token' => $tokenData['refresh_token'] ?? null,
                'expires_at' => isset($tokenData['expires_in']) 
                    ? now()->addSeconds($tokenData['expires_in']) 
                    : null,
                'scope' => $tokenData['scope'] ?? null,
                'store_id' => $tokenData['store_id'] ?? null,
                'store_name' => $tokenData['store_name'] ?? null,
                'store_url' => $tokenData['store_url'] ?? null,
                'is_active' => true,
            ]
        );
    }

    /**
     * Get all available platforms.
     */
    public static function getAvailablePlatforms(): array
    {
        return self::PLATFORMS;
    }
}

