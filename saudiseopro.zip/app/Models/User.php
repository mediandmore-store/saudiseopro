<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'google_token',
        'google_refresh_token',
        'subscription_id',
        'email_verified_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'google_token',
        'google_refresh_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    /**
     * Get the subscription that owns the user.
     */
    public function subscription()
    {
        return $this->belongsTo(Subscription::class);
    }

    /**
     * Get the platform tokens for the user.
     */
    public function platformTokens()
    {
        return $this->hasMany(PlatformToken::class);
    }

    /**
     * Check if user has an active subscription.
     */
    public function hasActiveSubscription(): bool
    {
        return $this->subscription && $this->subscription->isActive();
    }

    /**
     * Check if user has a specific subscription feature.
     */
    public function hasFeature(string $feature): bool
    {
        return $this->subscription && $this->subscription->hasFeature($feature);
    }

    /**
     * Get decrypted Google access token.
     */
    public function getGoogleAccessToken(): ?string
    {
        return $this->google_token ? decrypt($this->google_token) : null;
    }

    /**
     * Get decrypted Google refresh token.
     */
    public function getGoogleRefreshToken(): ?string
    {
        return $this->google_refresh_token ? decrypt($this->google_refresh_token) : null;
    }

    /**
     * Set encrypted Google access token.
     */
    public function setGoogleAccessToken(?string $token): void
    {
        $this->google_token = $token ? encrypt($token) : null;
    }

    /**
     * Set encrypted Google refresh token.
     */
    public function setGoogleRefreshToken(?string $token): void
    {
        $this->google_refresh_token = $token ? encrypt($token) : null;
    }

    /**
     * Check if user has connected Google account.
     */
    public function hasGoogleConnection(): bool
    {
        return !empty($this->google_token);
    }

    /**
     * Get platform token for specific platform.
     */
    public function getPlatformToken(string $platform): ?PlatformToken
    {
        return $this->platformTokens()->where('platform', $platform)->first();
    }

    /**
     * Check if user has connected to specific platform.
     */
    public function hasConnectedPlatform(string $platform): bool
    {
        return $this->platformTokens()->where('platform', $platform)->exists();
    }

    /**
     * Get all connected platforms.
     */
    public function getConnectedPlatforms(): array
    {
        return $this->platformTokens()->pluck('platform')->toArray();
    }

    /**
     * Scope a query to only include users with active subscriptions.
     */
    public function scopeWithActiveSubscription($query)
    {
        return $query->whereHas('subscription', function ($q) {
            $q->where('active', true);
        });
    }

    /**
     * Scope a query to only include users with specific subscription feature.
     */
    public function scopeWithFeature($query, string $feature)
    {
        return $query->whereHas('subscription', function ($q) use ($feature) {
            $q->whereJsonContains('features', $feature);
        });
    }
}

