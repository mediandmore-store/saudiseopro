<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Website extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'name',
        'url',
        'domain',
        'type',
        'platform',
        'settings',
        'is_verified',
        'verification_method',
        'verification_token',
        'verified_at',
        'is_active',
        'seo_score',
        'last_crawled_at',
        'crawl_status',
        'pages_count',
        'keywords_count',
    ];

    protected $casts = [
        'settings' => 'array',
        'is_verified' => 'boolean',
        'verified_at' => 'datetime',
        'is_active' => 'boolean',
        'seo_score' => 'array',
        'last_crawled_at' => 'datetime',
        'crawl_status' => 'array',
    ];

    // Relationships
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function keywords(): HasMany
    {
        return $this->hasMany(Keyword::class);
    }

    public function pages(): HasMany
    {
        return $this->hasMany(Page::class);
    }

    public function crawlResults(): HasMany
    {
        return $this->hasMany(CrawlResult::class);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeVerified($query)
    {
        return $query->where('is_verified', true);
    }

    public function scopeByType($query, string $type)
    {
        return $query->where('type', $type);
    }

    public function scopeByPlatform($query, string $platform)
    {
        return $query->where('platform', $platform);
    }

    // Mutators
    public function setUrlAttribute($value)
    {
        $this->attributes['url'] = rtrim($value, '/');
        $this->attributes['domain'] = parse_url($value, PHP_URL_HOST);
    }

    // Accessors
    public function getCleanDomainAttribute(): string
    {
        return str_replace('www.', '', $this->domain);
    }

    public function getOverallSeoScoreAttribute(): int
    {
        if (!$this->seo_score) {
            return 0;
        }

        $scores = $this->seo_score;
        $total = 0;
        $count = 0;

        foreach ($scores as $score) {
            if (is_numeric($score)) {
                $total += $score;
                $count++;
            }
        }

        return $count > 0 ? round($total / $count) : 0;
    }

    // Helper methods
    public function generateVerificationToken(): string
    {
        $token = 'ssp-' . Str::random(32);
        $this->update(['verification_token' => $token]);
        return $token;
    }

    public function verify(string $method = 'html_file'): bool
    {
        return $this->update([
            'is_verified' => true,
            'verified_at' => now(),
            'verification_method' => $method,
        ]);
    }

    public function getVerificationHtmlFile(): string
    {
        if (!$this->verification_token) {
            $this->generateVerificationToken();
        }

        return "saudi-seo-pro-verification-{$this->verification_token}.html";
    }

    public function getVerificationMetaTag(): string
    {
        if (!$this->verification_token) {
            $this->generateVerificationToken();
        }

        return "<meta name=\"saudi-seo-pro-verification\" content=\"{$this->verification_token}\" />";
    }

    public function getVerificationDnsRecord(): string
    {
        if (!$this->verification_token) {
            $this->generateVerificationToken();
        }

        return "saudi-seo-pro-verification={$this->verification_token}";
    }

    public function updateSeoScore(array $scores): void
    {
        $this->update([
            'seo_score' => array_merge($this->seo_score ?? [], $scores),
        ]);
    }

    public function updateCrawlStatus(array $status): void
    {
        $this->update([
            'crawl_status' => $status,
            'last_crawled_at' => now(),
        ]);
    }

    public function incrementPagesCount(int $count = 1): void
    {
        $this->increment('pages_count', $count);
    }

    public function incrementKeywordsCount(int $count = 1): void
    {
        $this->increment('keywords_count', $count);
    }

    public function getTypeName(): string
    {
        return match ($this->type) {
            'ecommerce' => 'متجر إلكتروني',
            'blog' => 'مدونة',
            'corporate' => 'موقع شركة',
            'portfolio' => 'معرض أعمال',
            'other' => 'أخرى',
            default => $this->type,
        };
    }

    public function getPlatformName(): string
    {
        return match ($this->platform) {
            'wordpress' => 'WordPress',
            'shopify' => 'Shopify',
            'woocommerce' => 'WooCommerce',
            'salla' => 'سلة',
            'zid' => 'زد',
            'custom' => 'مخصص',
            default => $this->platform ?? 'غير محدد',
        };
    }

    public function needsCrawling(): bool
    {
        return !$this->last_crawled_at || 
               $this->last_crawled_at->diffInHours(now()) >= 24;
    }

    public function getHealthStatus(): string
    {
        if (!$this->is_verified) {
            return 'غير مؤكد';
        }

        if (!$this->is_active) {
            return 'غير نشط';
        }

        $score = $this->overall_seo_score;

        return match (true) {
            $score >= 80 => 'ممتاز',
            $score >= 60 => 'جيد',
            $score >= 40 => 'متوسط',
            $score >= 20 => 'ضعيف',
            default => 'يحتاج تحسين',
        };
    }

    public function getSeoIssues(): array
    {
        $issues = [];
        $seoScore = $this->seo_score ?? [];

        if (($seoScore['meta_titles'] ?? 0) < 80) {
            $issues[] = 'عناوين Meta مفقودة أو غير محسنة';
        }

        if (($seoScore['meta_descriptions'] ?? 0) < 80) {
            $issues[] = 'أوصاف Meta مفقودة أو غير محسنة';
        }

        if (($seoScore['headings'] ?? 0) < 80) {
            $issues[] = 'بنية العناوين (H1, H2, H3) غير محسنة';
        }

        if (($seoScore['images_alt'] ?? 0) < 80) {
            $issues[] = 'نصوص Alt للصور مفقودة';
        }

        if (($seoScore['page_speed'] ?? 0) < 60) {
            $issues[] = 'سرعة تحميل الصفحات بطيئة';
        }

        return $issues;
    }
}

